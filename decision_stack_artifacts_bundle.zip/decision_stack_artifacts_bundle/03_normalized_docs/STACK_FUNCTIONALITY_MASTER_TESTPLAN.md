# STACK FUNCTIONALITY MASTER TESTPLAN

STACK_FUNCTIONALITY_MASTER_TESTPLAN.md

1.  Účel

Tento plán definuje, jak ověřit skutečnou funkčnost celého 30-role GPT
stacku.

Neověřujeme jen to, že jednotlivé role umí generovat hezké odpovědi.
Ověřujeme, že stack jako celek umí: • převzít reálný vstup • správně
routovat další krok • předat použitelný handoff • projít více kroky bez
driftu • vyrobit operativně použitelný artefakt • dovést operátora k
reálné akci nebo rozhodnutí

⸻

2.  Hlavní testovací cíl

Prokázat, že stack funguje jako spolehlivý pracovní systém, ne jako
volná sbírka izolovaných GPT rolí.

Funkční stack musí splnit všech 5 podmínek 1. Routing funguje •
SYSTEM_OS_MASTER vybírá správný další krok • výstup routeru je
konzistentní • re-entry přes router je stabilní 2. Specialisté drží
boundary • každá role dělá svou práci • nevstupuje do práce jiné role •
neporušuje svůj output contract 3. Handoffs jsou použitelné • výstup z
kroku A lze použít v kroku B • nevzniká scope drift • operátor nemusí
ručně improvizovat strukturu dalšího kroku 4. End-to-end flow se
nerozpadá • use case projde více hopy bez ztráty směru • stack
nezkracuje nebo nerozbíjí flow proti očekávání 5. Výsledek má operativní
hodnotu • na konci vzniká použitelný artefakt • ne pouze „hezký text“

⸻

3.  Rozsah

In-scope

Celý stack 30/30:

System • SYSTEM_OS_MASTER • PROMPT_AUTHOR • PROMPT_QA_CRITIC •
PROMPT_PACK_EXPORTER

Core • STRUCTURAL_ENGINE • ASSET_ENGINE • SUGGESTION_ENGINE •
REWRITE_ENGINE • PERFORMANCE_MEMORY • GOVERNANCE_LIGHT •
PATTERN_LIBRARY_LOGIC • CAPITAL_ALLOCATOR • CFO_ENGINE •
SAAS_FEATURE_PACK_ENGINE • ENTERPRISE_LAYER

Add-ons • PRICING_PACKAGER • POSITIONING_POLICE • LIST_BUILDER •
DELIVERABILITY_GUARD • OBJECTION_HANDLER • CALL_CLOSER •
DELIVERY_SOP_ENGINE • RETENTION_ENGINE • EXPERIMENT_DESIGNER •
OPS_AUTOMATOR

Scouts • MARKET_SCOUT_OUTBOUND • MARKET_SCOUT_INBOUND

Triangle • Architecture Copilot • Staff Engineer OS • Founder OS

Out-of-scope pro tento plán • dlouhodobé vyhodnocení tržní pravdy
konkrétních nabídek • benchmark přes externí platformy mimo stack •
builder UI limity, které nejsou součástí prompt/runtime logiky •
automatizované API orchestrace mimo manuální a semimanální operátorský
režim

⸻

4.  Definice úspěchu

4.1 Contract PASS

Role splní svůj základní kontrakt: • správný formát výstupu • správné
sekce • správné schema keys • správná boundary

To je minimum.

4.2 Workflow PASS

Další krok lze provést bez ruční improvizace: • handoff je použitelný •
router vrací správný další hop • operátor ví, co kam vložit

To je střední úroveň důkazu.

4.3 Outcome PASS

Na konci flow vznikne reálně použitelný výstup: • shortlist • ICP cards
• opener pack • pricing pack • prompt export • product spec • call flow
• delivery SOP • experiment pack • execution plan

To je skutečný důkaz funkčnosti.

⸻

5.  Hlavní principy testování
    1.  Nejdřív vertical slices, potom izolované opravy
    2.  Router je single source of routing truth
    3.  Po každém specialistovi znovu router re-entry
    4.  Golden handoffy mají přednost před „chytrou optimalizací“
    5.  Determinismus se testuje na fixních vstupech
    6.  Live utility se testuje až po backbone stabilitě
    7.  Každý FAIL musí mít jasný drift typ a vlastní opravu

⸻

6.  Testovací architektura

Testování se dělí do 5 vrstev.

VRSTVA A — Router integrity

Ověřuje: • determinismus SYSTEM_OS_MASTER • stabilitu prvního routingu •
stabilitu re-entry • zachování scope • stejný flow při stejném vstupu

VRSTVA B — Handoff integrity

Ověřuje: • návaznost mezi rolemi • použitelnost výstupů • správnost
dalšího hopu • nepřítomnost schema driftu

VRSTVA C — Vertical slice integrity

Ověřuje: • celé hlavní pracovní lane • vícehopové flow • finální outcome

VRSTVA D — Operator usability

Ověřuje: • zda stack zvládne junior • zda stack zvládne senior • zda
copy-paste flow funguje bez skrytých pravidel

VRSTVA E — Real-world utility

Ověřuje: • použití ve skutečné práci • praktickou hodnotu výstupu •
schopnost dostat se k live akci

⸻

7.  Hlavní ověřovací lanes

7.1 Revenue lane

Primární lane pro důkaz praktické funkčnosti.

Referenční flow

SYSTEM_OS_MASTER → MARKET_SCOUT_OUTBOUND → STRUCTURAL_ENGINE →
LIST_BUILDER → POSITIONING_POLICE → ASSET_ENGINE → DELIVERABILITY_GUARD
→ PERFORMANCE_MEMORY

Klíčová otázka

Dostane stack operátora od vágního offeru k prvnímu testovatelnému
outbound batchi?

⸻

7.2 Prompt ops lane

Čistá, dobře oddělená lane pro kontrolu boundary.

Referenční flow

SYSTEM_OS_MASTER → PROMPT_AUTHOR → PROMPT_QA_CRITIC →
PROMPT_PACK_EXPORTER

Klíčová otázka

Umí stack prompt vytvořit, auditovat a zabalit bez překrytí rolí?

⸻

7.3 Product lane

Lane pro ověření design-review-execution logiky.

Referenční flow

SYSTEM_OS_MASTER → SAAS_FEATURE_PACK_ENGINE → Architecture Copilot →
Staff Engineer OS → Founder OS

Klíčová otázka

Umí stack převést produktový nápad do implementačně použitelného plánu?

⸻

8.  Hlavní testovací scénáře

SCENARIO_01 — ICP creation

Cíl

Z offeru vytvořit 5 ICP hypotéz, převést je do ICP cards a vybrat
primary ICP.

PASS • správný scout-first routing • 5 použitelných ICP hypotéz • 5
testovatelných ICP cards • ranking primary + backups • žádný scope drift

FAIL • předčasné zúžení bez explicitního zadání • nekonzistentní role
pořadí • ICP nejsou testovatelné • chybí návaznost na sourcing

⸻

SCENARIO_02 — ICP to shortlist

Cíl

Z primary ICP vytvořit account sourcing logic a shortlist workflow.

PASS • source map • query templates • account-ready vs email-ready
logika • tiering • filtry a exkluze

FAIL • směšování ICP definition a sourcingu • nepoužitelný shortlist
output • chybějící account criteria

⸻

SCENARIO_03 — Shortlist to first outreach pack

Cíl

Z ICP a offeru vytvořit message-safe assety.

PASS • positioning fit • assety drží CTA • žádné fake claims • výstupy
jsou copy-paste použitelné

FAIL • messaging drift • fake proof • generický text bez použitelnosti

⸻

SCENARIO_04 — First replies to response system

Cíl

Z prvních objections udělat reply map a next-step logic.

PASS • objection clusters • reply map • navázání na call flow • žádná
nepřiměřená slibnost

FAIL • generic coaching místo usable replies • role přepisuje offer
místo objections logic

⸻

SCENARIO_05 — Prompt lifecycle

Cíl

Vytvořit nový prompt pack end-to-end.

PASS • PROMPT_AUTHOR píše • PROMPT_QA_CRITIC auditne •
PROMPT_PACK_EXPORTER zabalí • boundary drží

FAIL • QA přepisuje prompt • exporter inventuje artefakty • author
nedodrží deterministic structure

⸻

SCENARIO_06 — Product spec to execution

Cíl

Převést produktový nápad do implementačního plánu.

PASS • build-ready spec • doporučená architektura • review rizik •
execution sequencing

FAIL • role overlap • příliš abstraktní výstupy • chybí akční plán

⸻

9.  Backbone testy

Tyto testy jsou povinné před spuštěním full vertical slices.

TEST_01_router_same_input_10x

Účel

Stejný první vstup do SYSTEM_OS_MASTER musí vracet stejný handoff.

PASS • 10/10 identických výsledků • stejný NEXT_GPT • stejné key names •
stejné pořadí • stejné wording

FAIL drift types • route_drift • schema_drift • wording_drift •
format_drift

⸻

TEST_02_router_reentry_same_input_10x

Účel

Stejný re-entry prompt po specialistovi musí vracet stejný další hop.

PASS • 10/10 identických výsledků • žádné předčasné narrowing • žádný
přeskok role

FAIL drift types • route_drift • narrowing_drift • schema_drift •
wording_drift

⸻

TEST_03_flow_determinism_3_hops

Účel

Při fixních mock vstupech musí být celý 3-hop flow identický.

PASS

Například: SYSTEM_OS_MASTER → MARKET_SCOUT_OUTBOUND → SYSTEM_OS_MASTER →
STRUCTURAL_ENGINE → SYSTEM_OS_MASTER → LIST_BUILDER

FAIL drift types • route_drift • narrowing_drift • handoff_drift

⸻

10. Vertical slice test plan

PHASE_1 — Revenue slice

Test chain 1. SYSTEM_OS_MASTER 2. MARKET_SCOUT_OUTBOUND 3.
SYSTEM_OS_MASTER 4. STRUCTURAL_ENGINE 5. SYSTEM_OS_MASTER 6.
LIST_BUILDER 7. SYSTEM_OS_MASTER 8. POSITIONING_POLICE 9.
SYSTEM_OS_MASTER 10. ASSET_ENGINE 11. SYSTEM_OS_MASTER 12.
DELIVERABILITY_GUARD 13. SYSTEM_OS_MASTER 14. PERFORMANCE_MEMORY

Expected outputs • ICP hypotheses • ICP cards • sourcing matrix • fit
audit • opener pack • deliverability baseline • performance decision
logic

Revenue slice PASS • flow se nerozpadne • role boundaries drží • finální
výstupy jsou použitelné • operátor ví, co kam vložit

Revenue slice FAIL • router přeskakuje nebo zužuje scope bez
explicitního zadání • specialista negeneruje použitelný artefakt • další
krok vyžaduje ruční vymýšlení handoffu

⸻

PHASE_2 — Prompt ops slice

Test chain 1. SYSTEM_OS_MASTER 2. PROMPT_AUTHOR 3. SYSTEM_OS_MASTER 4.
PROMPT_QA_CRITIC 5. SYSTEM_OS_MASTER 6. PROMPT_PACK_EXPORTER

Expected outputs • nový prompt • QA audit • repo-ready export plan

PASS • čisté role separation • žádné překrývání author/QA/export •
finální export je použitelný

FAIL • QA přepisuje • exporter přejmenovává nebo vymýšlí soubory •
router dává špatný další hop

⸻

PHASE_3 — Product slice

Test chain 1. SYSTEM_OS_MASTER 2. SAAS_FEATURE_PACK_ENGINE 3.
SYSTEM_OS_MASTER 4. Architecture Copilot 5. SYSTEM_OS_MASTER 6. Staff
Engineer OS 7. SYSTEM_OS_MASTER 8. Founder OS

Expected outputs • build-ready spec • architecture recommendation •
engineering review • execution plan

PASS • design → review → execution flow drží • jasné rozdělení rolí •
finální plan je akční

FAIL • design a review se míchají • execution role nedává praktický plán
• flow nevede k usable outputu

⸻

11. Operator usability tests

TEST_OP_01 — Junior run

Cíl

Ověřit, že junior zvládne flow jen s copy-paste manuálem.

PASS • junior dokáže projít lane bez improvizace • ví, kdy se vrátit do
SYSTEM_OS_MASTER • chápe, co je artefakt a co je další handoff

FAIL • ztratí se mezi rolemi • nepozná, co vracet routeru • potřebuje
skryté vysvětlení mimo stack

⸻

TEST_OP_02 — Senior run

Cíl

Ověřit, že senior dokáže stack používat disciplinovaně a auditovat
drift.

PASS • pozná route drift • pozná schema drift • pozná boundary porušení
• správně zapíše verdict

FAIL • flow není auditovatelné • chybí jasný testovací kontrakt

⸻

12. Live validation tests

Tato vrstva se spouští až po PASS backbone a PASS vertical slices.

LIVE_01 — Revenue live batch

Cíl

Použít revenue lane na skutečný outbound test.

Minimum scope • 1 primary ICP • 1 CTA • 1 opener • 1 malý batch

PASS • vznikne reálný shortlist • vznikne reálný opener • batch lze
spustit • performance data lze vrátit do stacku

FAIL • výstupy nejdou použít live • flow je příliš abstraktní • operátor
musí vše ručně přepisovat

⸻

LIVE_02 — Prompt export

Cíl

Použít prompt ops lane na skutečný nový prompt pack.

PASS • vznikne použitelný prompt • audit najde chyby • export je
repo-ready

FAIL • flow se rozpadne při exportu • role boundary nevydrží reálný use
case

⸻

LIVE_03 — Product planning

Cíl

Použít product lane na skutečný produktový návrh.

PASS • vznikne build-ready spec • review označí rizika • execution plan
je použitelný

FAIL • výstupy jsou příliš obecné • build tým z nich nemůže pracovat

⸻

13. Defect taxonomy

Každý FAIL musí být označen jedním hlavním defect typem. • route_drift —
router vybral jiný další krok • schema_drift — změna klíčů, shape nebo
expected contractu • narrowing_drift — předčasné zúžení scope •
wording_drift — wording se liší proti golden handoffu • format_drift —
jiný formát výstupu • boundary_violation — role dělá práci jiné role •
handoff_failure — výstup nelze použít v dalším kroku •
operator_confusion — flow není použitelné pro operátora •
outcome_failure — finální výstup není prakticky použitelný

⸻

14. Test evidence

Každý test musí mít uložené: • test_id • run_number • input_prompt •
expected_output • actual_output • verdict • drift_type • notes

Doporučené ukládání: • raw prompt • raw response • short verdict •
operator notes

⸻

15. Entry criteria

Do hlavního testovacího programu lze vstoupit jen pokud: • 30/30 role
pack je stabilní ve své aktuální verzi • SYSTEM_OS_MASTER má zamčená
routing rules • existují golden handoffy pro backbone testy • existují
copy-paste test inputs • je určen operátor testu • je určen verdict
owner

⸻

16. Exit criteria

Stack lze označit za funkční až pokud platí vše:

Backbone gate • TEST_01 PASS • TEST_02 PASS • TEST_03 PASS

Vertical slice gate • Revenue slice PASS • Prompt ops slice PASS •
Product slice PASS

Operator gate • Junior run PASS • Senior run PASS

Live gate • Revenue live batch PASS • alespoň 1 prompt ops live run PASS
• alespoň 1 product live run PASS

⸻

17. Release gate

STACK FUNCTIONALITY = GO

pouze pokud: • žádný otevřený route_drift • žádný otevřený schema_drift
• žádný otevřený boundary_violation v hlavních lanes • backbone stabilní
• 3 vertical slices funkční • operátor flow zvládá bez skrytých pravidel
• alespoň 1 revenue lane se dostala do live testu

STACK FUNCTIONALITY = NO-GO

pokud platí alespoň jedno: • router není deterministický • re-entry není
stabilní • vertical slice se rozpadne dřív než vznikne usable artefakt •
operátor neví, co kam vkládat • stack generuje hezký obsah, ale ne
pracovní výstupy

⸻

18. Doporučené pořadí spuštění

Fáze A — Backbone 1. TEST_01_router_same_input_10x 2.
TEST_02_router_reentry_same_input_10x 3. TEST_03_flow_determinism_3_hops

Fáze B — Vertical slices 4. Revenue slice 5. Prompt ops slice 6. Product
slice

Fáze C — Operator usability 7. Junior run 8. Senior run

Fáze D — Live utility 9. Revenue live batch 10. Prompt live export 11.
Product live planning

⸻

19. Praktická rozhodovací logika

Když failne backbone

Nejdi dál. Oprav router a golden handoffy.

Když failne vertical slice

Neopravuj hned celý stack. Oprav jen: • driftující roli • nebo konkrétní
handoff mezi dvěma kroky

Když failne operator usability

Doplň: • copy-paste manuál • re-entry templates • jasnější next-step
pravidla

Když failne live utility

Nejprve ověř: • byl problém v offeru / trhu • nebo ve stacku / flow /
handoffu

⸻

20. Hlavní metrika

Primary metric

Time-to-usable-artifact

Za kolik kroků a s jakým třením stack dovede operátora k artefaktu,
který lze skutečně použít.

Secondary metrics • number of manual fixes per slice • number of
re-entry failures • number of route drifts • number of handoff failures
• operator confusion points per scenario

⸻

21. Finální rozhodnutí

Tento plán nehodnotí, zda je stack „chytrý“. Hodnotí, zda je: •
deterministický tam, kde má být deterministický • pružný tam, kde má být
pružný • auditovatelný • provozně použitelný • schopný vést operátora ke
skutečné akci

Teprve pokud projde backbone, vertical slices, operator usability a live
utility, lze tvrdit, že GPT stack je skutečně funkční.

⸻

22. Next step

Spustit v tomto pořadí: 1. TEST_01_router_same_input_10x 2.
TEST_02_router_reentry_same_input_10x 3. TEST_03_flow_determinism_3_hops
4. Revenue slice 5. Prompt ops slice 6. Product slice

Pokud chceš, navážu rovnou TEST_01_router_same_input_10x.md v přesném
produkčním formátu.
