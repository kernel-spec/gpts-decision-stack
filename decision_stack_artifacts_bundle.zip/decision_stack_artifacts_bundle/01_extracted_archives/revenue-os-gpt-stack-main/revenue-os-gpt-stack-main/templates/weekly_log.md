# Weekly Log Template

> **Usage:** Complete at end of each week. Use PERFORMANCE_MEMORY to update metrics. Log patterns in PATTERN_LIBRARY_LOGIC. See `/ops/schemas/weekly_log.schema.json` for JSON equivalent.

---

## Metadata

| Field | Value |
|-------|-------|
| Week number | W[NN]-[YYYY] |
| Period | [YYYY-MM-DD] to [YYYY-MM-DD] |
| Author | [TBD] |
| Status | draft / final |

---

## 1. Metrics Snapshot

| Metric | This Week | Last Week | Δ | Status |
|--------|-----------|-----------|---|--------|
| MRR | €[TBD] | €[TBD] | [TBD] | [✅/⚠️/❌] |
| New clients | [TBD] | [TBD] | [TBD] | [✅/⚠️/❌] |
| Churned clients | [TBD] | [TBD] | [TBD] | [✅/⚠️/❌] |
| Calls booked | [TBD] | [TBD] | [TBD] | [✅/⚠️/❌] |
| Calls held | [TBD] | [TBD] | [TBD] | [✅/⚠️/❌] |
| Close rate | [TBD]% | [TBD]% | [TBD] | [✅/⚠️/❌] |
| Pipeline value | €[TBD] | €[TBD] | [TBD] | [✅/⚠️/❌] |
| Email open rate | [TBD]% | [TBD]% | [TBD] | [✅/⚠️/❌] |

---

## 2. Wins This Week

1. [TBD]
2. [TBD]
3. [TBD]

## 3. Challenges & Blockers

1. [TBD]
2. [TBD]

## 4. Key Actions Completed

- [ ] [TBD]
- [ ] [TBD]

## 5. Patterns Logged

> Link to pattern records created this week.

- [Pattern ID / description] → [PATTERN_LIBRARY_LOGIC]

## 6. Experiments Running / Completed

| Experiment ID | Status | Result |
|--------------|--------|--------|
| [TBD] | Running / Complete | [TBD] |

## 7. Next Week Priorities

| Priority | Action | Owner | Deadline |
|----------|--------|-------|----------|
| 1 | [TBD] | [TBD] | [TBD] |
| 2 | [TBD] | [TBD] | [TBD] |
| 3 | [TBD] | [TBD] | [TBD] |

## 8. Notes & Observations

[TBD]

---

*Template version: v1 | system_id: weekly-log-template-v1*
