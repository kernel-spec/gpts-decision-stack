# Call Script Template

> **Usage:** Customise for offer type and ICP. Use CALL_CLOSER to generate a tailored version. Have OBJECTION_HANDLER responses ready for Section 5.

---

## Metadata

| Field | Value |
|-------|-------|
| Call type | Discovery / Strategy / Closing / Check-in |
| Offer | [TBD] |
| ICP | [TBD] |
| Duration | [30 / 45 / 60 min] |
| Created | [YYYY-MM-DD] |
| Status | draft / active / archived |

---

## Pre-Call Preparation (5 min before)

- [ ] Review prospect's LinkedIn / website / notes from previous touchpoints.
- [ ] Note 2–3 personalisation points.
- [ ] Have offer page open in another tab.
- [ ] Calendar link ready to send.
- [ ] CRM entry updated with call scheduled.

---

## Section 1 — Opening & Rapport (0–5 min)

```
"Hi [FIRST NAME], great to finally connect. How are you doing?"

[Brief small talk — 1 exchange max]

"Perfect. So I've got us [X] minutes together — does that still work for you?"

"What I'd like to do is: first understand where you're at right now, then share 
a bit about how we work, and if it seems like a good fit, we can talk about 
next steps. Does that sound OK?"
```

---

## Section 2 — Situation Questions (5–15 min)

> Goal: Understand current state without leading.

- "Can you walk me through what your [REVENUE / PIPELINE / PROCESS] looks like right now?"
- "What's working well?"
- "What are you currently doing to [ACHIEVE GOAL]?"
- "How long has that approach been in place?"

---

## Section 3 — Problem Questions (15–25 min)

> Goal: Surface and deepen pain.

- "Where are you feeling the most friction?"
- "What happens when [PAIN SCENARIO]?"
- "How is that affecting [BUSINESS OUTCOME / TEAM / YOU PERSONALLY]?"
- "Have you tried solving this before? What happened?"

---

## Section 4 — Implication & Vision (25–35 min)

> Goal: Connect pain to cost; co-create the desired future.

- "What does this cost you — in time, money, or opportunities — if it stays as it is?"
- "If we solved [PROBLEM] in the next 90 days, what would that make possible?"
- "What would hitting [GOAL] mean for you personally?"

---

## Section 5 — Offer Presentation (35–42 min)

```
"Based on what you've shared, here's what I think could help..."

[Present offer in 3 sentences: What it is, Who it's for, What outcome it delivers.]

"Specifically, we'd [KEY DELIVERABLE 1], [KEY DELIVERABLE 2], and [KEY DELIVERABLE 3]."

"The investment is €[X] [payment structure]."

"Does this feel like it could be the right fit for you?"
```

---

## Section 6 — Objection Handling (as needed)

> See OBJECTION_HANDLER for scripted responses to common objections.

| Objection | Response summary |
|-----------|-----------------|
| Price | [Refer to OBJECTION_HANDLER] |
| Need to think | [Refer to OBJECTION_HANDLER] |
| Need to ask partner | [Refer to OBJECTION_HANDLER] |
| Bad past experience | [Refer to OBJECTION_HANDLER] |

---

## Section 7 — Close & Next Steps (42–45 min)

```
"Great. So to recap: [RESTATE THEIR PAIN + YOUR SOLUTION IN 2 SENTENCES]."

"The next step would be [CONTRACT / PAYMENT LINK / ONBOARDING CALL]. 
Does that work for you?"

[If yes]: "Perfect — I'll send that over right after this call."
[If unsure]: "What would you need to feel confident moving forward?"
```

---

## Post-Call Actions (within 1 hour)

- [ ] CRM updated with outcome and next step.
- [ ] Follow-up email sent (use email_sequence template or ASSET_ENGINE).
- [ ] Contract / proposal sent if agreed.
- [ ] Notes logged for PERFORMANCE_MEMORY.

---

*Template version: v1 | system_id: call-script-template-v1*
