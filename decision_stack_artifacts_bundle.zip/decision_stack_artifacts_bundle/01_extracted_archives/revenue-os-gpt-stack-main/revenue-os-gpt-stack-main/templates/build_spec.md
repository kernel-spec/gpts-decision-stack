# Build Specification Template

> **Usage:** Complete before any product, feature, or campaign build. Use SAAS_FEATURE_PACK_ENGINE to generate feature specs. Reviewed by CFO_ENGINE before committing resources.

---

## Metadata

| Field | Value |
|-------|-------|
| Spec title | [TBD] |
| Type | Feature / Campaign / Automation / Integration / Other |
| system_id | [kebab-case-id-v1] |
| Version | v1 |
| Status | draft / approved / in-build / shipped / cancelled |
| Owner | [TBD] |
| Created | [YYYY-MM-DD] |
| Target ship date | [YYYY-MM-DD] |

---

## 1. Problem Statement

> One paragraph. What problem does this build solve and for whom?

[TBD]

---

## 2. Goal & Success Metrics

| Goal | Primary Metric | Target | Measurement Method |
|------|----------------|--------|--------------------|
| [TBD] | [TBD] | [TBD] | [TBD] |

---

## 3. Scope

### In Scope
- [TBD]
- [TBD]

### Out of Scope
- [TBD]

---

## 4. Requirements

### Functional Requirements
| # | Requirement | Priority (MoSCoW) | Notes |
|---|-------------|------------------|-------|
| FR-01 | [TBD] | Must / Should / Could / Won't | [TBD] |
| FR-02 | [TBD] | [TBD] | [TBD] |

### Non-Functional Requirements
| # | Requirement | Notes |
|---|-------------|-------|
| NFR-01 | [e.g., response time < 2s] | [TBD] |

---

## 5. User Stories

```
As a [USER TYPE], I want to [ACTION] so that [OUTCOME].

Acceptance criteria:
- [ ] [criterion 1]
- [ ] [criterion 2]
```

---

## 6. Technical Notes

- Stack / tools: [TBD]
- Dependencies: [TBD]
- Integration points: [TBD]
- Data/privacy considerations: [TBD] 🔒

---

## 7. Resource Estimate

| Resource | Estimate | Notes |
|----------|----------|-------|
| Engineering hours | [TBD] | |
| Design hours | [TBD] | |
| Third-party cost | €[TBD]/mo | |
| Total one-off cost | €[TBD] | |

> Validated by CFO_ENGINE: [GO / CONDITIONAL / NO-GO / TBD]

---

## 8. Risks

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|-----------|
| [TBD] | High/Med/Low | High/Med/Low | [TBD] |

---

## 9. Milestones

| Milestone | Date | Owner | Status |
|-----------|------|-------|--------|
| Spec approved | [TBD] | [TBD] | ⬜ |
| Build started | [TBD] | [TBD] | ⬜ |
| Internal QA | [TBD] | [TBD] | ⬜ |
| Shipped | [TBD] | [TBD] | ⬜ |

---

*Template version: v1 | system_id: build-spec-template-v1*
