# Offer Page Template

> **Usage:** Fill in all `[BRACKETS]`. Remove any section that does not apply. Hand to ASSET_ENGINE or REWRITE_ENGINE to generate/refine copy.

---

## Metadata

| Field | Value |
|-------|-------|
| Offer name | [TBD] |
| ICP | [TBD] |
| Price point | [TBD] |
| Created | [YYYY-MM-DD] |
| Status | draft / active / archived |

---

## 1. Headline

> One sentence. Lead with the transformation, not the mechanism.

```
[HEADLINE — max 12 words]
```

## 2. Sub-headline

> Clarifies who this is for and the core outcome.

```
[SUB-HEADLINE — max 20 words]
```

## 3. Problem Section

> Agitate the pain. Speak to what the prospect is experiencing right now.

**Headline:** [Problem headline]

**Body:**
- [Pain point 1]
- [Pain point 2]
- [Pain point 3]

## 4. Solution Section

> Introduce the offer as the bridge from pain to outcome.

**Headline:** [Solution headline]

**Body:** [2–3 sentences describing the solution mechanism]

## 5. What You Get (Inclusions)

| # | Module / Deliverable | Outcome |
|---|---------------------|---------|
| 1 | [TBD] | [TBD] |
| 2 | [TBD] | [TBD] |
| 3 | [TBD] | [TBD] |

## 6. Social Proof

> Use verified results only (✓). Mark projected outcomes with (~).

- "[Testimonial quote]" — [Name, Title, Company] ✓
- Result: [Specific outcome] ✓
- [NEEDS PROOF] if not yet verified.

## 7. Guarantee

> Specific, operator-controlled, believable.

```
[GUARANTEE STATEMENT]
```

## 8. Pricing

| Tier | Price | Key inclusions |
|------|-------|----------------|
| [TBD] | €[X] | [TBD] |

## 9. Call to Action

**Primary CTA:** [Button text — max 5 words]
**CTA URL:** [TBD]
**Secondary CTA:** [e.g. "Book a call" link]

## 10. FAQ

**Q: [Common objection as question]**
A: [Answer]

**Q: [TBD]**
A: [TBD]

---

*Template version: v1 | system_id: offer-page-template-v1*
