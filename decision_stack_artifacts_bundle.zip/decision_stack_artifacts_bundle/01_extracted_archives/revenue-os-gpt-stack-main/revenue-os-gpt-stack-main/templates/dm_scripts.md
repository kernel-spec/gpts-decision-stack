# DM Scripts Template

> **Usage:** Customise `[BRACKETS]` for each campaign. Deliver personalised version to ASSET_ENGINE. Run through POSITIONING_POLICE before sending at scale.

---

## Metadata

| Field | Value |
|-------|-------|
| Campaign name | [TBD] |
| Channel | LinkedIn / Instagram / Twitter / Email / Other |
| ICP | [TBD] |
| Goal | [e.g., book a call, reply to question, download resource] |
| Created | [YYYY-MM-DD] |
| Status | draft / active / archived |

---

## Script 1 — Cold Outreach (Connection Request or First DM)

**Character limit awareness:** LinkedIn connection note ≤ 300 chars; DM ≤ 2000 chars.

```
Hi [FIRST NAME],

[Personalisation hook — 1 sentence referencing their work, post, or company.]

[Value bridge — 1 sentence connecting their context to your offer.]

[Soft CTA — low-friction ask, not a pitch.]

[YOUR NAME]
```

**Notes:** Do not pitch in the connection request. Lead with curiosity.

---

## Script 2 — Follow-Up (No Response — Day 3)

```
Hi [FIRST NAME],

Just following up on my previous message.

[One new value point or insight relevant to them.]

[Repeat soft CTA.]

[YOUR NAME]
```

---

## Script 3 — Follow-Up (No Response — Day 7)

```
Hi [FIRST NAME],

I'll keep this brief — [ONE SENTENCE value statement].

[Direct question CTA — yes/no answer possible.]

Either way, no pressure. Happy to share more if useful.

[YOUR NAME]
```

---

## Script 4 — Response to "Tell Me More"

```
Hi [FIRST NAME],

Great to hear from you!

[2–3 sentences describing the offer outcome, not the mechanism.]

[Social proof — 1 verified result ✓ or omit if none available.]

Would it make sense to get on a quick [15/30]-min call this week to see if this is relevant for [THEIR COMPANY]?

[CALENDAR LINK or "Let me know a time that works"]

[YOUR NAME]
```

---

## Script 5 — Inbound DM Response (They reached out first)

```
Hi [FIRST NAME],

Thanks for reaching out!

[Acknowledge their question or comment.]

[Answer + next step.]

[CTA]

[YOUR NAME]
```

---

## Personalisation Variables

| Variable | Source | Example |
|----------|--------|---------|
| `[FIRST NAME]` | List enrichment | Jana |
| `[COMPANY]` | List enrichment | Acme s.r.o. |
| `[TRIGGER]` | MARKET_SCOUT_OUTBOUND | "I saw you recently launched X" |
| `[PAIN POINT]` | ICP research | [TBD] |

---

*Template version: v1 | system_id: dm-scripts-template-v1*
