# Audit Report Template

> **Usage:** Complete this template after a revenue/funnel audit session. Use PERFORMANCE_MEMORY data and CFO_ENGINE for financial interpretation.

---

## Metadata

| Field | Value |
|-------|-------|
| Report title | [TBD] |
| Client / Business | [TBD] |
| Audit type | Revenue / Funnel / Email / Ops / Full |
| Period covered | [YYYY-MM-DD] to [YYYY-MM-DD] |
| Author | [TBD] |
| Status | draft / final |
| Created | [YYYY-MM-DD] |

---

## Executive Summary

> 3–5 sentences. State the overall health of the system audited, the top 3 findings, and the single most important recommended action.

[EXECUTIVE SUMMARY — TBD]

---

## 1. Current State Snapshot

| Metric | Value | Benchmark | Status |
|--------|-------|-----------|--------|
| MRR | €[TBD] | [TBD] | [✅/⚠️/❌] |
| Churn rate | [TBD]% | < 5% | [✅/⚠️/❌] |
| CAC | €[TBD] | [TBD] | [✅/⚠️/❌] |
| LTV | €[TBD] | [TBD] | [✅/⚠️/❌] |
| LTV:CAC | [TBD]:1 | ≥ 3:1 | [✅/⚠️/❌] |
| Conversion rate (lead→call) | [TBD]% | [TBD] | [✅/⚠️/❌] |
| Conversion rate (call→close) | [TBD]% | > 25% | [✅/⚠️/❌] |
| Pipeline value | €[TBD] | [TBD] | [✅/⚠️/❌] |

---

## 2. Funnel Audit

### 2.1 Awareness / Top of Funnel

- Traffic sources: [TBD]
- Monthly leads generated: [TBD]
- Top-performing channel: [TBD]
- Gaps identified: [TBD]

### 2.2 Consideration / Middle of Funnel

- Lead magnet conversion rate: [TBD]%
- Email open rate: [TBD]% (benchmark: > 30%)
- Email CTR: [TBD]% (benchmark: > 3%)
- Gaps identified: [TBD]

### 2.3 Decision / Bottom of Funnel

- Discovery call booking rate: [TBD]%
- Close rate: [TBD]%
- Average deal size: €[TBD]
- Gaps identified: [TBD]

---

## 3. Key Findings

| # | Finding | Severity | Impact |
|---|---------|----------|--------|
| 1 | [TBD] | 🔴 High / 🟡 Medium / 🟢 Low | [TBD] |
| 2 | [TBD] | [TBD] | [TBD] |
| 3 | [TBD] | [TBD] | [TBD] |

---

## 4. Recommendations

| Priority | Action | Owner | Deadline | Expected Δ |
|----------|--------|-------|----------|-----------|
| 1 | [TBD] | [TBD] | [TBD] | [TBD] |
| 2 | [TBD] | [TBD] | [TBD] | [TBD] |
| 3 | [TBD] | [TBD] | [TBD] | [TBD] |

---

## 5. Next Review Date

[YYYY-MM-DD]

---

*Template version: v1 | system_id: audit-report-template-v1*
