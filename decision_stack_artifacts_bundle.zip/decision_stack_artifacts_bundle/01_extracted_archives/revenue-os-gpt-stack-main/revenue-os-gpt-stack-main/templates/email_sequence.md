# Email Sequence Template

> **Usage:** Fill in all `[BRACKETS]`. Hand to ASSET_ENGINE for copy generation. Run finished copy through DELIVERABILITY_GUARD before sending.

---

## Metadata

| Field | Value |
|-------|-------|
| Sequence name | [TBD] |
| Trigger | [e.g., opt-in, purchase, no-response day 3] |
| Audience | [ICP description] |
| Goal | [e.g., book a call, purchase, re-engage] |
| Number of emails | [TBD] |
| Created | [YYYY-MM-DD] |
| Status | draft / active / paused / archived |

---

## Email 1 — Welcome / Orientation

**Send time:** Immediately on trigger  
**Goal:** Set expectations, deliver quick win

| Field | Content |
|-------|---------|
| Subject line | [TBD] |
| Preview text | [TBD] |
| From name | [TBD] |

**Body:**

[Greeting + who you are — 1 sentence]

[Core value delivery or welcome message — 2–3 sentences]

[What to expect from this sequence — 1–2 sentences]

[Single CTA]: [CTA text] → [URL/TBD]

---

## Email 2 — Problem / Pain Agitation

**Send time:** Day 1–2  
**Goal:** Deepen resonance with the problem

| Field | Content |
|-------|---------|
| Subject line | [TBD] |
| Preview text | [TBD] |

**Body:**

[Open with a relatable scenario — 2 sentences]

[Name the core pain without over-complicating — 2–3 sentences]

[Bridge sentence to solution]

[CTA]: [TBD]

---

## Email 3 — Solution / Proof

**Send time:** Day 3–4  
**Goal:** Introduce the solution and social proof

| Field | Content |
|-------|---------|
| Subject line | [TBD] |
| Preview text | [TBD] |

**Body:**

[Introduce offer mechanism — 2 sentences]

[Social proof: 1 verified result ✓ or [NEEDS PROOF]]

[How it works — 3-step list]

[CTA]: [TBD]

---

## Email 4 — Objection Handling

**Send time:** Day 5–6  
**Goal:** Address the top objection

| Field | Content |
|-------|---------|
| Subject line | [TBD] |
| Preview text | [TBD] |

**Body:**

[Name the objection directly — 1 sentence]

[Acknowledge + reframe — 2–3 sentences]

[Counter-evidence or case study — 2 sentences]

[CTA]: [TBD]

---

## Email 5 — Urgency / Close

**Send time:** Day 7–8  
**Goal:** Drive final action

| Field | Content |
|-------|---------|
| Subject line | [TBD] |
| Preview text | [TBD] |

**Body:**

[Remind them of the pain cost of inaction — 2 sentences]

[Restate the offer and what they get — 2 sentences]

[Urgency mechanism (deadline / limited spots / price change) — 1 sentence. Use only if genuine.]

[Primary CTA]: [TBD]

---

## Deliverability Checklist

- [ ] All subject lines under 50 characters
- [ ] No spam trigger words
- [ ] Unsubscribe link in footer
- [ ] Plain-text version created
- [ ] Reviewed by DELIVERABILITY_GUARD

---

*Template version: v1 | system_id: email-sequence-template-v1*
