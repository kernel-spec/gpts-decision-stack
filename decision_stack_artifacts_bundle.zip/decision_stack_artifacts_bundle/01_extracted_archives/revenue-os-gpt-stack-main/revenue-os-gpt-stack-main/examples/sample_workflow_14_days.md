# Sample Workflow — 14-Day Launch Sprint

> **system_id:** `ai-ops-cz`  
> **stage:** `build → test`  
> **version:** v1  
> **artifact_type:** sop  
> **Goal:** Go from zero assets to first booked discovery calls in 14 days.

---

## Overview

This workflow demonstrates how the full GPT stack works together during a 14-day launch sprint for a new productized offer targeting Czech operations managers.

---

## Day 1 — Define (SYSTEM_OS_MASTER + STRUCTURAL_ENGINE)

**Morning brief to SYSTEM_OS_MASTER:**
```
system_id: ai-ops-cz
stage: define
Goal: Launch a productized AI ops audit offer for Czech SMB operations managers.
Route tasks accordingly.
```

**STRUCTURAL_ENGINE output:**
- Offer name: AI Ops Audit
- Transformation: Chaotic manual processes → documented, partially automated ops stack
- Tiers:
  | Tier | Price | Inclusions |
  |------|-------|------------|
  | Audit only | €990 | 2-hour audit, written report, 3 priority recommendations |
  | Audit + SOP | €2,490 | Audit + 3 custom SOPs + implementation call |
  | Full retainer | €4,900/mo | Ongoing ops optimisation, weekly check-ins |
- Guarantee: If no automatable process found, full refund.

---

## Day 2 — ICP Research (MARKET_SCOUT_OUTBOUND)

```
Research ICP: Operations managers at Czech SMBs (20–150 employees), 
manufacturing or logistics sector, using manual spreadsheet-based ops.
Give me trigger events and outreach angles.
```

**Output:** Top trigger events:
- Recent LinkedIn post complaining about process chaos
- Job posting for "Operations Coordinator" (growth signal)
- Company recently received funding (need to scale ops)

---

## Day 3 — List Build (LIST_BUILDER)

```
Build a list brief for: Czech ops managers, manufacturing/logistics, 
20–150 employees, LinkedIn Sales Navigator.
Target: 200 verified contacts.
```

**List build brief generated** → executed manually via LinkedIn Sales Navigator.

---

## Day 4 — Asset Creation (ASSET_ENGINE)

```
Write a cold LinkedIn DM sequence (3 messages) for:
ICP: Czech operations manager, 50-person manufacturing company
Offer: AI Ops Audit (€990 entry point)
Angle: Cost of manual ops chaos
```

**Output:** 3-message DM sequence using `/templates/dm_scripts.md` format.

---

## Day 5 — Compliance Review (GOVERNANCE_LIGHT + POSITIONING_POLICE)

```
Review this DM sequence for compliance issues and brand positioning.
[PASTE DM SEQUENCE]
```

**Result:** 🟢 PASS — no income claims, no fabricated social proof, consistent tone.

---

## Day 6 — Deliverability Setup (DELIVERABILITY_GUARD)

```
Audit my email sending setup:
Domain: [domain]
SPF: [record]
DKIM: active
DMARC: p=none
Planned volume: 50/day ramping to 100/day
```

**Output:** Warm-up schedule: 20/day → 50/day → 100/day over 3 weeks.

---

## Day 7 — Experiment Design (EXPERIMENT_DESIGNER)

```
Design an A/B test for my LinkedIn DM opener.
system_id: ai-ops-cz
Control: direct pain opener ("Is ops chaos costing you...?")
Variant: curiosity opener ("Quick question about your ops stack...")
Primary metric: reply_rate
Volume: 100 per variant
```

**Experiment ID:** `EXP__ai-ops-cz__20260227__reply_rate__icp_narrow_it`

---

## Day 8–10 — Outreach Execution

- 200 connection requests sent via LinkedIn.
- 100 DMs sent to accepted connections.
- Replies routed through MARKET_SCOUT_INBOUND for lead scoring.
- Hot leads (score ≥ 9) → CALL_CLOSER for call prep.

---

## Day 11 — First Calls (CALL_CLOSER + OBJECTION_HANDLER)

```
Create a discovery call script for:
Offer: AI Ops Audit (€990)
ICP: Czech ops manager, manufacturing
Duration: 30 min
Top expected objection: "I don't have time to implement anything new."
```

**Call script generated** using `/templates/call_script.md`.  
**Objection response prepared** via OBJECTION_HANDLER.

---

## Day 12–13 — Follow-Up Sequences (ASSET_ENGINE)

```
Write a 3-email follow-up sequence for discovery call no-shows.
Offer: AI Ops Audit
Goal: Re-book the call
```

---

## Day 14 — Weekly Review & Decision

```
Week 2 metrics for ai-ops-cz:
sent: 200, replies: 19, booked: 5, closed: 2, revenue: €1,980
```

**PERFORMANCE_MEMORY output:**
| Metric | Value | Status |
|--------|-------|--------|
| reply_rate | 9.5% | ✅ |
| booked_rate | 26.3% | ✅ |
| close_rate | 40% | ✅ |

**Decision: SCALE** — double outreach volume, build case study from closes.

**Pattern logged to PATTERN_LIBRARY_LOGIC:**
- Cost-of-inaction DM opener outperformed curiosity opener by 2.3× in reply rate.

---

## Log File

Stored at: `/ops/logs/ai-ops-cz/weekly_2026-W09.json`  
Experiment record: `/ops/logs/ai-ops-cz/experiments/EXP__ai-ops-cz__20260227__reply_rate__icp_narrow_it.md`

---

*artifact_id: ai-ops-cz__sop__20260227__14day_launch | stage: build*
