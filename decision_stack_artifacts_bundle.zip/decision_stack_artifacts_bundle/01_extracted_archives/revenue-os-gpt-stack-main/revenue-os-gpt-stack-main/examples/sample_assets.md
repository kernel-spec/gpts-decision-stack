# Sample Assets

> Sample outputs from ASSET_ENGINE and REWRITE_ENGINE for the `ai-ops-cz` system.  
> All outputs are in **Czech** as per the language rule.  
> English instructions are shown above each asset for context.

---

## Asset 1 — LinkedIn DM (Cold Outreach)

**Input to ASSET_ENGINE:**
```
Write a cold LinkedIn DM opener for:
ICP: Czech operations manager, manufacturing company, 50 employees
Offer: AI Ops Audit (€990)
Angle: Cost of manual ops chaos
Tone: Direct, professional
```

**Output (Czech):**

> Dobrý den, [Jméno],
>
> Sleduju váš profil — vedete ops v [Firma] a vidím, že tým roste.
>
> Z naší praxe: ve firmách vaší velikosti zabírají manuální procesy (tabulky, e-mailová koordinace, ruční reporty) průměrně 12–15 hodin týdně vedoucímu ops.
>
> Děláme AI Ops Audit — 2 hodiny, výstup: písemná zpráva + 3 konkrétní místa, kde se dá automatizovat nebo zjednodušit.
>
> Má to smysl prohodit pár vět?
>
> [Vaše jméno]

**Pattern logged:**
```json
{
  "pattern_id": "PAT-001",
  "system_id": "ai-ops-cz",
  "icp": "ops manager, manufacturing, CZ, 20-150 employees",
  "channel": "dm",
  "asset_type": "outreach",
  "angle": "cost-of-manual-ops-chaos",
  "cta": "soft question CTA",
  "conversion_rate": "reply_rate: 9.5%",
  "status": "active",
  "notes": "Outperformed curiosity opener by 2.3x in week 2 test."
}
```

---

## Asset 2 — Email Subject Lines (A/B Test)

**Input to REWRITE_ENGINE:**
```
Give me 3 subject line variants for a cold email targeting Czech ops managers.
Primary metric: open rate
Angle: ops chaos cost / time waste
```

**Output (Czech):**

| Variant | Subject line | Preview text |
|---------|-------------|-------------|
| A (Control) | Kolik vás stojí ruční procesy? | Spočítali jsme to za vás — 2 min. |
| B | [Jméno], tohle se děje ve vaší ops každý týden | A pravděpodobně o tom nevíte. |
| C | Audit vašich ops procesů — zdarma odhad | Bez závazku, výstup do 48 hodin. |

**Winner after test:** Variant B — open rate 41.2% vs. 28.5% (Control).  
**Pattern logged:** Personalised subject lines with implicit revelation outperform direct question openers for this ICP.

---

## Asset 3 — Offer Page Headline (Rewrite)

**Input to REWRITE_ENGINE:**
```
Original headline: "AI Ops Audit pro vaši firmu"
Rewrite for higher specificity and urgency.
ICP: Czech ops manager
Tone: Direct
```

**ORIGINAL:**
> AI Ops Audit pro vaši firmu

**REWRITE:**
> Zjistěte za 2 hodiny, kde vám ops procesy brzdí růst — a co s tím udělat jako první.

**Rationale:** Leads with time-specificity (2 hodiny) and outcome (zjistěte kde brzdí), adds action orientation (co s tím udělat).

---

## Asset 4 — Objection Response (Live Call)

**Input to OBJECTION_HANDLER:**
```
Objection: "Nemám teď čas řešit implementaci."
Context: live discovery call
Offer: AI Ops Audit (€990)
```

**Output (Czech):**

> "Rozumím — proto jsme audit navrhli tak, aby nekladl žádné nároky na váš čas při implementaci. Výstupem je zpráva s prioritami: řekneme vám, co udělat první, a vy se rozhodnete, co a kdy spustíte. Samotný audit zabere 2 hodiny vašeho času — a to je vše. Dáte mi vědět, jestli 2 hodiny v příštích 2 týdnech by se daly najít?"

**Framework used:** FEEL-FELT-FOUND + reframe → time objection addressed by minimising implementation burden, not dismissing it.

---

## Asset 5 — Pattern Record (JSON)

Stored at: `/ops/logs/ai-ops-cz/experiments/EXP__ai-ops-cz__20260227__reply_rate__icp_narrow_it.md`

```json
{
  "pattern_id": "PAT-002",
  "system_id": "ai-ops-cz",
  "icp": "ops manager, manufacturing, CZ, 20-150 employees",
  "channel": "email",
  "asset_type": "outreach",
  "angle": "personalised-revelation",
  "cta": "call booking",
  "conversion_rate": "open_rate: 41.2%",
  "context": "Week 2 A/B test, 200 sends per variant",
  "status": "active",
  "notes": "Variant B won. Personalised subject + implicit revelation outperforms direct question for this ICP."
}
```

---

*artifact_id: ai-ops-cz__pattern__20260227__sample_assets | stage: test*
