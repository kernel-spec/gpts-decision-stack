# Changelog

All notable changes to the Revenue OS GPT Stack are documented here.  
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).  
Versioning follows [Semantic Versioning](https://semver.org/).

---

## [Unreleased]

### Added
- Repository scaffold with full folder structure.
- 12 core prompt files under `/prompts/core/` (lowercase_underscore naming).
- 2 market scout prompt files under `/prompts/scouts/`.
- 10 add-on prompt files under `/prompts/addons/`.
- Templates under `/templates/` (offer_page, email_sequence, dm_scripts, call_script, audit_report, build_spec, weekly_log, pattern_record.json).
- Ops files: `daily_cheatsheet.md`, `weekly_review.md`, `metric_definitions.md`, `naming_conventions.md`.
- JSON schemas: `weekly_log.schema.json`, `pattern_record.schema.json` under `/ops/schemas/`.
- Log directory structure: `/ops/logs/{system_id}/weekly_{YYYY}-W{WW}.json`.
- GitHub Issue templates: `experiment.md`, `weekly_review.md`, `new_offer.md`.
- Example workflows: `sample_workflow_14_days.md`, `sample_assets.md`.
- Full naming conventions: system_id (`{topic}-{geo}-{segment}`), artifact_id, experiment_id, stage, artifact_type.
- [TBD] and [TBD proof] policy with risk flag requirement for critical fields.

### Changed
- Prompt files renamed from UPPERCASE to `lowercase_underscores` per file naming standard.
- `templates/pattern_record.json` updated to match `pattern_record.schema.json` field structure.
- README updated with new naming conventions, correct file links, system_id examples, and schema references.

---

## [1.0.0] — 2026-02-27

### Added
- Repository initialised.

