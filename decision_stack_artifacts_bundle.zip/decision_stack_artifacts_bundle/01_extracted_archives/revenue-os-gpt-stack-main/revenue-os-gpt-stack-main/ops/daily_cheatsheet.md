# Daily Cheatsheet

> **Start here every morning.** This is your 15-minute Revenue OS daily routine.  
> All GPT inputs are in English. All GPT outputs are delivered in Czech.

---

## Morning Routine (15 min)

### Step 1 — Orient (2 min)

Open `SYSTEM_OS_MASTER` and paste:

```
Morning briefing. My system_id is [YOUR SYSTEM_ID]. 
Today's date: [DATE].
Current stage: [define / build / test / iterate / scale].
Top priority today: [ONE SENTENCE].
Route accordingly.
```

---

### Step 2 — Metrics Check (3 min)

Open `PERFORMANCE_MEMORY` and paste last week's numbers:

```
Update metrics for [system_id], week [YYYY-W##]:
- sent: [X]
- replies: [X]
- booked: [X]
- closed: [X]
- revenue: €[X]
Flag any off-trend metrics.
```

→ If reply_rate < 4%: route to REWRITE_ENGINE (subject lines / openers)  
→ If close_rate < 20%: route to CALL_CLOSER or OBJECTION_HANDLER  
→ If churn > 5%: route to RETENTION_ENGINE  

---

### Step 3 — Assign the Day (5 min)

Pick 1–3 tasks from your weekly priorities. Match each to a GPT:

| Task type | GPT to open |
|-----------|-------------|
| Write / update copy | ASSET_ENGINE → REWRITE_ENGINE |
| Review copy for brand | POSITIONING_POLICE |
| Stress-test a decision | CFO_ENGINE |
| Design an experiment | EXPERIMENT_DESIGNER |
| Build an outreach list | MARKET_SCOUT_OUTBOUND → LIST_BUILDER |
| Score inbound leads | MARKET_SCOUT_INBOUND |
| Handle objections | OBJECTION_HANDLER |
| Prepare for a call | CALL_CLOSER |
| Build / update SOP | DELIVERY_SOP_ENGINE |
| Automate something | OPS_AUTOMATOR |
| Capture a pattern | PATTERN_LIBRARY_LOGIC |
| Price a new offer | PRICING_PACKAGER |
| Spec a feature | SAAS_FEATURE_PACK_ENGINE |
| Enterprise deal | ENTERPRISE_LAYER |
| Compliance check | GOVERNANCE_LIGHT |
| Budget allocation | CAPITAL_ALLOCATOR |

---

### Step 4 — Execute & Log (5 min at end of day)

At end of day, log your key outputs:

```
Log to PATTERN_LIBRARY_LOGIC:
- pattern_id: [auto / next number]
- system_id: [YOUR SYSTEM_ID]
- type: [subject_line / hook / offer / objection_response / pricing / cta]
- content: [PASTE]
- metric: [open_rate / reply_rate / close_rate]: [X]%
- channel: [email / dm / call / landing_page]
```

---

## Weekly Rhythm

| Day | Focus |
|-----|-------|
| Monday | Weekly log review → set 3 priorities |
| Tuesday–Thursday | Execute: build assets, run outreach, close deals |
| Friday | Log metrics → open Weekly Review GitHub Issue |

---

## Copy-Paste Prompts

### Quick rewrite
```
Rewrite this [email subject / headline / CTA] for higher [open rate / reply rate / clicks].
Keep it under [X] words. Tone: [direct / conversational / professional].
Original: [PASTE]
```

### Quick objection response
```
Give me 3 responses to the objection: "[OBJECTION]"
Context: [DM / email / live call]
Offer type: [DESCRIBE BRIEFLY]
```

### Quick experiment brief
```
Design an A/B test for [ELEMENT] targeting [METRIC].
system_id: [YOUR SYSTEM_ID]
Current baseline: [X]%
I can run it for [X] days with [X] volume.
```

### Quick CFO gate
```
Stress-test this decision: [DESCRIBE DECISION].
Capital at risk: €[X].
My current MRR: €[X]. Reserves: €[X].
Give me base / upside / downside scenario and a GO/NO-GO.
```

---

## Key Links

- [Weekly Review template](../templates/weekly_log.md)
- [Metric definitions](metric_definitions.md)
- [Naming conventions](naming_conventions.md)
- [Pattern record schema](schemas/pattern_record.schema.json)
- [Weekly log schema](schemas/weekly_log.schema.json)

---

*system_id: daily-cheatsheet-v1 | artifact_type: sop*
