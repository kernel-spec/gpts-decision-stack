# Metric Definitions

> Version: v1 | Last updated: 2026-02-27  
> Source of truth for all metrics tracked in PERFORMANCE_MEMORY and weekly logs.

---

## Core Outreach Metrics

### reply_rate
- **Definition:** Percentage of outreach messages that received any reply (positive, negative, or neutral).
- **Formula:** `replies / sent × 100`
- **Thresholds:**
  - ✅ Good: ≥ 8%
  - ⚠️ Watch: 4–7%
  - ❌ Fix: < 4%
- **Notes:** Measure per channel separately. Cold email and LinkedIn DMs have different benchmarks.

### booked_rate
- **Definition:** Percentage of replies that converted to a booked discovery/strategy call.
- **Formula:** `booked / replies × 100`
- **Thresholds:**
  - ✅ Good: ≥ 25%
  - ⚠️ Watch: 15–24%
  - ❌ Fix: < 15%
- **Notes:** Low booked_rate usually indicates a CTA problem or ICP mismatch, not a copy problem.

### close_rate
- **Definition:** Percentage of calls held that resulted in a closed deal (signed contract or payment received).
- **Formula:** `closed / calls_held × 100`
- **Thresholds:**
  - ✅ Good: ≥ 30%
  - ⚠️ Watch: 20–29%
  - ❌ Fix: < 20%
- **Notes:** Distinguish between discovery calls (lower close rate expected) and closing calls (higher expected).

---

## Revenue Metrics

### MRR (Monthly Recurring Revenue)
- **Definition:** Total predictable recurring revenue in a given month.
- **Formula:** Sum of all active monthly subscription / retainer payments.
- **Notes:** One-off payments do not count toward MRR.

### ARR (Annual Recurring Revenue)
- **Formula:** `MRR × 12`

### Churn Rate (MRR)
- **Definition:** Percentage of MRR lost in a month due to cancellations or downgrades.
- **Formula:** `churned_MRR / starting_MRR × 100`
- **Thresholds:**
  - ✅ Good: < 2%
  - ⚠️ Watch: 2–5%
  - ❌ Fix: > 5%

### Net Revenue Retention (NRR)
- **Definition:** MRR retained plus expansion revenue, as a percentage of starting MRR.
- **Formula:** `(starting_MRR - churned_MRR + expansion_MRR) / starting_MRR × 100`
- **Thresholds:**
  - ✅ Good: ≥ 100% (expansion covers churn)
  - ⚠️ Watch: 90–99%
  - ❌ Fix: < 90%

---

## Unit Economics

### CAC (Customer Acquisition Cost)
- **Definition:** Total cost to acquire one new paying customer.
- **Formula:** `total_acquisition_spend / new_customers`
- **Includes:** Ad spend, sales time (valued at hourly rate), tool costs attributed to acquisition.

### LTV (Customer Lifetime Value)
- **Definition:** Total revenue expected from one customer over their lifetime.
- **Formula:** `average_contract_value × average_retention_months`
- **Notes:** Use conservative (actual historical) retention data where available.

### LTV:CAC Ratio
- **Formula:** `LTV / CAC`
- **Thresholds:**
  - ✅ Good: ≥ 3:1
  - ⚠️ Watch: 2:1–2.9:1
  - ❌ Fix: < 2:1

### Payback Period
- **Definition:** Months to recoup CAC from gross margin.
- **Formula:** `CAC / (monthly_revenue_per_customer × gross_margin_pct)`
- **Thresholds:**
  - ✅ Good: ≤ 6 months
  - ⚠️ Watch: 7–12 months
  - ❌ Fix: > 12 months

---

## Email Metrics

### Open Rate
- **Thresholds:** ✅ ≥ 35% | ⚠️ 25–34% | ❌ < 25%

### Click-Through Rate (CTR)
- **Thresholds:** ✅ ≥ 3% | ⚠️ 1–2.9% | ❌ < 1%

### Bounce Rate (hard)
- **Thresholds:** ✅ < 1% | ⚠️ 1–2% | ❌ > 2%

### Unsubscribe Rate
- **Thresholds:** ✅ < 0.2% | ⚠️ 0.2–0.5% | ❌ > 0.5%

---

## Pipeline Metrics

### Pipeline Value
- **Definition:** Sum of deal values for all active opportunities in the pipeline.

### Pipeline Coverage
- **Definition:** Pipeline value as a multiple of MRR target.
- **Target:** ≥ 3× monthly revenue goal.

---

## Metric Log Format

When logging metrics to `/ops/logs/{system_id}/weekly_{YYYY}-W{WW}.json`, use the schema at  
`/ops/schemas/weekly_log.schema.json`.

---

*system_id: metric-definitions-v1 | artifact_type: metrics*
