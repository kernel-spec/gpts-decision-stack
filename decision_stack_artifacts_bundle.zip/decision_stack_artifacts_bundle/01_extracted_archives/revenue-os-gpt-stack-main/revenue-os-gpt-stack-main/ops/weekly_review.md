# Weekly Review

> Complete every Friday. Open a GitHub Issue using `.github/ISSUE_TEMPLATE/weekly_review.md`.  
> Log JSON data to `/ops/logs/{system_id}/weekly_{YYYY}-W{WW}.json` using the schema at `/ops/schemas/weekly_log.schema.json`.

---

## Purpose

The weekly review is the governance heartbeat of the Revenue OS stack.  
It ensures that every system_id has a documented decision each week:  
**SCALE** (working — do more), **OPTIMIZE** (directionally right — improve), or **KILL** (not working — stop/pivot).

---

## Review Protocol

### 1. Pull metrics from PERFORMANCE_MEMORY

```
Show me the weekly scorecard for [system_id], week [YYYY-W##].
Compare to prior week. Flag anything off-trend.
```

### 2. Identify the constraint

Ask: _What is the single biggest thing preventing more revenue this week?_

Map to stage:
- **define** → ICP or offer not clear enough → STRUCTURAL_ENGINE
- **build** → assets not ready → ASSET_ENGINE
- **test** → no data yet → EXPERIMENT_DESIGNER
- **iterate** → data exists, need optimisation → REWRITE_ENGINE or OBJECTION_HANDLER
- **scale** → working → CAPITAL_ALLOCATOR or OPS_AUTOMATOR

### 3. Log patterns

Any copy, angle, or script that outperformed → log to PATTERN_LIBRARY_LOGIC.

### 4. Set 3 priorities for next week (max 3)

| Priority | Action | Owner | GPT |
|----------|--------|-------|-----|
| 1 | [TBD] | [TBD] | [TBD] |
| 2 | [TBD] | [TBD] | [TBD] |
| 3 | [TBD] | [TBD] | [TBD] |

### 5. Issue Decision

| Decision | Criteria |
|----------|---------|
| **SCALE** | reply_rate ≥ 8%, close_rate ≥ 30%, MRR growing |
| **OPTIMIZE** | Metrics directional but below threshold |
| **KILL** | No traction after 2+ weeks at `test` stage |

---

## Example JSON Log

```json
{
  "system_id": "ai-ops-cz",
  "week_range": "2026-W09",
  "version": "v1",
  "artifact_type": "log",
  "stage": "test",
  "metrics": {
    "sent": 120,
    "replies": 11,
    "booked": 3,
    "closed": 1,
    "revenue": 4900,
    "reply_rate": 9.2,
    "booked_rate": 27.3,
    "close_rate": 33.3
  },
  "decision": "SCALE",
  "pattern_notes": "Subject line with cost-of-inaction angle outperformed by 2.1×.",
  "next_week_focus": [
    "Double outreach volume to 240/week",
    "A/B test new ICP segment: ops managers vs. CEOs",
    "Build case study from week 9 close"
  ],
  "links": [
    "ops/logs/ai-ops-cz/experiments/EXP__ai-ops-cz__20260227__reply_rate__icp_narrow_it.md"
  ]
}
```

---

*system_id: weekly-review-v1 | artifact_type: sop*
