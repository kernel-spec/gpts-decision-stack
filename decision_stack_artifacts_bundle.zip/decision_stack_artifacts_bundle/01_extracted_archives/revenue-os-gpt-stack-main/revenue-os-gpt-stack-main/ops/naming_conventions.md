# Naming Conventions

> Version: v1 | Last updated: 2026-02-27

All identifiers in this stack follow strict conventions to ensure consistency across GPT prompts, artifacts, logs, experiments, and repo files.

---

## Repo Naming

| Variant | Name |
|---------|------|
| Main repo | `revenue-os-gpt-stack` |
| Internal fork | `revenue-os-gpt-stack-internal` |
| Public fork | `revenue-os-gpt-stack-public` |

---

## Branching

| Branch | Purpose |
|--------|---------|
| `main` | Stable release — only merged, reviewed content |
| `dev` | Active work / drafts |
| Release tags | `v0.1.0`, `v0.2.0`, … (repo releases only — do not confuse with offer/prompt `v1`, `v2`) |

---

## Folder Structure

| Path | Contents |
|------|---------|
| `/prompts/core/` | Core role GPTs |
| `/prompts/scouts/` | Web research / market intelligence GPTs |
| `/prompts/addons/` | Specialist add-on roles |
| `/templates/` | Output templates (offer, email, report, …) |
| `/ops/` | Operations (cheatsheet, naming, metrics, SOP) |
| `/ops/schemas/` | JSON schemas |
| `/ops/logs/` | Weekly logs and experiment records (per system_id) |
| `/examples/` | Sample workflows and asset outputs |

---

## system_id

- **Format:** kebab-case
- **Rule:** `{topic}-{geo}-{segment}` — minimum 2 parts
- **Examples:**

| system_id | Meaning |
|-----------|---------|
| `ai-ops-cz` | AI ops stack, Czech market |
| `revops-audit-eu` | Revenue ops audit, EU segment |
| `li-content-b2b` | LinkedIn content, B2B segment |

> Use system_id as the primary key linking prompts, logs, patterns, and experiments together.

---

## version

- Prompt / offer / asset version: `v1`, `v2`, `v3` …  
- Repo release tag: `v0.1.0`, `v0.2.0` …  
- **Do not mix.** A prompt at `v2` and the repo at `v0.2.0` are independent versioning axes.

---

## artifact_id (recommended)

- **Format:** `{system_id}__{artifact_type}__{yyyymmdd}__{short}`
- **Examples:**

| artifact_id | Description |
|-------------|-------------|
| `ai-ops-cz__email1__20260227__overhead` | First email in overhead-reduction campaign |
| `revops-audit-eu__offer__20260301__starter` | Starter offer artifact |

---

## experiment_id

- **Format:** `EXP__{system_id}__{yyyymmdd}__{target_metric}__{brief}`
- **Examples:**

| experiment_id | Description |
|---------------|-------------|
| `EXP__ai-ops-cz__20260227__reply_rate__icp_narrow_it` | ICP narrowing test for IT segment |
| `EXP__revops-audit-eu__20260315__close_rate__guarantee_reframe` | Guarantee reframe test |

---

## artifact_type (allowed values)

| Value | Used for |
|-------|---------|
| `offer` | Offer structures and pages |
| `structure` | Product/programme architecture |
| `outreach` | Cold outreach copy (DM, email) |
| `rewrite` | Rewritten copy variants |
| `diagnosis` | Audit reports and diagnoses |
| `metrics` | Metric snapshots and scorecards |
| `log` | Weekly logs |
| `allocation` | Capital/budget allocation outputs |
| `gate` | CFO gate decisions |
| `pattern` | Pattern records |
| `spec` | Build specifications |
| `enterprise` | Enterprise contract/compliance docs |
| `sop` | Standard operating procedures |
| `automation` | Automation blueprints |

---

## stage (allowed values)

| Value | Meaning |
|-------|---------|
| `define` | Problem and ICP not yet fully validated |
| `build` | Assets and systems being built |
| `test` | Running experiments to validate |
| `iterate` | Optimising based on test results |
| `scale` | Proven system being scaled |

---

## [TBD] Policy

- Use `[TBD]` when a fact, value, or proof has not yet been established.  
- Use `[TBD proof]` specifically when a claim exists but supporting evidence has not been collected.  
- **Critical field rule:** If `[TBD]` or `[TBD proof]` appears in any of the following fields, the output **must** include a `⚠️ RISK FLAG`:
  - CFO gate decisions (pricing claims, revenue projections)
  - Offer guarantee language
  - Income/results claims in marketing copy
  - LTV:CAC or payback period calculations

**Example:**
```
price: €4,900 [TBD proof — no market validation yet]
⚠️ RISK FLAG: pricing claim unvalidated. Run PRICING_PACKAGER before publishing.
```

---

## File Naming (repo files)

### Prompt files
- Use `lowercase_underscores`, no version in filename (version lives in file header and CHANGELOG).

```
/prompts/core/system_os_master.md
/prompts/core/structural_engine.md
/prompts/addons/call_closer.md
/prompts/scouts/market_scout_outbound.md
```

### Template files
```
/templates/email_sequence.md
/templates/offer_page.md
/templates/build_spec.md
/templates/weekly_log.md
/templates/pattern_record.json
```

### Log files (if stored in repo)
```
/ops/logs/{system_id}/weekly_{YYYY}-W{WW}.json
/ops/logs/{system_id}/experiments/{experiment_id}.md
```

**Examples:**
```
/ops/logs/ai-ops-cz/weekly_2026-W09.json
/ops/logs/ai-ops-cz/experiments/EXP__ai-ops-cz__20260227__reply_rate__icp_narrow_it.md
```

---

*system_id: naming-conventions-v1 | artifact_type: sop*
