# Revenue OS — GPT Stack

A structured prompt library and operating system for a portfolio of Custom GPT roles.  
All prompt inputs are written in **English**; all GPT outputs are delivered in **Czech**.

---

## Table of Contents

1. [Overview](#overview)
2. [Repository Structure](#repository-structure)
3. [How to Use Daily](#how-to-use-daily)
4. [GPT Roles](#gpt-roles)
   - [Core GPTs](#core-gpts)
   - [Scout GPTs](#scout-gpts)
   - [Add-on GPTs](#add-on-gpts)
5. [Conventions](#conventions)
6. [Templates](#templates)
7. [Examples](#examples)
8. [Tooling & Schemas](#tooling--schemas)
9. [Contributing](#contributing)
10. [License](#license)

---

## Overview

Revenue OS GPT Stack is a modular operating system built on top of Custom GPT roles.  
Each role has a dedicated system prompt, conversation starters, and builder settings stored under `/prompts/`.  
Supporting templates, operational checklists, and JSON schemas live in `/templates/`, `/ops/`, and `/ops/schemas/`.

---

## Repository Structure

```
revenue-os-gpt-stack/
├── prompts/
│   ├── core/                  # 12 core orchestration + structural GPTs
│   ├── scouts/                # Market intelligence GPTs
│   └── addons/                # 10 specialist add-on GPTs
├── templates/                 # Reusable output templates
├── ops/                       # Daily & weekly operating procedures
│   ├── schemas/               # JSON schemas for logs and records
│   └── logs/                  # Per-system_id weekly logs and experiments
├── examples/                  # Sample workflows and assets
├── .github/
│   └── ISSUE_TEMPLATE/        # GitHub Issue templates
├── CHANGELOG.md
├── LICENSE
└── README.md
```

---

## How to Use Daily

> **Start here →** [/ops/daily_cheatsheet.md](ops/daily_cheatsheet.md)

The daily cheatsheet walks you through the recommended 15-minute morning routine:

1. Open the `system_os_master` GPT as your orchestrator.
2. Run a quick metrics check using `performance_memory`.
3. Assign the day's tasks to specialist GPTs.
4. Log outcomes in `/ops/weekly_review.md` at end-of-day.

See also: [weekly_review.md](ops/weekly_review.md) and [metric_definitions.md](ops/metric_definitions.md).

---

## GPT Roles

### Core GPTs

| File | Role | system_id |
|------|------|-----------|
| [system_os_master](prompts/core/system_os_master.md) | Orchestrator — routes tasks to specialist GPTs | `system-os-master-v1` |
| [structural_engine](prompts/core/structural_engine.md) | Builds offer/product structures | `structural-engine-v1` |
| [asset_engine](prompts/core/asset_engine.md) | Creates sales & marketing assets | `asset-engine-v1` |
| [suggestion_engine](prompts/core/suggestion_engine.md) | Generates strategic suggestions | `suggestion-engine-v1` |
| [rewrite_engine](prompts/core/rewrite_engine.md) | Rewrites and improves copy | `rewrite-engine-v1` |
| [performance_memory](prompts/core/performance_memory.md) | Tracks and recalls key metrics | `performance-memory-v1` |
| [governance_light](prompts/core/governance_light.md) | Lightweight compliance & policy guard | `governance-light-v1` |
| [capital_allocator](prompts/core/capital_allocator.md) | Budget & capital allocation advisor | `capital-allocator-v1` |
| [cfo_engine](prompts/core/cfo_engine.md) | CFO gate — financial stress-testing | `cfo-engine-v1` |
| [pattern_library_logic](prompts/core/pattern_library_logic.md) | Captures and surfaces winning patterns | `pattern-library-logic-v1` |
| [saas_feature_pack_engine](prompts/core/saas_feature_pack_engine.md) | Specs SaaS features and packages | `saas-feature-pack-engine-v1` |
| [enterprise_layer](prompts/core/enterprise_layer.md) | Enterprise contract & compliance layer | `enterprise-layer-v1` |

### Scout GPTs

| File | Role | system_id |
|------|------|-----------|
| [market_scout_outbound](prompts/scouts/market_scout_outbound.md) | Outbound market research & prospecting | `market-scout-outbound-v1` |
| [market_scout_inbound](prompts/scouts/market_scout_inbound.md) | Inbound signal analysis & lead scoring | `market-scout-inbound-v1` |

### Add-on GPTs

| File | Role | system_id |
|------|------|-----------|
| [list_builder](prompts/addons/list_builder.md) | Builds and segments prospect lists | `list-builder-v1` |
| [deliverability_guard](prompts/addons/deliverability_guard.md) | Email deliverability audit & fixes | `deliverability-guard-v1` |
| [objection_handler](prompts/addons/objection_handler.md) | Generates objection-handling scripts | `objection-handler-v1` |
| [call_closer](prompts/addons/call_closer.md) | Discovery/closing call frameworks | `call-closer-v1` |
| [pricing_packager](prompts/addons/pricing_packager.md) | Pricing strategy & packaging | `pricing-packager-v1` |
| [delivery_sop_engine](prompts/addons/delivery_sop_engine.md) | Delivery SOPs and onboarding flows | `delivery-sop-engine-v1` |
| [retention_engine](prompts/addons/retention_engine.md) | Retention campaigns and churn prevention | `retention-engine-v1` |
| [experiment_designer](prompts/addons/experiment_designer.md) | Designs and logs A/B experiments | `experiment-designer-v1` |
| [positioning_police](prompts/addons/positioning_police.md) | Enforces brand & positioning rules | `positioning-police-v1` |
| [ops_automator](prompts/addons/ops_automator.md) | Automation blueprints and SOPs | `ops-automator-v1` |

---

## Conventions

### system_id Format
kebab-case, pattern: `{topic}-{geo}-{segment}` (minimum 2 parts).

| Example | Meaning |
|---------|---------|
| `ai-ops-cz` | AI ops stack, Czech market |
| `revops-audit-eu` | Revenue ops audit, EU segment |
| `li-content-b2b` | LinkedIn content, B2B segment |

### Versioning
- Prompt / offer / asset: `v1`, `v2`, `v3` …
- Repo release tags: `v0.1.0`, `v0.2.0` … — **do not mix these two axes.**

### artifact_id (recommended)
Format: `{system_id}__{artifact_type}__{yyyymmdd}__{short}`  
Example: `ai-ops-cz__email1__20260227__overhead`

### experiment_id
Format: `EXP__{system_id}__{yyyymmdd}__{target_metric}__{brief}`  
Example: `EXP__ai-ops-cz__20260227__reply_rate__icp_narrow_it`

### artifact_type (allowed values)
`offer` · `structure` · `outreach` · `rewrite` · `diagnosis` · `metrics` · `log` · `allocation` · `gate` · `pattern` · `spec` · `enterprise` · `sop` · `automation`

### stage (allowed values)
`define` · `build` · `test` · `iterate` · `scale`

### File Naming
All repo files: `lowercase_underscores`, no version suffix in filename.  
Versions belong in the file header and in CHANGELOG.

### [TBD] Policy
- Use `[TBD]` when a fact or value is not yet established.
- Use `[TBD proof]` when a claim exists but evidence hasn't been collected.
- If `[TBD]` or `[TBD proof]` appears in a critical field (CFO gate, pricing claim, guarantee), the output **must** include a `⚠️ RISK FLAG`.

### Claims & Proof Policy
- **Verified claims** (backed by data) → mark `✓`
- **Projected claims** (estimates) → mark `~`
- **Unverified claims** → mark `[NEEDS PROOF]` — do not publish as-is.

See full rules: [naming_conventions.md](ops/naming_conventions.md)

---

## Templates

| Template | Purpose |
|----------|---------|
| [offer_page.md](templates/offer_page.md) | Sales/offer page copy structure |
| [email_sequence.md](templates/email_sequence.md) | Multi-email nurture sequence |
| [dm_scripts.md](templates/dm_scripts.md) | Direct message outreach scripts |
| [call_script.md](templates/call_script.md) | Discovery and closing call script |
| [audit_report.md](templates/audit_report.md) | Revenue / funnel audit report |
| [build_spec.md](templates/build_spec.md) | Product / feature build specification |
| [weekly_log.md](templates/weekly_log.md) | Weekly performance log |
| [pattern_record.json](templates/pattern_record.json) | Pattern record (JSON) |

---

## Examples

- [sample_workflow_14_days.md](examples/sample_workflow_14_days.md) — A 14-day launch sprint using the full GPT stack (`ai-ops-cz` system).
- [sample_assets.md](examples/sample_assets.md) — Sample outputs from `asset_engine` and `rewrite_engine` with pattern records.

---

## Tooling & Schemas

JSON schemas for structured logging live in `/ops/schemas/`:

| Schema | Description |
|--------|-------------|
| [weekly_log.schema.json](ops/schemas/weekly_log.schema.json) | Schema for weekly log JSON payloads |
| [pattern_record.schema.json](ops/schemas/pattern_record.schema.json) | Schema for pattern record JSON |

Log files are stored per system_id:
```
/ops/logs/{system_id}/weekly_{YYYY}-W{WW}.json
/ops/logs/{system_id}/experiments/{experiment_id}.md
```

GitHub Issue templates are in `/.github/ISSUE_TEMPLATE/`:
- **experiment.md** — for logging A/B experiments (`EXP__{system_id}__…`)
- **weekly_review.md** — for structured weekly review issues (`WEEKLY__{system_id}__…`)
- **new_offer.md** — for defining new productized offers (`OFFER__{system_id}__v1`)

---

## Contributing

1. Fork the repo and create a feature branch off `dev`.
2. Follow the [naming_conventions.md](ops/naming_conventions.md) for all new files.
3. Set prompt status to `draft` until reviewed.
4. Open a PR targeting `dev`; merge to `main` only on stable release.

---

## License

MIT — see [LICENSE](LICENSE).
