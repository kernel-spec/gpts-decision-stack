---
name: Experiment
about: Run a focused test with clear hypothesis, metric, and stop rules.
title: "EXP__{system_id}__{yyyymmdd}__{metric}__{brief}"
labels: ["experiment"]
assignees: []
---

## System
- system_id:
- version:
- stage: test/iterate

## Hypothesis
(If we change X, then metric Y will improve because Z.)

## Change
- Control:
- Variant:

## Metric & Target
- primary_metric:
- target:

## Sample Size / Duration
- volume_needed:
- timeframe:

## Stop Rules
- Kill if:
- Promote if:
- Iterate if:

## Execution Checklist
- [ ] Assets prepared
- [ ] List ready
- [ ] Tracking set
- [ ] Launched

## Results
- sent:
- replies:
- booked:
- closed:
- revenue:

## Decision
SCALE / OPTIMIZE / KILL

## Notes
-
