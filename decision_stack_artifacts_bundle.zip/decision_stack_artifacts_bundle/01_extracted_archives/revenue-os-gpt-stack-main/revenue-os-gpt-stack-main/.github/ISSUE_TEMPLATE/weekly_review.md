---
name: Weekly Review
about: Weekly governance snapshot and next-week focus.
title: "WEEKLY__{system_id}__{YYYY}-W{WW}"
labels: ["weekly-review"]
assignees: []
---

## Snapshot
- system_id:
- version:
- week_range:
- stage:

## Metrics
- sent:
- replies:
- booked:
- closed:
- revenue:
- reply_rate:
- booked_rate:
- close_rate:

## What Worked
-

## What Didn't
-

## Decision
SCALE / OPTIMIZE / KILL

## Next Week Focus (max 3)
1.
2.
3.

## Links
- assets:
- logs:
- patterns:
