---
name: New Offer
about: Define a new productized offer with ICP, contract, scope lock, and 14-day plan.
title: "OFFER__{system_id}__v1"
labels: ["offer"]
assignees: []
---

## Problem
-

## ICP
- job title:
- industry:
- size:
- trigger:

## Desired Transformation
Before → After

## Output Contract
- deliverables:
- timeline:
- format:

## Scope Lock
- included:
- excluded:

## Monetization Model
- price:
- upsell:
- risk reversal:

## 14-Day Execution Plan
-

## Validation Metric
-

## Kill Criteria
-
