# 🧾 META Knowledge – README + Export Format

Tento soubor slučuje hlavní README a systémové exportní formáty pro referenci.



---

## README_FULL_KNOWLEDGE.md

# GPT_Architect – Full Knowledge Bundle

Tento balíček obsahuje všech 20 knowledge souborů používaných GPT_Architectem.

## Seznam souborů

- 01_CORE_MODULY_BUILD_INSTRUCTIONS.md
- 01_CORE_MODULY_LINTER.md
- 01_CORE_MODULY_VALIDATE.md
- 01_CORE_MODULY_TEST_SUITE.md
- 01_CORE_MODULY_AB_WINNER.md
- 01_CORE_MODULY_MODEL_SELECTOR.md
- 01_CORE_MODULY_EXPORTER.md
- 01_CORE_MODULY_FINAL_DELIVERY.md
- 01_CORE_MODULY_OBSERVABILITY.md
- 01_CORE_MODULY_AUTO_GENERATE_GPT.md
- 02_SUPPORT_SCORING_MODEL.md
- 02_SUPPORT_SELF_CHECK.md
- 02_SUPPORT_ROUTING_EVIDENCE_TRIGGERS.md
- 02_INS_CONFIG.md
- 03_AUD_CONFIG.md
- 03_LIBRARY_PROMPT_LIBRARY.md
- 03_LIBRARY_PIPELINE_EXAMPLES.md
- 03_LIBRARY_OUTPUT_TEMPLATES.md
- 03_LIBRARY_MINI_KIT_RUNBOOK.md
- 04_SYSTEM_EXPORT_FORMAT.md

## Poznámky

- Všechny výskyty řetězce `@temp` byly z obsahu odstraněny.
- Ve vybraných souborech byly nalezeny a odstraněny výskyty `@temp`:
  - 01_CORE_MODULY_AUTO_GENERATE_GPT.md: 1×
