#!/usr/bin/env python3
import argparse
import json
import yaml
from pathlib import Path

def load_file(path):
    if path.suffix in ['.yaml', '.yml']:
        return yaml.safe_load(path.read_text(encoding="utf-8"))
    elif path.suffix == '.json':
        return json.loads(path.read_text(encoding="utf-8"))
    else:
        raise ValueError("Unsupported file format")

def main():
    parser = argparse.ArgumentParser(description="Run GPT_KIT locally")
    parser.add_argument("--file", "-f", type=str, required=True, help="Path to .yaml or .json GPT_KIT file")
    parser.add_argument("--print", action="store_true", help="Print the loaded file structure")
    args = parser.parse_args()

    path = Path(args.file)
    if not path.exists():
        print(f"❌ File not found: {args.file}")
        return

    try:
        data = load_file(path)
        if args.print:
            print("✅ Loaded content:
")
            print(json.dumps(data, indent=2, ensure_ascii=False))
        else:
            print(f"✅ File {args.file} loaded successfully.")
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    main()
