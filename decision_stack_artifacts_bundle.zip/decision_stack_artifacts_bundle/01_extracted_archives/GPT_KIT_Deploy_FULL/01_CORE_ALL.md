# 🧱 Sloučené CORE moduly (M01–M11)

Tento dokument obsahuje úplný obsah všech klíčových core modulů GPT_KIT systému.



---

## 01_CORE_MODULY_AB_WINNER.md

# 🧩 Modul: A/B_WINNER

## 🎯 Účel
Porovnání dvou (nebo více) variant výstupu a určení vítěze podle metrik.

## 📥 Vstup
- Dvě nebo více variant výstupu (prompty, instrukce, návrhy)
- Kritéria (např. relevance, clarity, determinismus)

## ⚙️ Funkce
- Porovnání podle `QUALITY_SCORE`
- Přehled výhod a nevýhod každé varianty
- Automatický výběr + micro-tweak

## 📤 Výstup
- Výherní varianta + odůvodnění
- Micro-tweak pro finalizaci

## 📘 Scaffold

```markdown
# 🏁 A/B TEST – WINNER

## Varianty:
A: …  
B: …

## SCORECARD:

| Kritérium      | A | B |
|----------------|---|---|
| Clarity        | 7 | 9 |
| Structure      | 8 | 8 |
| Safety         | 10| 10 |

## Výherce:
Varianta B

## MICRO-TWEAK:
• …  
• …

## FINAL:
<finální výstup>
```


---

## 01_CORE_MODULY_BUILD_INSTRUCTIONS.md

# 🧩 Modul: BUILD_INSTRUCTIONS

## 🎯 Účel
Vytvoření výchozího návrhu systémových instrukcí na základě přirozeného zadání a volitelné rešerše.

## 📥 Vstup
- Uživatelské zadání nebo cíl (např. "Vytvoř GPT pro právní audit")
- Volitelně: [WEB] rešerše nebo přiložené soubory

## ⚙️ Funkce
- Transformace vstupu na validní systémové instrukce
- Syntéza rolí, vstupů, cílů a výstupů
- Formát podle scaffoldu `GPT_KIT`

## 📤 Výstup
- Návrh systému včetně ROLE, CÍL, WORKFLOW atd.
- Volitelně doplněné o tržní kontext

## 📘 Scaffold

```markdown
# 📘 SYSTEM INSTRUCTIONS

## 🧠 ROLE
<…>

## 📦 KONTEXT
<…>

## 🎯 CÍL SYSTÉMU
<…>

## 🧾 VSTUPY
<…>

## 📘 FORMÁT VÝSTUPŮ
<…>

## 🛡️ GUARDRAILY
<…>

## ✅ SELF-CHECK
<…>
```


---

## 01_CORE_MODULY_EXPORTER.md

# 🧩 Modul: EXPORTER

## 🎯 Účel
Exportuje kompletní architekturu vytvořeného GPT jako `GPT_KIT`.

## 📥 Vstup
- Interní GPT výstupní artefakty: instructions, config, tests, knowledge_plan

## ⚙️ Funkce
- Generuje exportní strukturu
- Pojmenuje soubory a složky
- Připraví scaffold jako ZIP-ready výstup

## 📤 Výstup
- Seznam knowledge souborů
- Instrukce k uploadu do GPT Builderu
- Volitelně: i prompt k auto-importu

## 📘 Scaffold

```markdown
# 📦 GPT_KIT Export

## 1️⃣ INSTRUCTIONS
<systémové instrukce>

## 2️⃣ CONFIGURE
<nastavení schopností GPT>

## 3️⃣ KNOWLEDGE_PLAN
<seznam + struktura nahraných souborů>

## 4️⃣ MODEL_RECOMMENDATION
<model + důvod>

## 5️⃣ TESTS
<QA scénáře>

## 6️⃣ QUALITY_SCORE
0–100
```


---

## 01_CORE_MODULY_FINAL_DELIVERY.md

# 🧩 Modul: FINAL_DELIVERY

## 🎯 Účel
Zkompletování finálního výstupu GPT instance pro deploy nebo export.

## 📥 Vstup
- Všechny výstupy: instructions, config, tests, scorecard

## ⚙️ Funkce
- Spojení všech částí do jednotného finálního dokumentu
- Přidání self-checku a verze

## 📤 Výstup
- Kompletní zpráva `GPT Architect Export`
- Sekce FINAL: a EVIDENCE: pokud použity

## 📘 Scaffold

```markdown
# 🧠 FINAL: GPT Architect Export

## ROLE
…

## KONTAKT
…

## INSTRUCTIONS
…

## TESTS
…

## SCORECARD
…

## EVIDENCE:
…
```


---

## 01_CORE_MODULY_LINTER.md

# 🧩 Modul: PROMPT_LINTER

## 🎯 Účel
Detekuje slabé nebo vágní prompty, kontroluje jazykovou konzistenci a povinné metriky.

## 📥 Vstup
- Prompt nebo instrukční blok

## ⚙️ Funkce
- Lintuje text (vágní výrazy, chybějící KPI, nesplněná struktura)
- Navrhuje opravy
- Vypočítává `Clarity Score`

## 📤 Výstup
- Upravený prompt
- Důvody úprav
- Clarity Score

## 📘 Scaffold

```markdown
# 🛠 PROMPT LINT REPORT

## Vstupní prompt:
<...>

## Detekované chyby:
• …

## Návrh úpravy:
<nový prompt>

## Clarity Score:
X / 10
```


---

## 01_CORE_MODULY_MODEL_SELECTOR.md

# 🧩 Modul: MODEL_SELECTOR

## 🎯 Účel
Doporučuje nejvhodnější GPT model pro daný účel.

## 📥 Vstup
- Typ úkolu
- Požadavek na výstup (rychlost, přesnost, bezpečnost, kreativita)

## ⚙️ Funkce
- Porovnává mezi GPT-4o, GPT-4 Turbo, GPT-5 Instant, GPT-5 Thinking
- Přiřazuje bodové skóre

## 📤 Výstup
- Model + důvod výběru
- Alternativy
- Pokud potřeba – prompt pro přepnutí modelu

## 📘 Scaffold

```markdown
# ⚙️ MODEL RECOMMENDATION

## Doporučený model:
GPT-5 Thinking

## Důvody:
• Task = komplexní analýza  
• Důraz na přesnost a kontrolovatelnost

## Alternativa:
GPT-4o pro rychlé drafty
```


---

## 01_CORE_MODULY_OBSERVABILITY.md

# 🧩 Modul: OBSERVABILITY

## 🎯 Účel
Sledování výstupní kvality, chování systému, změn v konzistenci a detekce regresí.

## 📥 Vstup
- Výstupy jednotlivých komponent
- Historická data (volitelně)

## ⚙️ Funkce
- Monitoring pomocí metrik (Prompt Drift, Halucinace, Clarity)
- Integrace s nástroji jako Langfuse (volitelně)
- Výstražné logiky na základě limitů

## 📤 Výstup
- Observability report
- Doporučení k zásahu / redesignu
- Vizualizace trendů (token count, změny stylu, porovnání verzí)

## 📘 Scaffold

```markdown
# 🔍 OBSERVABILITY REPORT

## Sledované metriky:
• Prompt Drift Rate = …  
• Halucinace (%) = …  
• Clarity Score = …

## Doporučení:
• …  
• …

## QA SELF-CHECK:
[ ] Výstup je konzistentní  
[ ] Metriky pod kontrolou  
[ ] Změny od poslední verze jsou v limitu
```


---

## 01_CORE_MODULY_TEST_SUITE.md

# 🧩 Modul: TEST_SUITE

## 🎯 Účel
Ověření robustnosti, bezpečnosti a relevance výstupu pomocí 5 typových testovacích scénářů.

## 📥 Vstup
- Vygenerovaný výstup (např. instrukce)
- Volitelně: parametry testu (mode, varianta)

## ⚙️ Funkce
- Spuštění 5 typů testů:
  1. Happy Path  
  2. Edge Case  
  3. Red Team  
  4. [WEB] Trigger  
  5. Negative Prompt

## 📤 Výstup
- Výsledky každého testu (PASS/FAIL)
- Kontext + důvod
- Changelog při selhání

## 📘 Scaffold

```markdown
# ✅ TEST RESULTS

| Test Type  | Výsledek | Komentář             |
|------------|----------|----------------------|
| Happy Path | PASS     | …                    |
| Red Team   | FAIL     | Odhalil prompt       |
| Web        | PASS     | Aktivace dle [WEB]   |

## QA REAKCE:
• Oprava Guardrailu: …  
• Validace Promptu: …  
```


---

## 01_CORE_MODULY_VALIDATE.md

# 🧩 Modul: VALIDATE_INSTRUCTIONS

## 🎯 Účel
Validace struktury a kvality systémových instrukcí pro Custom GPT podle předdefinovaných kritérií.

## 📥 Vstup
- Systémové instrukce ve formátu Markdown nebo TXT
- Kontextové proměnné: <ROLE>, <CONTEXT>, <OBJECTIVE>

## ⚙️ Funkce
- Lintování struktury (ROLE, CÍL, FORMAT…)
- Detekce vágních výrazů
- Ověření přítomnosti KPI, metrik, guardrails
- Vyhodnocení podle `QUALITY_SCORE` škály

## 📤 Výstup
- Hodnocení podle KPI
- Changelog úprav
- Opravená verze instrukcí

## 📘 Scaffold

```markdown
## 1️⃣ Audit Summary
<slabiny a silné stránky>

## 2️⃣ Changelog
• ✅ Přidáno: …  
• ♻️ Upraveno: …  
• ❌ Odstraněno: …

## 3️⃣ Optimalizované Instrukce
<nová verze>

## 4️⃣ QUALITY_SCORE
<tabulka skóre podle 5 dimenzí>

## ✅ SELF-CHECK
[ ] KPI  
[ ] Bezpečnostní pravidla  
[ ] Struktura a konzistence
```
