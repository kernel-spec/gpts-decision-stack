# AUDIT_PROMPTS_STRICT_EXTREME.md
25 extrémně přísných auditních promptů pro GPT_KIT Audit Engine (STRICT MODE).

## A) SYSTEM PROMPT AUDITS (1–5)

### 1) Full System Prompt Audit – EXTREME
```
/kit.review
STRICT EXTREME AUDIT:
Zde je system prompt. Najdi *vše*, co je špatně. Nic neignoruj.
<PASTE>
```

### 2) System Prompt – Missing Core Components
```
Najdi všechny chybějící části system promptu podle KIT (M01–M11, pipelines, QA).
Nehledej výmluvy, pouze deficity.
<PASTE>
```

### 3) System Prompt – Role Enforcement Audit
```
Audituj roli promptu. Pokud není absolutně jasná, označ jako FAIL.
Navrhni přesnou a striktní opravu.
<PASTE>
```

### 4) System Prompt – Constraint Violations
```
Najdi všechna porušení constraints (bezpečnost, jazyk, role, I/O).
Každé musí být označeno a opraveno.
<PASTE>
```

### 5) System Prompt – Governance & Safety FAILSCAN
```
Prověř *všechna* safety rizika, policy hrozby, fuzzy instrukce.
Navrhni tvrdé mitigace.
<PASTE>
```

## B) KIT BLUEPRINT AUDITS (6–10)

### 6) Full KIT Audit – EXTREME
```
/kit.review
Kompletní KIT audit.
Návrh je buď VALID, nebo FAIL.
<PASTE_YAML>
```

### 7) KIT – Business Layer Integrity Check
```
Chybějící JTBD/KPI/riziko/omezení = kritický FAIL.
<PASTE>
```

### 8) KIT – Module Coverage ZERO-TOLERANCE
```
Zkontroluj pokrytí všech modulů.
Chybějící modul nebo neurčitá funkce = FAIL.
<PASTE>
```

### 9) KIT – Pipeline Logic Audit
```
Jakákoli nekonzistence pipeline = FAIL.
<PASTE_PIPELINE>
```

### 10) KIT – QA/Test Layer Mandatory Check
```
Chybí-li T01–T04 nebo QA metriky → FAIL.
<PASTE>
```

## C) PROMPT ENGINEERING AUDITS (11–15)

### 11) Prompt Audit – STRUCTURAL HARD MODE
```
Najdi slabiny, rizika, chyby. Přepiš prompt do perfektní verze.
<PASTE_PROMPT>
```

### 12) Prompt Role/Task/IO Breakdown Audit
```
Není-li role/task/IO explicitní → FAIL.
<PASTE>
```

### 13) Prompt Clarity FAILURE CHECK
```
Každá nejasnost = FAIL. Vrať extrémně jasnou verzi promptu.
<PASTE>
```

### 14) Prompt Safety Breach Audit
```
Identifikuj všechna safety rizika. Každé oprav.
<PASTE>
```

### 15) Prompt–Blueprint Consistency Audit
```
Najdi *všechny* nekonzistence s blueprintem.
Každá = FAIL.
PROMPT: <PASTE_PROMPT>
BLUEPRINT: <PASTE_YAML>
```

## D) SAFETY / RISK / QA AUDITS (16–20)

### 16) Safety MAXIMUM RISK Audit
```
Najdi *všechna* bezpečnostní rizika, zneužitelné části, slabiny.
Klasifikuj: High, Critical.
<PASTE>
```

### 17) Hallucination Probability Audit
```
Najdi místa s vysokým rizikem halucinace.
U každého navrhni fix.
<PASTE>
```

### 18) QA Metrics Zero-Tolerance Audit
```
Pokud jakákoliv metrika < 10/20 → FAIL.
<PASTE_OUTPUT>
```

### 19) Edge-Case Handling Audit
```
Najdi všechny edge-case slabiny. Navrhni konkrétní opravy.
<PASTE>
```

### 20) Test Coverage EXTREME
```
Chybí-li T01–T04 = FAIL.
<PASTE_TESTS>
```

## E) WORKFLOW / PIPELINE / MODULE AUDITS (21–25)

### 21) Module-by-Module Hardline Audit
```
Audituj každý modul M01–M11.
Jakákoli nejasná definice = FAIL.
<PASTE>
```

### 22) Pipeline Adequacy Audit
```
Pipeline musí přesně odpovídat účelu.
Neodůvodněné kroky = FAIL.
<PASTE_PIPELINE>
```

### 23) Workflow Correctness Audit
```
Workflow musí mít logickou návaznost 1→N.
Jakýkoli chybějící krok = FAIL.
<PASTE_WORKFLOW>
```

### 24) Regression / Diff Audit
```
Najdi každou regresi, chybu nebo ztrátu informace.
OLD: <PASTE_OLD>
NEW: <PASTE_NEW>
```

### 25) Multi-Agent Consistency Audit (EXTREME)
```
Každý konflikt mezi agenty = FAIL.
AGENT_1: <PASTE_1>
AGENT_2: <PASTE_2>
AGENT_3: <PASTE_3>
```
