# 🧩 Sloučené SUPPORT moduly

Tento dokument obsahuje všechny podpůrné knowledge soubory (routing, self-check, scoring…).



---

## 02_SUPPORT_ROUTING_EVIDENCE_TRIGGERS.md

# 02_SUPPORT_ROUTING_EVIDENCE_TRIGGERS

## 1. ÚČEL

Tento dokument sjednocuje:

- routing schopností (web, MINI_KIT, moduly),
- pravidla pro práci s důkazy a citacemi (Evidence policy),
- knihovnu triggerů a jejich prioritu.

Cíl: konzistentně rozhodovat, kdy:

- použít jen interní knowledge,
- aktivovat web a Evidence mód BOTH,
- spouštět MINI_KIT moduly (`/ins`, `/aud`, `/mini_kit_runner`).

---

## 2. ROUTING & CAPABILITIES

### 2.1 Výchozí nastavení

- Výchozí mód: **KNOWLEDGE_ONLY**, bez webu.
- Web se zapíná jen pokud:
  - to explicitně chce uživatel (`[WEB]`),
  - dotaz je typicky “čerstvý” (zákony, ceny, novinky, trendy),
  - je potřeba doplnit `web_context` pro MINI_KIT `/ins`.

### 2.2 Zjednodušená matice

| Typ dotazu                          | Evidence mód    | Poznámka                                                          |
|------------------------------------|-----------------|-------------------------------------------------------------------|
| Prompt design / architektura GPT   | KNOWLEDGE_ONLY  | Využij knowledge + MINI_KIT, web jen když je `[WEB]`.             |
| Aktuální info, trendy, zákony      | BOTH            | Aktivuj web, cituj zdroje.                                        |
| Kombinace rešerše + návrh GPT      | BOTH            | Web → `web_context` → `/ins` (viz 02_INS_CONFIG.md).              |
| Interní audit existujícího promptu | KNOWLEDGE_ONLY  | `/aud` nad `ins_output`, bez webu, pokud není `[WEB]`.            |

---

## 3. EVIDENCE POLICY

### 3.1 Evidence módy

- **KNOWLEDGE_ONLY**  
  - Odpovědi stavět primárně na interních znalostech (knowledge soubory, systémové instrukce).
  - Web nepoužívat, pokud to není nutné nebo výslovně vyžádané.

- **BOTH**  
  - Kombinace knowledge + web.
  - Klíčová tvrzení z webu musí mít citaci.

- **WEB_ONLY** (výjimečný)  
  - Pouze web, pokud interní knowledge nedává relevantní oporu.

### 3.2 Přepínání evidence módů

| Trigger / Kontext                 | Evidence mód    | Poznámka                                           |
|----------------------------------|-----------------|----------------------------------------------------|
| Žádný explicitní trigger         | KNOWLEDGE_ONLY  | Využij pouze knowledge a systémové instrukce.      |
| Text „aktuální / nejnovější…“    | BOTH            | Vysoká šance potřeby webu.                         |
| `[WEB]`                          | BOTH            | Vynucení použití webu.                             |
| Interní QA / testování promptu   | KNOWLEDGE_ONLY  | Auditování podle knowledge modulů.                 |

---

## 4. TRIGGER LIBRARY

### 4.1 Přehled triggerů

| Trigger            | Typ       | Efekt                                                                                     |
|--------------------|-----------|-------------------------------------------------------------------------------------------|
| `[WEB]`            | routing   | Aktivuj web, Evidence mód = BOTH.                                                         |
| `/ins`             | modul     | Spusť MINI_KIT **custom_gpt_ins_v1** (viz 02_INS_CONFIG.md) – návrh systémových instrukcí. |
| `/aud`             | modul     | Spusť MINI_KIT **custom_gpt_aud_v1** (viz 03_AUD_CONFIG.md) – audit 10 sekcí.            |
| `/mini_kit_runner` | modul     | Orchestrace presetu + System Brief → `/ins` → `/aud` (viz 03_LIBRARY_MINI_KIT_RUNBOOK.md).|
| `/export`          | modul     | Spusť exportní pipeline (GPT_KIT; viz 01_CORE_MODULY_EXPORTER.md).                       |
| `[SAFE]`           | bezpečnost| Přísnější guardraily, konzervativní odpovědi, minimalizace rizika.                       |

### 4.2 Priorita triggerů

1. **Bezpečnostní** triggery (`[SAFE]` + explicitní omezení typu „bez webu“).
2. **Modulové** triggery (`/mini_kit_runner`, `/ins`, `/aud`, `/export`).
3. **Routing / Evidence** (`[WEB]`).

Pokud jsou v konfliktu (např. `[SAFE]` + `[WEB]`), vždy vyhrává bezpečnost.

---

## 5. VAZBY NA MINI_KIT

- `/ins`  
  - používá konfiguraci `custom_gpt_ins_v1` popsanou v **02_INS_CONFIG.md**  
  - očekává vstupy: `user_brief`, `web_context`, `original_instructions`.

- `/aud`  
  - používá konfiguraci `custom_gpt_aud_v1` popsanou v **03_AUD_CONFIG.md**  
  - očekává vstup: `ins_output` v tagu `<INS_OUTPUT>...</INS_OUTPUT>`.

- `/mini_kit_runner`  
  - orchestruje presety a System Brief (viz **03_LIBRARY_MINI_KIT_RUNBOOK.md**) a volá `/ins` a `/aud` podle `MODE`.

---

## 6. PATTERNY A PŘÍKLADY

### 6.1 Rychlý návrh GPT bez webu

- Vstup obsahuje `/ins`, neobsahuje `[WEB]`.
- Routing:
  - Evidence mód = KNOWLEDGE_ONLY.
  - Spusť `/ins` s `user_brief` (a případně `original_instructions`).
  - `web_context` neplň, pokud není `[WEB]`.

### 6.2 Analytická zpráva s webem + návrh GPT

- Vstup obsahuje `[WEB]` a cíl „aktuální stav + navrhni GPT“.
- Routing:
  - Evidence mód = BOTH.
  - Nejprve `[WEB]` rešerše → shrnutí do `web_context`.
  - Poté `/ins` s `user_brief` + `web_context`.

### 6.3 Audit existujícího GPT

- Uživatelský vstup obsahuje `/aud` a blok `<INS_OUTPUT>...</INS_OUTPUT>`.
- Routing:
  - Evidence mód = KNOWLEDGE_ONLY (pokud není `[WEB]`).
  - Spusť `/aud` podle 03_AUD_CONFIG.md.

---

## 7. QUICK-CHECK PRO ROUTING

Před finální odpovědí:

1. Obsahuje vstup nějaký trigger z tabulky (modulový / routing / bezpečnostní)?  
2. Potřebuje dotaz aktuální data (zákony, ceny, novinky)?  
3. Je zřejmé, zda je primární akce `/ins`, `/aud` nebo `/mini_kit_runner`?  
4. Je správně nastaven Evidence mód (KNOWLEDGE_ONLY / BOTH)?  
5. Nejsou v konfliktu triggery (pokud ano, je aplikována priorita: bezpečnost → moduly → routing)?


---

## 02_SUPPORT_SCORING_MODEL.md

# 📊 QUALITY_SCORE Model

## 🎯 Účel
Hodnotící metrika pro finální výstupy a návrhy Custom GPT.

## ⚖️ Váhy kritérií

| Kritérium        | Váha (%) |
|------------------|----------|
| 🧱 Struktura      | 30 %     |
| 🧾 Srozumitelnost | 20 %     |
| 🎯 Determinismus  | 20 %     |
| 🛡 Bezpečnost      | 15 %     |
| 🔍 Evidence       | 15 %     |

## 🧠 Vysvětlení

- **Struktura**: odpovídá scaffoldu, konzistence
- **Srozumitelnost**: jednoduchost, čitelnost, tón
- **Determinismus**: predikovatelnost výstupu
- **Bezpečnost**: guardraily, refusal logic
- **Evidence**: citace, RAG, důkazní báze

## 📘 Příklad Hodnocení

```markdown
# 🧾 QUALITY SCORE

| Kritérium      | Skóre (1–10) | Komentář           |
|----------------|--------------|--------------------|
| Struktura      | 9            | Kompletní scaffold |
| Srozumitelnost | 8            | Mírně vágní úvod   |
| Evidence       | 10           | Silná RAG logika   |

## CELKEM: 94 / 100
```


---

## 02_SUPPORT_SELF_CHECK.md

# ✅ SELF-CHECK

## 🎯 Účel
Interní checklist a test před odesláním výstupu.

## 🧾 Kontrolní body

| Otázka                                             | Výsledek |
|----------------------------------------------------|----------|
| Odpovídá Role, Kontext, Cíl?                       | ✅ / ❌    |
| Obsahuje všechny části scaffoldu?                  | ✅ / ❌    |
| Je výstup podle definovaného stylu (STYLE & VOICE)?| ✅ / ❌    |
| Obsahuje metriky a návrh KPI?                      | ✅ / ❌    |
| Dodržuje guardraily?                               | ✅ / ❌    |
| Self-score a rationale přítomny?                   | ✅ / ❌    |

## 📘 Příklad použití

```markdown
# 🧪 SELF-CHECK

✓ Scaffold je úplný  
✓ KPI: Prompt Drift, Halucinace  
✓ Evidence použitá z [Context]  
✓ Guardraily: ON  
✓ Mini-Rationale: přítomna
```
