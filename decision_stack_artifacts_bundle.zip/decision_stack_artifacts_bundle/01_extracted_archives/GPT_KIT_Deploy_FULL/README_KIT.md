# 🚀 GPT_KIT – Nasazení & Použití (Runtime README)

Tento soubor slouží jako úvodní přehled a runtime návod k použití systému `GPT_KIT`.

---

## 📦 Obsah balíčku

- `GPT_KIT_Template.yaml` – hlavní šablona systému (moduly, pipeline, prompty, QA…)
- `GPT_KIT_MetaDesigner.yaml` – agent pro návrh dalších GPT agentů
- `GPT_KIT_KCPD.yaml` – knowledge & context plánovač

- `01_CORE_ALL.md` – všechny core moduly M01–M11
- `02_SUPPORT_ALL.md` – podpůrné funkce, evidence, triggery
- `03_LIBRARY_ALL.md` – knihovna promptů, pipeline, output šablon
- `04_META_ALL.md` – README knowledge + systémové export formáty

---

## 🧠 Jak používat

1. Nahraj výše uvedené `.yaml` a `.md` soubory do **Custom GPT builderu**
2. Jako **startovní prompt** použij:
   ```
   /kit.spec
   ```
   nebo
   ```
   /design GPT agent na [téma]
   ```

3. Používej aliasy:

| Alias | Funkce |
|-------|--------|
| `/kit.spec` | Návrh nového systému z briefu |
| `/kit.review` | Kontrola návrhu a scoring |
| `/design` | Interaktivní návrh blueprintu |
| `/tests` | Generování testovacích scénářů |
| `/export` | Export výstupu (MD/JSON) |
| `/compare`, `/rollback`, `/refactor`, `/final` | Verze, diff, QA |

---

## 🛡️ Model doporučení

| Fáze použití | Model |
|-------------|-------|
| Návrh, export | `gpt-4-turbo` nebo `gpt-5` |
| QA & audit | `gpt-4o` nebo `gpt-5` |
| Prompt rewrite (M11) | `gpt-4o`, `claude 3 opus`, `gpt-5` |

---

## 📘 Poznámky

- Knowledge je sloučena do 4 souborů kvůli limitu 20 souborů v Custom GPT
- YAML šablony musí být beze změn, jinak nebude fungovat orchestrace
- Všechny prompty a moduly jsou připraveny na `meta_prompt_architect`

