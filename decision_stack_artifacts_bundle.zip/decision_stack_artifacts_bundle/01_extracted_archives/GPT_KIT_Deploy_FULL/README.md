# 📦 GPT_KIT – Meta-Builder Deployment

Tento balíček obsahuje kompletní architekturu a agenty pro návrh, testování a provoz GPT systémů v prostředí „GPT Architect“.

## 🧠 OBSAH BALÍČKU

- `GPT_KIT_Template.yaml` – hlavní šablona pro návrh nového systému
- `GPT_KIT_MetaDesigner.yaml` – agent pro návrh metapromptů a rolí
- `GPT_KIT_KCPD.yaml` – návrhář znalostního a kontextového plánu
- `Null_Filler_Agent.yaml` – nástroj na doplňování neznámých/null informací
- `File_System_Operator_Agent.yaml` – operátor nad souborovým systémem
- `README_KIT.md` – tento úvodní soubor
- `01_CORE_ALL.md` – sloučené CORE moduly
- `02_SUPPORT_ALL.md` – podpůrné nástroje
- `03_LIBRARY_ALL.md` – knihovny šablon a pipeline
- `04_META_ALL.md` – meta-agent logika, testy, triggery
- `AUDIT_PROMPTS_STRICT_EXTREME.md` – 25 přísných auditních promptů
- `run_kit.py` – CLI runner pro načítání a testování YAML/JSON

## ▶️ RYCHLÝ START

```bash
python3 run_kit.py --file GPT_KIT_Template.yaml --print
```

## ✅ DOPORUČENÍ

- Používej výhradně strukturované YAML návrhy
- Vždy validuj QA skóre (≥85)
- Při zásazích do souborů používej `--dry-run` nebo zálohování

