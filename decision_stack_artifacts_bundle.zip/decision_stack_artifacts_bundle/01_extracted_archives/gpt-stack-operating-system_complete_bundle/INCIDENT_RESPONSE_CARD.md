# INCIDENT_RESPONSE_CARD.md

## Purpose
Krátká incident response karta pro runtime, live send nebo control-layer chybu.

Používej ji:
- při live incidentu
- při critical operator error
- při release failure
- při claims incidentu
- při registry breaku

---

## Incident classes

### 1. Control incident
Např.:
- router selhal
- dev layer selhal
- re-entry byl nevalidní
- specialista byl routovaný špatně

### 2. Live send incident
Např.:
- batch šel ven bez gate
- šla ven špatná asset verze
- send šel na špatný list subset

### 3. Claims incident
Např.:
- unsupported claim v live copy
- invented proof wording
- riskantní promise language šla ven

### 4. Registry incident
Např.:
- chybí raw output
- chybí artifact
- manifest se rozpadl
- log neodpovídá real runu

### 5. Operator incident
Např.:
- chybný GPT
- přeskočená vrstva
- špatný re-entry
- špatný reviewer

---

## Immediate response

### Step 1
Stop current flow.

### Step 2
Neškáluj dál.

### Step 3
Urči incident class.

### Step 4
Urči:
- last valid step
- broken step
- whether anything went live

### Step 5
Zapoj správnou recovery vrstvu:
- operator error -> `OPERATOR_ERROR_RECOVERY_CARD.md`
- drift problem -> `STACK_DRIFT_TRIAGE_CARD.md`
- registry problem -> `REGISTRY_AUDITOR`
- release problem -> `RELEASE_GATE_REVIEWER`
- claims problem -> `CLAIMS_EVIDENCE_REVIEWER`

---

## Incident containment

- [ ] flow stopped
- [ ] no further send
- [ ] affected asset version identified
- [ ] affected list or batch identified
- [ ] affected artifact identified
- [ ] affected session identified

---

## Recovery questions

- Co byl poslední validní krok?
- Co přesně se rozbilo?
- Šlo něco live?
- Je to control issue, operator issue, nebo content issue?
- Co je minimum repair?
- Co se musí rozhodnout ještě dnes?

---

## Incident block

```text
INCIDENT_RESPONSE:
DATE_LABEL:
SESSION_ID:
RUN_ID:
INCIDENT_CLASS:
SEVERITY:
LAST_VALID_STEP:
BROKEN_STEP:
WENT_LIVE:
AFFECTED_ARTIFACT:
AFFECTED_ASSET_VERSION:
AFFECTED_BATCH:
IMMEDIATE_CONTAINMENT:
MINIMUM_REPAIR:
OWNER:
NEXT_SAFE_STEP:
STATUS:


⸻

Severity guide
	•	low
	•	medium
	•	high
	•	critical

⸻

Hard rule

Při incidentu nejdřív zastav flow.
Teprve potom analyzuj.
Neobracej to.
