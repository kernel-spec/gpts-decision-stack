# LIVE_OPERATOR_RUNBOOK.md

## Purpose
Denní runtime guide pro operátora.

## Golden flow
`SYSTEM_OS_MASTER -> specialista -> STACK_DEV_LAYER -> SYSTEM_OS_MASTER`

## Extended flow
`SYSTEM_OS_MASTER -> specialista -> STACK_DEV_LAYER -> reviewer -> SYSTEM_OS_MASTER`

## Open by default
- `LIVE_OPERATOR_RUNBOOK.md`
- `CANONICAL_REENTRY_TEMPLATE.md`
- `STACK_DEV_LAYER_INPUT_TEMPLATE.md`
- `SESSION_LOG_TEMPLATE.md`

## What goes where
- business next step -> `SYSTEM_OS_MASTER`
- raw specialist output -> `STACK_DEV_LAYER`
- log step -> `SESSION_LOGGER`
- update manifest -> `MANIFEST_KEEPER`

## Never do
- specialist -> specialist
- raw output -> router
- reviewer as router
- launch without release gate
