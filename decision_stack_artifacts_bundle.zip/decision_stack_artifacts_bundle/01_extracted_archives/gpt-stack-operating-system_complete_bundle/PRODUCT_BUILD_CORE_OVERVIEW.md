# PRODUCT_BUILD_CORE_OVERVIEW.md

## Purpose
Tento soubor je orientační overview product / build lane.

Používej ho jako:
- rychlý přehled product/build rolí
- mapu feature -> architecture -> engineering review -> execution plan
- referenci pro build planning

---

## Product lane goal
Product lane má dojít od:
- product nápadu
- feature requestu
- nejasného build scope

k:
- feature packu
- architecture recommendation
- engineering review
- execution planu
- release verdictu

---

## Core roles

### `SAAS_FEATURE_PACK_ENGINE`
Používej pro:
- feature pack
- requirements
- user flows
- scope definition

### `Architecture Copilot`
Používej pro:
- system design
- topology
- architecture choice
- integration structure

### `Staff Engineer OS`
Používej pro:
- technical review
- bottlenecks
- readiness
- implementation risk

### `Founder OS`
Používej pro:
- execution sequencing
- prioritization
- final build plan

### `RELEASE_GATE_REVIEWER`
Používej pro:
- final readiness decision
- blocker clarity
- release discipline

---

## Canonical product flow
`SYSTEM_OS_MASTER -> SAAS_FEATURE_PACK_ENGINE -> STACK_DEV_LAYER -> SYSTEM_OS_MASTER -> Architecture Copilot -> STACK_DEV_LAYER -> SYSTEM_OS_MASTER -> Staff Engineer OS -> STACK_DEV_LAYER -> SYSTEM_OS_MASTER -> Founder OS -> RELEASE_GATE_REVIEWER -> STACK_DEV_LAYER`

---

## Documentation source
Primary runbook:
- `10_PRODUCT_BUILD_RUNBOOK.md`

Related control files:
- `01_CONTROL_PLANE_RUNBOOK.md`
- `12_SESSION_LOGGING_AND_ARTIFACT_REGISTRY_RUNBOOK.md`
- `RELEASE_GATE_POLICY.md`

---

## Product lane success condition
Product lane je správně nastavená, když:
- feature pack je build-ready
- architektura je konkrétní
- engineering review je prioritizovaný
- execution plan je použitelný
- release gate vrací tvrdý verdict
