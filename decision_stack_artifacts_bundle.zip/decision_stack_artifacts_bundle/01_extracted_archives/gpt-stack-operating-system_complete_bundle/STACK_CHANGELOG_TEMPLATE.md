# STACK_CHANGELOG_TEMPLATE.md

## Purpose
Template pro změnový log celého stacku.

Používej ho:
- při změně routeru
- při změně dev layeru
- při změně review gates
- při změně dokumentace
- při změně import registry
- při změně runtime nebo testovací logiky

---

## Changelog entry

DATE_LABEL:
CHANGE_ID:
OWNER:
CHANGE_TYPE:
- router
- dev_layer
- review_gate
- operator_runtime
- documentation
- test_layer
- import_registry
- lane_logic
- mixed

AFFECTED_FILES:
- 
- 
- 

AFFECTED_GPTS:
- 
- 
- 

REASON_FOR_CHANGE:
- 

WHAT_CHANGED:
- 
- 
- 

EXPECTED_IMPACT:
- 

RISK_LEVEL:
- low
- medium
- high
- critical

REQUIRES_RETEST:
- yes
- no

RETEST_SCOPE:
- none
- router
- reentry
- backbone
- slice
- operator
- live
- mixed

REQUIRED_TEST_FILES:
- 
- 
- 

ROLLBACK_PLAN:
- 

STATUS:
- proposed
- in_progress
- implemented
- retested
- reverted
- closed

NOTES:
- 

---

## Changelog usage rules

### Rule 1
Každá změna routeru nebo dev layeru musí mít changelog entry.

### Rule 2
Každá změna, která mění flow, musí mít `REQUIRES_RETEST: yes`.

### Rule 3
Každá změna dokumentace, která mění pořadí souborů nebo meaning, musí být zapsaná.

### Rule 4
Bez rollback plánu se nemá dělat high-risk změna.

---

## Minimal entry example

```text
DATE_LABEL:
CHANGE_ID:
CHANGE_TYPE:
AFFECTED_FILES:
REASON_FOR_CHANGE:
WHAT_CHANGED:
RISK_LEVEL:
REQUIRES_RETEST:
STATUS:


⸻

Hard rule

Když změna mění control plane, output contract, nebo release logic a není v changelogu, ber ji jako neřízenou změnu.
