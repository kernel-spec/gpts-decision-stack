# FIRST_5_GPTS_IMPORT_ORDER.md

## Purpose
Krátká karta pro prvních 5 GPTs, které má smysl importovat jako první.

Používej ji:
- na úplném začátku buildu
- když chceš rychlý start bez přestřelení scope
- když chceš první použitelné jádro stacku

---

## Import order

### 1. `SYSTEM_OS_MASTER`
Proč první:
- bez routeru nemáš control plane
- bez routeru neexistuje canonical next step

### 2. `STACK_DEV_LAYER`
Proč druhý:
- bez dev vrstvy nemáš artifact trail
- bez dev vrstvy nemáš re-entry
- bez dev vrstvy se flow rychle rozbije

### 3. `OPERATOR_HELPER`
Proč třetí:
- zamezí operátorskému guesswork
- zrychlí praktické používání na iPhonu

### 4. `SESSION_LOGGER`
Proč čtvrtý:
- bez logu nevíš, co se stalo
- bez logu se těžko debugguje drift

### 5. `MANIFEST_KEEPER`
Proč pátý:
- bez manifestu nemáš session state
- bez manifestu nemáš čistý artifact trail

---

## What this first 5 gives you

Po importu těchto 5 už máš:
- routing
- dev packaging
- operator guidance
- hop logging
- manifest

Ještě nemáš:
- claims gate
- release gate
- specialist lanes
- audit-plus layer

---

## Next recommended after first 5

### Add next
6. `HANDOFF_REVIEWER`
7. `CLAIMS_EVIDENCE_REVIEWER`
8. `RELEASE_GATE_REVIEWER`

Teprve potom:
9. `MARKET_SCOUT_OUTBOUND`
10. `STRUCTURAL_ENGINE`

---

## Minimal first test after import

Po prvních 5 GPT proveď:
1. jednoduchý router input
2. jednoduchý raw specialist mock -> dev layer
3. jednoduchý log entry
4. jednoduchý manifest entry

### Goal
Ověřit, že control layer skeleton funguje.

---

## Import block

```text
FIRST_5_IMPORT_STATUS:
1_SYSTEM_OS_MASTER:
2_STACK_DEV_LAYER:
3_OPERATOR_HELPER:
4_SESSION_LOGGER:
5_MANIFEST_KEEPER:
CONTROL_LAYER_SKELETON_STATUS:
NEXT_IMPORT_PRIORITY:
NOTES:
```

---

## Hard rule

Nezačínej importem specialistů, dokud nemáš aspoň:
- router
- dev layer
- log
- manifest
