# REVENUE_EXECUTION_CHECKLIST.md

## Purpose
Praktický checklist pro spuštění a řízení revenue lane od discovery po post-batch verdict.

Používej ho jako:
- denní revenue execution checklist
- pre-launch checklist
- live batch checklist
- post-batch decision checklist

---

## Phase 1 — Foundation before revenue work

- [ ] control plane je zamčený
- [ ] `SYSTEM_OS_MASTER` je jediný router
- [ ] `STACK_DEV_LAYER` je připravený
- [ ] `SESSION_LOGGER` je připravený
- [ ] `MANIFEST_KEEPER` je připravený
- [ ] `CLAIMS_EVIDENCE_REVIEWER` je připravený
- [ ] `RELEASE_GATE_REVIEWER` je připravený
- [ ] backbone tests jsou PASS nebo aspoň základně ověřené
- [ ] session logging běží

---

## Phase 2 — Revenue core documents ready

- [ ] `OFFER_SINGLE_SOURCE_OF_TRUTH.md` existuje
- [ ] `PRICING_AND_PACKAGING_MASTER.md` existuje
- [ ] `SALES_CALL_SYSTEM.md` existuje
- [ ] `LIST_BUILDING_MASTER_SPEC.md` existuje
- [ ] `OUTBOUND_ASSET_MASTER_PACK.md` existuje
- [ ] `DELIVERABILITY_AND_LAUNCH_POLICY.md` existuje
- [ ] `POST_BATCH_DECISION_RULES.md` existuje

---

## Phase 3 — Discovery and structure

- [ ] market discovery proběhla
- [ ] primary ICP je vybraný
- [ ] backup hypotheses jsou zapsané
- [ ] `icp_card` existuje
- [ ] ICP je narrow a outbound-testable
- [ ] geo scope je zamčený
- [ ] channel scope je zamčený

---

## Phase 4 — Shortlist logic

- [ ] source map existuje
- [ ] exclusions jsou jasné
- [ ] tiering je definovaný
- [ ] account-ready vs email-ready je jasné
- [ ] tracker logic existuje
- [ ] target volume je definovaný
- [ ] constraints neporušují sourcing logic

---

## Phase 5 — Positioning and claims

- [ ] positioning line je zamčená
- [ ] one CTA only
- [ ] strongest allowed claim je definovaný
- [ ] forbidden claims jsou zapsané
- [ ] žádný invented proof
- [ ] wording je in-scope
- [ ] CTA drift neexistuje

---

## Phase 6 — Asset pack

- [ ] opener exists
- [ ] follow-up exists
- [ ] DM exists
- [ ] claims review proběhla
- [ ] copy je safe-to-send
- [ ] žádné fake familiarity
- [ ] žádné guarantee language

---

## Phase 7 — Launch safety

- [ ] sending setup je známý
- [ ] DNS baseline je zkontrolovaná
- [ ] ramp logic existuje
- [ ] stop rules existují
- [ ] deliverability review proběhla
- [ ] release gate proběhla
- [ ] release verdict je explicitní

---

## Phase 8 — Live send

- [ ] asset version je jasná
- [ ] batch scope je jasný
- [ ] list subset je jasný
- [ ] operator ví, co přesně se posílá
- [ ] claims gate byla před live stepem
- [ ] release gate byla před live stepem
- [ ] session log byl aktualizovaný
- [ ] manifest byl aktualizovaný

---

## Phase 9 — Post-batch review

- [ ] sent je zapsané
- [ ] replies jsou zapsané
- [ ] booked je zapsané
- [ ] objections jsou zapsané
- [ ] timeframe je zapsaný
- [ ] `PERFORMANCE_MEMORY` verdict proběhl
- [ ] verdict je `SCALE`, `OPTIMIZE`, nebo `KILL`
- [ ] next action je zapsaná

---

## Hard stop rules

- [ ] stop, pokud neexistuje primary ICP
- [ ] stop, pokud neexistuje shortlist logic
- [ ] stop, pokud neproběhla claims review
- [ ] stop, pokud neproběhla release gate
- [ ] stop, pokud asset wording není safe
- [ ] stop, pokud operátor musí hádat, co se posílá

---

## Final revenue readiness check

Revenue execution je ready, když:
- [ ] ICP je narrow
- [ ] shortlist je ready
- [ ] positioning je locked
- [ ] assets jsou safe
- [ ] launch safety je clear
- [ ] release verdict je explicitní
- [ ] post-batch verdict path je připravená
