# OPERATOR_ERROR_RECOVERY_CARD.md

## Purpose
Krátká recovery karta pro operátora při chybě v runtime.

Používej ji:
- když pošleš něco do špatného GPT
- když přeskočíš dev vrstvu
- když ztratíš artifact trail
- když nevíš, jak se bezpečně vrátit do flow

---

## Error class 1 — Wrong GPT used

### Symptom
- input šel do špatné role
- reviewer byl použit jako router
- specialista dostal input, který měl jít do routeru

### Recovery
1. zastav
2. nic dál nenavazuj na chybný output
3. zapiš chybu do logu
4. vrať se do správné předchozí vrstvy
5. znovu pošli původní validní input do správného GPT

### Correct return
- business next step -> `SYSTEM_OS_MASTER`
- raw specialist output -> `STACK_DEV_LAYER`
- document navigation -> `LIBRARY_GUIDE`
- operator confusion -> `OPERATOR_HELPER`

---

## Error class 2 — Dev layer skipped

### Symptom
- specialista -> specialista
- raw output šel rovnou do routeru
- neexistuje normalized artifact

### Recovery
1. najdi poslední raw specialist output
2. vlož ho 1:1 do `STACK_DEV_LAYER`
3. získej `REENTRY_PROMPT`
4. teprve potom se vrať do `SYSTEM_OS_MASTER`
5. doplň log a manifest zpětně

---

## Error class 3 — Lost artifact identity

### Symptom
- nevíš `artifact_id`
- `completed_artifact` nesedí
- v manifestu chybí artifact step

### Recovery
1. najdi poslední dev output
2. potvrď `artifact_id`
3. srovnej `completed_artifact = artifact_id`
4. oprav log
5. oprav manifest
6. až potom pokračuj

---

## Error class 4 — Wrong reviewer used

### Symptom
- claims problem poslaný do handoff revieweru
- release problem poslaný do claims revieweru
- reviewer měl dělat gate, ale řeší jiný problém

### Recovery
1. zastav
2. nepoužívej verdict z nesprávného revieweru jako final
3. pošli stejný relevantní input do správného revieweru
4. zaloguj původní chybu jako operator error

### Reviewer map
- handoff problem -> `HANDOFF_REVIEWER`
- claims / proof / wording risk -> `CLAIMS_EVIDENCE_REVIEWER`
- live go/no-go -> `RELEASE_GATE_REVIEWER`

---

## Error class 5 — Live step without gate

### Symptom
- asset šel live bez claims review
- batch šel live bez release gate

### Recovery
1. stop
2. neškáluj dál
3. označ incident jako critical
4. proveď chybějící gate review
5. teprve potom rozhodni:
   - continue
   - pause
   - rollback

---

## Minimal error log block

```text
OPERATOR_ERROR:
SESSION_ID:
RUN_ID:
ERROR_CLASS:
WHAT_HAPPENED:
LAST_VALID_STEP:
RECOVERY_ACTION:
STATUS:
NEXT_SAFE_STEP:


⸻

Golden recovery rule

Při chybě:
	1.	stop
	2.	vrať se k poslednímu validnímu kroku
	3.	obnov artifact trail
	4.	pokračuj až po recovery
