# 05_POSITIONING_AND_CLAIMS_RUNBOOK.md

## Purpose
Zamknout positioning, CTA discipline a claims safety.

## Entry criteria
- ICP exists
- shortlist logic exists
- current offer framing exists

## Flow
1. `SYSTEM_OS_MASTER`
2. `POSITIONING_POLICE`
3. `CLAIMS_EVIDENCE_REVIEWER`
4. `STACK_DEV_LAYER`
5. `SYSTEM_OS_MASTER`

## Expected outputs
- positioning audit
- vocabulary rules
- CTA lock
- strongest allowed claim
- forbidden claims

## Exit criteria
- one clear positioning line
- one CTA only
- no invented proof
- no broad transformation promise

## Stop conditions
- multiple CTA paths
- unsupported claims
- scope drift
- vague offer naming
