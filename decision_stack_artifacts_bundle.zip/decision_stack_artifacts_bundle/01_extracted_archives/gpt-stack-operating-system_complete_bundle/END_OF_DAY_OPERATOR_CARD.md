# END_OF_DAY_OPERATOR_CARD.md

## Purpose
Krátká end-of-day karta pro operátora.

Používej ji:
- na konci pracovního dne
- po poslední session
- před uzavřením iPhone runtime
- před zítřejším handoffem sám sobě

---

## Section 1 — Session state

- [ ] všechny dnešní sessions mají final status
- [ ] žádná session nekončí u nejasného kroku
- [ ] dnešní final bottleneck je zapsaný
- [ ] zítřejší první krok je jasný

---

## Section 2 — Logs

- [ ] každý dnešní hop je zalogovaný
- [ ] každý FAIL má drift type
- [ ] každý PASS_WITH_MINOR_FIXES má notes
- [ ] session logs nejsou jen v chatech

---

## Section 3 — Manifest

- [ ] manifest byl aktualizovaný
- [ ] poslední artifact je v manifestu
- [ ] final verdicty jsou v manifestu
- [ ] next bottleneck je v manifestu

---

## Section 4 — Live risk check

- [ ] nic nezůstalo viset jako implicitně live
- [ ] žádný unreleased asset není považovaný za safe
- [ ] žádný batch není bez release verdictu
- [ ] claims-safe status je jasný

---

## Section 5 — Tomorrow setup note

Vyplň:
- tomorrow first file:
- tomorrow first GPT:
- tomorrow first bottleneck:
- tomorrow first session goal:

---

## End-of-day summary block

```text
END_OF_DAY:
DATE_LABEL:
SESSIONS_CLOSED:
OPEN_SESSIONS:
FINAL_BOTTLENECK:
TOMORROW_FIRST_FILE:
TOMORROW_FIRST_GPT:
TOMORROW_FIRST_GOAL:
LOG_STATUS:
MANIFEST_STATUS:
LIVE_RISK_STATUS:
NOTES:


⸻

Hard rule

Den není správně uzavřený, pokud:
	•	log není kompletní
	•	manifest není aktualizovaný
	•	zítřejší první krok není jasný
