# FINAL_MASTER_FILE_INDEX.md

## Purpose
Tento soubor je finální master index celé sady vytvořených a standardizovaných souborů pro GPT stack.

Používej ho jako:
- úplný seznam knihovny
- kontrolu coverage
- navigační master index nad všemi vytvořenými soubory
- referenci pro knowledge upload, import, rollout a provoz

---

## Total file count
`97` souborů

---

## 1. Foundation / Control Plane

- `00_OPERATOR_START_HERE.md`
- `01_CONTROL_PLANE_RUNBOOK.md`
- `02_STACK_DETERMINISM_RUNBOOK.md`
- `12_SESSION_LOGGING_AND_ARTIFACT_REGISTRY_RUNBOOK.md`
- `MASTER_EXECUTION_CHECKLIST.md`

---

## 2. Operator Runtime

- `LIVE_OPERATOR_RUNBOOK.md`
- `FULL_LIVE_OPERATOR_PLAYBOOK.md`
- `OPERATOR_QUICK_CARD.md`
- `CANONICAL_REENTRY_TEMPLATE.md`
- `STACK_DEV_LAYER_INPUT_TEMPLATE.md`
- `SESSION_LOG_TEMPLATE.md`
- `DAILY_OPERATOR_CHECKLIST.md`
- `WEEKLY_REVIEW_MEMO.md`
- `BLOCKERS_AND_DRIFT_LOG.md`

---

## 3. Revenue Monetization Core

- `OFFER_SINGLE_SOURCE_OF_TRUTH.md`
- `PRICING_AND_PACKAGING_MASTER.md`
- `SALES_CALL_SYSTEM.md`
- `LIST_BUILDING_MASTER_SPEC.md`
- `OUTBOUND_ASSET_MASTER_PACK.md`
- `DELIVERABILITY_AND_LAUNCH_POLICY.md`
- `POST_BATCH_DECISION_RULES.md`
- `ONE_PAGE_OFFER_SHEET.md`
- `ONBOARDING_FLOW.md`
- `DELIVERY_SOP.md`
- `SALES_PAGE_CORE_SECTIONS.md`

---

## 4. Revenue Runbook Suite

- `03_REVENUE_DISCOVERY_RUNBOOK.md`
- `04_ICP_TO_SHORTLIST_RUNBOOK.md`
- `05_POSITIONING_AND_CLAIMS_RUNBOOK.md`
- `06_ASSET_GENERATION_RUNBOOK.md`
- `07_LAUNCH_SAFETY_RUNBOOK.md`
- `08_POST_BATCH_DECISION_RUNBOOK.md`

---

## 5. Review / Gate Library

- `HANDOFF_REVIEW_POLICY.md`
- `CLAIMS_EVIDENCE_POLICY.md`
- `RELEASE_GATE_POLICY.md`
- `HANDOFF_REVIEWER_USE_GUIDE.md`
- `CLAIMS_EVIDENCE_REVIEWER_USE_GUIDE.md`
- `RELEASE_GATE_REVIEWER_USE_GUIDE.md`

---

## 6. Prompt Ops

- `09_PROMPT_OPS_RUNBOOK.md`

---

## 7. Product / Build

- `10_PRODUCT_BUILD_RUNBOOK.md`

---

## 8. Delivery / Retention / Scale

- `11_DELIVERY_AND_RETENTION_RUNBOOK.md`
- `PATTERN_LIBRARY.md`

---

## 9. Test Library — Master

- `STACK_FUNCTIONALITY_MASTER_TESTPLAN.md`
- `TEST_RESULTS_SUMMARY_TEMPLATE.md`
- `BACKBONE_GOLDEN_OUTPUTS_NOTE.md`
- `TEST_EXECUTION_ORDER_CARD.md`

---

## 10. Test Library — Backbone Tests

- `TEST_01_router_same_input_10x.md`
- `TEST_02_router_reentry_same_input_10x.md`
- `TEST_03_flow_determinism_3_hops.md`

---

## 11. Test Library — Slice Integrity

- `TEST_04_revenue_slice_integrity.md`
- `TEST_05_prompt_ops_slice_integrity.md`
- `TEST_06_product_slice_integrity.md`

---

## 12. Test Library — Operator Tests

- `TEST_OP_01_JUNIOR_RUN.md`
- `TEST_OP_02_SENIOR_RUN.md`

---

## 13. Test Library — Live Tests

- `LIVE_01_REVENUE_LIVE_BATCH.md`
- `LIVE_02_PROMPT_LIVE_EXPORT.md`
- `LIVE_03_PRODUCT_LIVE_PLANNING.md`

---

## 14. Core Import / Master Documentation

- `FINAL_CORE_IMPORT_REGISTRY_CARD.md`
- `LIBRARY_GUIDE_DOCUMENTATION.md`
- `MASTER_LIBRARY_INDEX.md`
- `STACK_DOCUMENTATION_MASTER.md`
- `STACK_DOCUMENTATION_SPLIT_PLAN.md`

---

## 15. Overview / Architecture Files

- `MAXIMUM_VIABLE_CONTROL_LAYER.md`
- `REVENUE_EXECUTION_CORE_OVERVIEW.md`
- `PROMPT_OPS_CORE_OVERVIEW.md`
- `PRODUCT_BUILD_CORE_OVERVIEW.md`
- `CONTROL_PLUS_AUDIT_LAYER_OVERVIEW.md`
- `COMMON_FAILURE_MODES.md`
- `STACK_STATUS_TEMPLATE.md`

---

## 16. Revenue / Control Execution Utilities

- `REVENUE_EXECUTION_CHECKLIST.md`
- `CONTROL_LAYER_READINESS_CHECKLIST.md`
- `LIVE_REVENUE_SESSION_TEMPLATE.md`

---

## 17. Operator Micro Cards

- `IOS_TAP_BY_TAP_OPERATOR_CARD.md`
- `REVIEW_GATE_DECISION_CARD.md`
- `ROUTER_REENTRY_QA_CARD.md`
- `LIVE_BATCH_STOP_RULES_CARD.md`

---

## 18. Session / Day Utilities

- `SESSION_CLOSEOUT_CHECKLIST.md`
- `FIRST_10_MINUTES_OPERATOR_SETUP.md`
- `REVENUE_DAY_OPENING_CARD.md`
- `END_OF_DAY_OPERATOR_CARD.md`

---

## 19. Review / Incident / Drift Utilities

- `WEEKLY_STACK_REVIEW_TEMPLATE.md`
- `LIVE_SESSION_POSTMORTEM_TEMPLATE.md`
- `OPERATOR_ERROR_RECOVERY_CARD.md`
- `STACK_DRIFT_TRIAGE_CARD.md`
- `INCIDENT_RESPONSE_CARD.md`

---

## 20. Go-Live / Maintenance Utilities

- `STACK_GO_LIVE_CHECKLIST.md`
- `FIRST_LIVE_REVENUE_DAY_TEMPLATE.md`
- `STACK_MAINTENANCE_RHYTHM.md`
- `STACK_CHANGELOG_TEMPLATE.md`
- `DOC_UPDATE_PROTOCOL.md`

---

## 21. Import / Builder / Rollout Utilities

- `GPT_IMPORT_QA_CHECKLIST.md`
- `STACK_ROLES_AND_BOUNDARIES_CARD.md`
- `KNOWLEDGE_UPLOAD_CHECKLIST.md`
- `CUSTOM_GPT_BUILDER_SETUP_CARD.md`
- `FIRST_5_GPTS_IMPORT_ORDER.md`
- `ROLLOUT_SEQUENCE_CARD.md`

---

## 22. Knowledge / Naming / ID / Admin Policies

- `KNOWLEDGE_SOURCE_MAP.md`
- `STACK_CANONICAL_NAMING_RULES.md`
- `ARTIFACT_ID_POLICY.md`
- `SESSION_ID_AND_RUN_ID_POLICY.md`

---

## 23. Recommended first-open set

Pokud chceš začít hned teď, otevři:
1. `00_OPERATOR_START_HERE.md`
2. `01_CONTROL_PLANE_RUNBOOK.md`
3. `12_SESSION_LOGGING_AND_ARTIFACT_REGISTRY_RUNBOOK.md`
4. `LIVE_OPERATOR_RUNBOOK.md`
5. `FINAL_CORE_IMPORT_REGISTRY_CARD.md`

---

## 24. Recommended first rollout set

Pokud chceš začít build / import, začni:
1. `FIRST_5_GPTS_IMPORT_ORDER.md`
2. `CUSTOM_GPT_BUILDER_SETUP_CARD.md`
3. `GPT_IMPORT_QA_CHECKLIST.md`
4. `KNOWLEDGE_UPLOAD_CHECKLIST.md`
5. `ROLLOUT_SEQUENCE_CARD.md`

---

## 25. Recommended first live revenue set

Pokud chceš spustit první revenue flow, otevři:
1. `OFFER_SINGLE_SOURCE_OF_TRUTH.md`
2. `03_REVENUE_DISCOVERY_RUNBOOK.md`
3. `04_ICP_TO_SHORTLIST_RUNBOOK.md`
4. `05_POSITIONING_AND_CLAIMS_RUNBOOK.md`
5. `06_ASSET_GENERATION_RUNBOOK.md`
6. `07_LAUNCH_SAFETY_RUNBOOK.md`
7. `08_POST_BATCH_DECISION_RUNBOOK.md`

---

## 26. Final rule

Tento master index je správně použitý tehdy, když:
- víš, který soubor je primary authority
- quick cards nepoužíváš místo runbooků
- control plane má prioritu před lane prací
- po každém specialistovi jde output přes `STACK_DEV_LAYER`
- žádný live krok nejde ven bez claims gate a release gate
