# CONTROL_LAYER_READINESS_CHECKLIST.md

## Purpose
Praktický checklist pro ověření, zda je control layer připravená na reálný provoz.

Používej ho jako:
- pre-live readiness check
- control plane audit checklist
- operator setup checklist
- pre-monetization readiness check

---

## Section 1 — Router readiness

- [ ] `SYSTEM_OS_MASTER` existuje
- [ ] router vrací přesně jeden `NEXT_GPT`
- [ ] router neroutuje do `STACK_DEV_LAYER`
- [ ] router neroutuje do `SYSTEM_OS_REENTRY_PACKER`
- [ ] router drží canonical schema keys
- [ ] router zachovává constraints
- [ ] router zachovává bottleneck
- [ ] router je deterministický pro stejné inputy
- [ ] router neprodukuje více route options

---

## Section 2 — Dev layer readiness

- [ ] `STACK_DEV_LAYER` existuje
- [ ] raw output bere jako source of truth
- [ ] vrací `REENTRY_PROMPT`
- [ ] vrací `NORMALIZED_ARTIFACT`
- [ ] drží `artifact_id`
- [ ] drží `completed_artifact = artifact_id`
- [ ] nepřidává prose noise
- [ ] nepředstírá file creation při nejisté persistenci
- [ ] nepoužívá placeholder drift typu `inferred_from_raw_specialist_output`

---

## Section 3 — Operator support readiness

- [ ] `OPERATOR_HELPER` existuje
- [ ] umí říct co otevřít
- [ ] umí říct co vložit
- [ ] umí říct kam patří raw output
- [ ] neumí routovat business role
- [ ] neumí suplovat specialisty

---

## Section 4 — Logging readiness

- [ ] `SESSION_LOGGER` existuje
- [ ] používá standardní verdicty
- [ ] používá standardní drift types
- [ ] umí zapsat každý hop
- [ ] log block je copy-paste ready

---

## Section 5 — Manifest readiness

- [ ] `MANIFEST_KEEPER` existuje
- [ ] drží `SESSION_ID`
- [ ] drží artifact identity
- [ ] drží verdict trail
- [ ] drží next bottleneck
- [ ] manifest je aktualizovatelný po každém kroku

---

## Section 6 — Review gates readiness

### Handoff gate
- [ ] `HANDOFF_REVIEWER` existuje
- [ ] vrací `PASS / PASS_WITH_MINOR_FIXES / FAIL`
- [ ] neauthoruje místo review

### Claims gate
- [ ] `CLAIMS_EVIDENCE_REVIEWER` existuje
- [ ] vrací `SAFE / SAFE_WITH_FIXES / NOT_SAFE`
- [ ] neinventuje proof
- [ ] umí strongest allowed claim

### Release gate
- [ ] `RELEASE_GATE_REVIEWER` existuje
- [ ] vrací `READY / READY_WITH_FIXES / NOT_READY`
- [ ] umí blockers vs non-blockers
- [ ] nedává READY bez kritických artefaktů

---

## Section 7 — Runtime rule readiness

- [ ] canonical flow je jasný
- [ ] operator zná default flow
- [ ] operator zná extended flow
- [ ] direct specialist-to-specialist jump je zakázaný
- [ ] raw output -> router je zakázané
- [ ] reviewer -> router je jasně gate-based
- [ ] každý hop má artifact trail

---

## Section 8 — Documentation readiness

- [ ] `00_OPERATOR_START_HERE.md` existuje
- [ ] `01_CONTROL_PLANE_RUNBOOK.md` existuje
- [ ] `12_SESSION_LOGGING_AND_ARTIFACT_REGISTRY_RUNBOOK.md` existuje
- [ ] `LIVE_OPERATOR_RUNBOOK.md` existuje
- [ ] `OPERATOR_QUICK_CARD.md` existuje
- [ ] `CANONICAL_REENTRY_TEMPLATE.md` existuje
- [ ] `STACK_DEV_LAYER_INPUT_TEMPLATE.md` existuje
- [ ] `SESSION_LOG_TEMPLATE.md` existuje

---

## Section 9 — Test readiness

- [ ] `TEST_01_router_same_input_10x.md` exists
- [ ] `TEST_02_router_reentry_same_input_10x.md` exists
- [ ] `TEST_03_flow_determinism_3_hops.md` exists
- [ ] backbone golden outputs are defined or ready to define
- [ ] test execution order is clear
- [ ] at least one smoke test has been run

---

## Final readiness rule

Control layer je ready pro reálný provoz, když:
- [ ] router je stabilní
- [ ] dev layer je stabilní
- [ ] operator support je jasný
- [ ] logging funguje
- [ ] manifest funguje
- [ ] claims gate funguje
- [ ] release gate funguje
- [ ] operator nemusí improvizovat mezi kroky

---

## Final verdict

- [ ] NOT_READY
- [ ] READY_WITH_FIXES
- [ ] READY
