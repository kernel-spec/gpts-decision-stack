# REVENUE_DAY_OPENING_CARD.md

## Purpose
Krátká opening karta pro den, kdy pracuješ v revenue lane.

Používej ji:
- na začátku revenue dne
- před prvním outbound flow
- před revenue review
- před live revenue session

---

## Open these first

### Control
- `SYSTEM_OS_MASTER`
- `STACK_DEV_LAYER`
- `OPERATOR_HELPER`
- `SESSION_LOGGER`
- `MANIFEST_KEEPER`

### Runtime docs
- `LIVE_OPERATOR_RUNBOOK.md`
- `OPERATOR_QUICK_CARD.md`
- `CANONICAL_REENTRY_TEMPLATE.md`
- `STACK_DEV_LAYER_INPUT_TEMPLATE.md`
- `SESSION_LOG_TEMPLATE.md`

### Revenue docs
- `OFFER_SINGLE_SOURCE_OF_TRUTH.md`
- `PRICING_AND_PACKAGING_MASTER.md`
- `SALES_CALL_SYSTEM.md`
- `LIST_BUILDING_MASTER_SPEC.md`
- `OUTBOUND_ASSET_MASTER_PACK.md`
- `DELIVERABILITY_AND_LAUNCH_POLICY.md`
- `POST_BATCH_DECISION_RULES.md`

---

## Check today’s revenue objective

Zapiš jednu hlavní věc:

- [ ] discovery
- [ ] ICP narrowing
- [ ] shortlist logic
- [ ] positioning / claims
- [ ] asset generation
- [ ] launch safety
- [ ] live batch
- [ ] post-batch review

---

## Check today’s current bottleneck

Vyplň:
- current bottleneck:
- current asset state:
- current list state:
- current launch state:
- current proof state:

---

## Gate awareness

### Before live wording
- use `CLAIMS_EVIDENCE_REVIEWER`

### Before live send
- use `RELEASE_GATE_REVIEWER`

### When artifact is messy
- use `HANDOFF_REVIEWER`

---

## Today’s do-not-break rules

- [ ] no direct specialist-to-specialist jump
- [ ] no raw output -> router
- [ ] no asset goes live without claims gate
- [ ] no batch goes live without release gate
- [ ] no session without log
- [ ] no session without manifest update

---

## Revenue day start block

```text
REVENUE_DAY_START:
DATE_LABEL:
SESSION_ID:
RUN_ID:
PRIMARY_OBJECTIVE:
CURRENT_BOTTLENECK:
CURRENT_ICP_STATUS:
CURRENT_LIST_STATUS:
CURRENT_POSITIONING_STATUS:
CURRENT_ASSET_STATUS:
CURRENT_LAUNCH_STATUS:
TODAY_SUCCESS_CRITERION:


⸻

Golden revenue rule

Nezačínej paid, scale, nebo druhou vrstvu.
Začni dalším nejmenším revenue bottleneckem.
