# 03_REVENUE_DISCOVERY_RUNBOOK.md

## Purpose
Dojít od offer contextu k:
- market snapshot
- primary ICP
- první narrow ICP card

## Entry criteria
- control plane locked
- session logging active
- backbone tests PASS
- offer context exists

## Flow
1. `SYSTEM_OS_MASTER`
2. `MARKET_SCOUT_OUTBOUND`
3. `STACK_DEV_LAYER`
4. `SYSTEM_OS_MASTER`
5. `STRUCTURAL_ENGINE`
6. `STACK_DEV_LAYER`
7. `SYSTEM_OS_MASTER`

## Inputs
- user_goal
- target_market
- time_horizon
- current_offer
- current bottleneck
- constraints

## Expected outputs
- `market_snapshot`
- `icp_card`

## Exit criteria
- 1 primary ICP
- backup hypotheses preserved if still alive
- 1 usable narrow ICP card
- clear next bottleneck

## Stop conditions
- market remains broad
- ICP card is not outbound-testable
- operator bypasses dev layer
