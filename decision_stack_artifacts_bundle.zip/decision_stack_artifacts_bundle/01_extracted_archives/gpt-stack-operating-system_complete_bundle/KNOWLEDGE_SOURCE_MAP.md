# KNOWLEDGE_SOURCE_MAP.md

## Purpose
Mapa knowledge zdrojů pro jednotlivé GPTs ve stacku.

Používej ji:
- při uploadu knowledge do Custom GPT Builderu
- při kontrole, co má být nahrané do kterého GPT
- při QA po update dokumentace
- při prevenci knowledge driftu

---

## Rule of thumb

Každý GPT má mít jen takovou knowledge, kterou skutečně potřebuje pro svou roli.

Nepřidávej:
- celé knihovny do role, která má být úzká
- cizí lane dokumenty do role, která je nemá používat
- quick cards jako primary authority, pokud existuje detailní source-of-truth soubor

---

## Knowledge classes

### Class A — Navigation knowledge
Používej pro:
- dokumentační navigátory
- library overview role

### Class B — Control knowledge
Používej pro:
- router
- dev layer
- operator support
- logging / manifest support

### Class C — Lane knowledge
Používej pro:
- revenue lane
- prompt ops lane
- product lane
- delivery lane

### Class D — Review knowledge
Používej pro:
- handoff review
- claims review
- release gate

### Class E — Audit knowledge
Používej pro:
- backbone testing
- registry audit
- scope guard

---

## GPT-by-GPT map

## `LIBRARY_GUIDE`
### Required knowledge
- `MASTER_LIBRARY_INDEX.md`
- `STACK_DOCUMENTATION_MASTER.md`
- `STACK_DOCUMENTATION_SPLIT_PLAN.md`

### Purpose
- library mode
- architecture mode
- split mode

### Do not add by default
- all runbooks
- all test files
- all policy files

---

## `SYSTEM_OS_MASTER`
### Required knowledge
- none required if rules are fully in Instructions

### Optional support knowledge
- `FINAL_CORE_IMPORT_REGISTRY_CARD.md`
- `MASTER_LIBRARY_INDEX.md`

### Purpose
- router consistency
- awareness of installed stack

### Do not add by default
- lane runbooks as primary routing source
- knowledge that tempts the router to solve tasks

---

## `STACK_DEV_LAYER`
### Required knowledge
- none required if output contract is fully in Instructions

### Optional support knowledge
- `12_SESSION_LOGGING_AND_ARTIFACT_REGISTRY_RUNBOOK.md`

### Purpose
- packaging consistency
- artifact / session discipline

---

## `OPERATOR_HELPER`
### Recommended knowledge
- `LIVE_OPERATOR_RUNBOOK.md`
- `OPERATOR_QUICK_CARD.md`
- `IOS_TAP_BY_TAP_OPERATOR_CARD.md`
- `SESSION_CLOSEOUT_CHECKLIST.md`

### Purpose
- exact operator moves
- runtime guidance

---

## `SESSION_LOGGER`
### Recommended knowledge
- `12_SESSION_LOGGING_AND_ARTIFACT_REGISTRY_RUNBOOK.md`
- `SESSION_LOG_TEMPLATE.md`

### Purpose
- consistent hop logs
- verdict discipline

---

## `MANIFEST_KEEPER`
### Recommended knowledge
- `12_SESSION_LOGGING_AND_ARTIFACT_REGISTRY_RUNBOOK.md`

### Purpose
- session manifest discipline
- artifact trail consistency

---

## `HANDOFF_REVIEWER`
### Recommended knowledge
- `HANDOFF_REVIEW_POLICY.md`
- `HANDOFF_REVIEWER_USE_GUIDE.md`

---

## `CLAIMS_EVIDENCE_REVIEWER`
### Recommended knowledge
- `CLAIMS_EVIDENCE_POLICY.md`
- `CLAIMS_EVIDENCE_REVIEWER_USE_GUIDE.md`

---

## `RELEASE_GATE_REVIEWER`
### Recommended knowledge
- `RELEASE_GATE_POLICY.md`
- `RELEASE_GATE_REVIEWER_USE_GUIDE.md`

---

## Revenue core roles

## `MARKET_SCOUT_OUTBOUND`
### Recommended knowledge
- `OFFER_SINGLE_SOURCE_OF_TRUTH.md`
- `03_REVENUE_DISCOVERY_RUNBOOK.md`

## `STRUCTURAL_ENGINE`
### Recommended knowledge
- `OFFER_SINGLE_SOURCE_OF_TRUTH.md`
- `03_REVENUE_DISCOVERY_RUNBOOK.md`

## `LIST_BUILDER`
### Recommended knowledge
- `LIST_BUILDING_MASTER_SPEC.md`
- `04_ICP_TO_SHORTLIST_RUNBOOK.md`

## `POSITIONING_POLICE`
### Recommended knowledge
- `OFFER_SINGLE_SOURCE_OF_TRUTH.md`
- `05_POSITIONING_AND_CLAIMS_RUNBOOK.md`

## `ASSET_ENGINE`
### Recommended knowledge
- `OUTBOUND_ASSET_MASTER_PACK.md`
- `06_ASSET_GENERATION_RUNBOOK.md`

## `DELIVERABILITY_GUARD`
### Recommended knowledge
- `DELIVERABILITY_AND_LAUNCH_POLICY.md`
- `07_LAUNCH_SAFETY_RUNBOOK.md`

## `PERFORMANCE_MEMORY`
### Recommended knowledge
- `POST_BATCH_DECISION_RULES.md`
- `08_POST_BATCH_DECISION_RUNBOOK.md`

---

## Prompt ops roles

## `PROMPT_AUTHOR`
### Recommended knowledge
- `09_PROMPT_OPS_RUNBOOK.md`

## `PROMPT_QA_CRITIC`
### Recommended knowledge
- `09_PROMPT_OPS_RUNBOOK.md`

## `PROMPT_PACK_EXPORTER`
### Recommended knowledge
- `09_PROMPT_OPS_RUNBOOK.md`

---

## Product roles

## `SAAS_FEATURE_PACK_ENGINE`
### Recommended knowledge
- `10_PRODUCT_BUILD_RUNBOOK.md`

## `Architecture Copilot`
### Recommended knowledge
- `10_PRODUCT_BUILD_RUNBOOK.md`

## `Staff Engineer OS`
### Recommended knowledge
- `10_PRODUCT_BUILD_RUNBOOK.md`

## `Founder OS`
### Recommended knowledge
- `10_PRODUCT_BUILD_RUNBOOK.md`

---

## Audit / control-plus roles

## `BACKBONE_TESTER`
### Recommended knowledge
- `02_STACK_DETERMINISM_RUNBOOK.md`
- `STACK_FUNCTIONALITY_MASTER_TESTPLAN.md`

## `REGISTRY_AUDITOR`
### Recommended knowledge
- `12_SESSION_LOGGING_AND_ARTIFACT_REGISTRY_RUNBOOK.md`

## `SCOPE_GUARD`
### Recommended knowledge
- `OFFER_SINGLE_SOURCE_OF_TRUTH.md`
- `PRICING_AND_PACKAGING_MASTER.md`
- `MAXIMUM_VIABLE_CONTROL_LAYER.md`

---

## Knowledge hygiene rules

### Rule 1
Primary authority files mají přednost před quick cards.

### Rule 2
Navigation GPT nemá suplovat specialist role.

### Rule 3
Router nemá být zahlcen lane dokumentací.

### Rule 4
Review GPT má mít policy knowledge, ne celou lane knihovnu.

### Rule 5
Po update dokumentace zkontroluj i relevantní knowledge upload.

---

## Knowledge source block

```text
KNOWLEDGE_SOURCE_MAP_STATUS:
DATE_LABEL:
GPT_NAME:
KNOWLEDGE_CLASS:
REQUIRED_FILES:
OPTIONAL_FILES:
PRIMARY_AUTHORITY_PRESENT:
OVERLOAD_RISK:
STATUS:
NOTES:
