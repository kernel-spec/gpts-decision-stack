# REVIEW_GATE_DECISION_CARD.md

## Purpose
Krátká rozhodovací karta:
- který reviewer použít
- kdy ho použít
- co od něj čekat
- kdy nepokračovat dál

---

## 1. HANDOFF_REVIEWER
### Použij když
- output je nečistý
- artifact identity je slabá
- next step je nejasný
- operátor by musel hádat
- output je drahý nebo riskantní pro další krok

### Nepoužívej když
- potřebuješ vybrat další GPT
- potřebuješ claims review
- potřebuješ release verdict

### Verdicts
- `PASS`
- `PASS_WITH_MINOR_FIXES`
- `FAIL`

### Rule
`FAIL` = nepokračuj dál bez opravy.

---

## 2. CLAIMS_EVIDENCE_REVIEWER
### Použij když
- jde ven offer copy
- jde ven CTA
- jde ven outbound asset
- wording může být silnější než proof
- hrozí invented proof risk
- potřebuješ strongest allowed claim

### Nepoužívej když
- chceš jen handoff completeness
- chceš release decision
- chceš routovat

### Verdicts
- `SAFE`
- `SAFE_WITH_FIXES`
- `NOT_SAFE`

### Rule
`NOT_SAFE` = nic neposílej live.

---

## 3. RELEASE_GATE_REVIEWER
### Použij když
- jde ven live batch
- jde ven export
- jde ven execution handoff
- chceš final go/no-go

### Nepoužívej když
- ještě chybí core artifact
- ještě nejsi po claims review
- potřebuješ jen content review

### Verdicts
- `READY`
- `READY_WITH_FIXES`
- `NOT_READY`

### Rule
`NOT_READY` = nic nespouštěj.

---

## Decision shortcut

### Potřebuju zkontrolovat předatelnost artifactu
-> `HANDOFF_REVIEWER`

### Potřebuju zkontrolovat wording / proof / claims
-> `CLAIMS_EVIDENCE_REVIEWER`

### Potřebuju final go/no-go pro live krok
-> `RELEASE_GATE_REVIEWER`

---

## Golden rule
Reviewer je gate, ne router.
Reviewer neurčuje další specialistu.
Reviewer nezaměňuj za `SYSTEM_OS_MASTER`.
