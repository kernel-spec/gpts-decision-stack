# FIRST_10_MINUTES_OPERATOR_SETUP.md

## Purpose
Praktický setup card pro prvních 10 minut před operátorskou prací.

Používej ho:
- na začátku dne
- před první live session
- při návratu do stacku po pauze
- když chceš rychle ověřit, že máš vše připravené

---

## Minute 1 — Open core control chats

Otevři:
- `SYSTEM_OS_MASTER`
- `STACK_DEV_LAYER`
- `OPERATOR_HELPER`
- `SESSION_LOGGER`
- `MANIFEST_KEEPER`

---

## Minute 2 — Open navigation and runtime docs

Otevři:
- `LIVE_OPERATOR_RUNBOOK.md`
- `OPERATOR_QUICK_CARD.md`
- `CANONICAL_REENTRY_TEMPLATE.md`
- `STACK_DEV_LAYER_INPUT_TEMPLATE.md`
- `SESSION_LOG_TEMPLATE.md`

---

## Minute 3 — Check today’s lane

Rozhodni:
- [ ] revenue day
- [ ] testing day
- [ ] prompt ops day
- [ ] product day

---

## Minute 4 — Open lane-specific docs

### If revenue day
Otevři:
- `OFFER_SINGLE_SOURCE_OF_TRUTH.md`
- `OUTBOUND_ASSET_MASTER_PACK.md`
- `DELIVERABILITY_AND_LAUNCH_POLICY.md`
- relevant revenue runbook

### If testing day
Otevři:
- `STACK_FUNCTIONALITY_MASTER_TESTPLAN.md`
- `TEST_EXECUTION_ORDER_CARD.md`
- relevant `TEST_*` soubory

### If prompt ops day
Otevři:
- `09_PROMPT_OPS_RUNBOOK.md`

### If product day
Otevři:
- `10_PRODUCT_BUILD_RUNBOOK.md`

---

## Minute 5 — Confirm session start

Zapiš:
- `SESSION_ID`
- `RUN_ID`
- lane
- user_goal
- target_market
- time_horizon

---

## Minute 6 — Check control rules

Potvrď:
- [ ] router = `SYSTEM_OS_MASTER`
- [ ] raw output půjde do `STACK_DEV_LAYER`
- [ ] reviewer nebude použit jako router
- [ ] každý hop bude zalogovaný
- [ ] manifest bude aktualizovaný

---

## Minute 7 — Check gates

Potvrď:
- [ ] `HANDOFF_REVIEWER` je připravený
- [ ] `CLAIMS_EVIDENCE_REVIEWER` je připravený
- [ ] `RELEASE_GATE_REVIEWER` je připravený

---

## Minute 8 — Check current bottleneck

Zapiš jednu větu:
- current bottleneck:
- next intended lane step:

---

## Minute 9 — Check stop risks

- [ ] nehrozí direct specialist-to-specialist jump
- [ ] nehrozí raw output -> router
- [ ] nehrozí live send bez gates
- [ ] nehrozí nejasný session start

---

## Minute 10 — Start

Teď otevři:
- `SYSTEM_OS_MASTER`, pokud potřebuješ další business krok
- `LIBRARY_GUIDE`, pokud ještě nevíš, jaký dokument otevřít
- `OPERATOR_HELPER`, pokud nevíš, co přesně udělat teď

---

## Final start block

```text
START_READY_CHECK:
SESSION_ID:
RUN_ID:
LANE:
USER_GOAL:
TARGET_MARKET:
TIME_HORIZON:
CURRENT_BOTTLENECK:
NEXT_INTENDED_STEP:
CONTROL_READY:
DOCS_READY:
GATES_READY:
START_STATUS:
