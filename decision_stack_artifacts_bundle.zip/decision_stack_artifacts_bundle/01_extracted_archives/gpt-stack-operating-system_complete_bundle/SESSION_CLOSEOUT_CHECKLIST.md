# SESSION_CLOSEOUT_CHECKLIST.md

## Purpose
Praktický checklist pro uzavření jedné session.

Používej ho:
- po každém delším runtime flow
- po live revenue session
- po testovacím běhu
- před koncem dne, pokud session končí

---

## Section 1 — Flow completion check

- [ ] poslední hop skončil jasným stavem
- [ ] není otevřený nejasný další krok
- [ ] current bottleneck je pojmenovaný
- [ ] next action je explicitně zapsaná
- [ ] session není ukončená uprostřed neuzavřeného reviewer kroku

---

## Section 2 — Artifact check

- [ ] poslední specialista má raw output
- [ ] raw output prošel přes `STACK_DEV_LAYER`
- [ ] normalized artifact existuje
- [ ] re-entry prompt existuje
- [ ] artifact_id je zapsaný
- [ ] completed_artifact ne driftuje vůči artifact_id
- [ ] file labels nebo files jsou zapsané

---

## Section 3 — Logging check

- [ ] poslední hop je v `SESSION_LOGGER`
- [ ] verdict je zapsaný
- [ ] drift type je zapsaný
- [ ] next bottleneck je zapsaný
- [ ] log není jen v chatu, ale i v session logu

---

## Section 4 — Manifest check

- [ ] `MANIFEST_KEEPER` byl aktualizovaný
- [ ] session manifest obsahuje poslední krok
- [ ] artifact trail je úplný
- [ ] final status session je jasný
- [ ] manifest odpovídá reálnému průběhu

---

## Section 5 — Review gate check

### Pokud proběhl handoff review
- [ ] verdict je uložený
- [ ] blocker je uložený
- [ ] next action je uložená

### Pokud proběhl claims review
- [ ] claims verdict je uložený
- [ ] strongest allowed claim je uložený
- [ ] forbidden claims jsou uložené

### Pokud proběhl release gate
- [ ] release verdict je uložený
- [ ] blockers jsou uložené
- [ ] release_now status je uložený

---

## Section 6 — Revenue session closeout

Použij jen pokud šlo o revenue lane.

- [ ] ICP status je jasný
- [ ] shortlist status je jasný
- [ ] positioning status je jasný
- [ ] asset status je jasný
- [ ] launch status je jasný
- [ ] post-batch next action je jasná

---

## Section 7 — Test session closeout

Použij jen pokud šlo o test.

- [ ] expected vs actual je uložené
- [ ] PASS / FAIL je uložený
- [ ] dominant drift type je uložený
- [ ] repair focus je uložený
- [ ] další test nebo repair step je jasný

---

## Final closeout block

```text
SESSION_CLOSEOUT:
SESSION_ID:
RUN_ID:
FINAL_STATUS:
LAST_COMPLETED_STEP:
FINAL_BOTTLENECK:
NEXT_ACTION:
LOG_COMPLETE:
MANIFEST_UPDATED:
ARTIFACT_TRAIL_COMPLETE:
RELEASE_STATUS:
NOTES:


⸻

Hard rule

Session není správně uzavřená, dokud:
	•	poslední hop není zalogovaný
	•	manifest není aktualizovaný
	•	next action není zapsaná
