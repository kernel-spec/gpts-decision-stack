# STACK_ROLES_AND_BOUNDARIES_CARD.md

## Purpose
Krátká karta rolí a jejich hranic.

Používej ji:
- když si nejsi jistý, který GPT co dělá
- při debugování boundary violation
- při import QA
- při operátorském onboarding

---

## Control plane roles

### `SYSTEM_OS_MASTER`
Dělá:
- routing
- výběr přesně jednoho NEXT_GPT
- strict handoff pack

Nedělá:
- specialist work
- artifact normalization
- review
- logging

### `STACK_DEV_LAYER`
Dělá:
- normalized artifact
- re-entry prompt
- file labels / files
- packaging raw outputu

Nedělá:
- routing
- strategy redesign
- business solving

---

## Operator support roles

### `OPERATOR_HELPER`
Dělá:
- co otevřít
- co vložit
- co zkopírovat
- jak neporušit flow

Nedělá:
- routing
- specialist work
- claims review

### `SESSION_LOGGER`
Dělá:
- hop log
- verdict log
- drift type log

Nedělá:
- routing
- manifest management
- business solving

### `MANIFEST_KEEPER`
Dělá:
- session manifest
- artifact trail summary
- session state snapshot

Nedělá:
- routing
- log judgement
- business solving

---

## Review gates

### `HANDOFF_REVIEWER`
Dělá:
- handoff readiness
- artifact completeness
- next-step usability

Nedělá:
- routing
- authoring full replacement artifact
- claims review

### `CLAIMS_EVIDENCE_REVIEWER`
Dělá:
- claim safety
- proof safety
- strongest allowed claim
- forbidden claims

Nedělá:
- routing
- offer strategy redesign
- release decision

### `RELEASE_GATE_REVIEWER`
Dělá:
- READY / READY_WITH_FIXES / NOT_READY
- blockers
- minimum fix order

Nedělá:
- routing
- claims review
- strategy authoring

---

## Revenue core roles

### `MARKET_SCOUT_OUTBOUND`
Dělá:
- market / wedge / ICP discovery

### `STRUCTURAL_ENGINE`
Dělá:
- ICP card
- offer structure
- narrow testable framing

### `LIST_BUILDER`
Dělá:
- shortlist logic
- sourcing logic
- filters / exclusions
- tracker logic

### `POSITIONING_POLICE`
Dělá:
- positioning discipline
- CTA discipline
- vocabulary / scope drift audit

### `ASSET_ENGINE`
Dělá:
- first asset generation

### `REWRITE_ENGINE`
Dělá:
- rewrite existing asset

### `SUGGESTION_ENGINE`
Dělá:
- diagnose asset without rewrite

### `DELIVERABILITY_GUARD`
Dělá:
- sending safety
- DNS baseline
- ramp logic

### `PERFORMANCE_MEMORY`
Dělá:
- post-batch verdict
- scale / optimize / kill logic

---

## Prompt ops roles

### `PROMPT_AUTHOR`
Dělá:
- prompt draft

### `PROMPT_QA_CRITIC`
Dělá:
- prompt QA

### `PROMPT_PACK_EXPORTER`
Dělá:
- export-ready prompt pack

---

## Product roles

### `SAAS_FEATURE_PACK_ENGINE`
Dělá:
- feature pack

### `Architecture Copilot`
Dělá:
- architecture choice

### `Staff Engineer OS`
Dělá:
- engineering review

### `Founder OS`
Dělá:
- execution sequencing

### `ENTERPRISE_LAYER`
Dělá:
- enterprise-level governance framing

---

## Control-plus roles

### `LIBRARY_GUIDE`
Dělá:
- navigaci po dokumentaci

Nedělá:
- routing
- runtime packy
- specialist work

### `BACKBONE_TESTER`
Dělá:
- determinism / regression test verdict

### `REGISTRY_AUDITOR`
Dělá:
- artifact trail audit

### `SCOPE_GUARD`
Dělá:
- in-scope / change-order / out-of-scope verdict

---

## Golden boundary rules

1. router = pouze `SYSTEM_OS_MASTER`
2. raw output = vždy do `STACK_DEV_LAYER`
3. reviewer = gate, ne router
4. operator helper = guide, ne business solver
5. library guide = doc navigator, ne runtime orchestrator

---

## Boundary violation signal
Pokud role začne dělat práci jiné role, ber to jako:
- `boundary_violation`
- a řeš to dřív, než budeš pokračovat dál
