# MAXIMUM_VIABLE_CONTROL_LAYER.md

## Purpose
Tento soubor definuje maximum viable control layer — nejmenší ještě provozně uzavřenou řídicí vrstvu stacku.

Používej ho jako:
- definici minimální control vrstvy pro reálný provoz
- hranici mezi core control a control-plus rozšířeními
- referenci pro import pořadí a operátorské nastavení

---

## Definition

Maximum viable control layer je nejmenší sada GPTs a pravidel, která už umí:

- řídit další krok
- zabalit raw output do runtime-safe formy
- vést operátora bez guesswork
- logovat každý hop
- držet manifest a artifact trail
- zastavit špatný handoff
- zastavit claims risk
- zastavit unsafe release

---

## Included roles

### 1. `SYSTEM_OS_MASTER`
Jediný router.

Řeší:
- výběr přesně jednoho dalšího GPT
- strict handoff pack
- scope-preserving routing

### 2. `STACK_DEV_LAYER`
Normalizační a re-entry vrstva.

Řeší:
- normalized artifact
- re-entry prompt
- file labels / files
- artifact trail step

### 3. `OPERATOR_HELPER`
Operátorský pomocník.

Řeší:
- co otevřít
- co vložit
- co zkopírovat
- kdy jít do routeru / dev vrstvy / revieweru

### 4. `SESSION_LOGGER`
Session hop logger.

Řeší:
- PASS / FAIL log
- drift type
- next bottleneck log

### 5. `MANIFEST_KEEPER`
Session manifest keeper.

Řeší:
- session manifest
- artifact list
- verdict trail
- session state

### 6. `HANDOFF_REVIEWER`
Handoff gate.

Řeší:
- artifact usability
- completeness
- handoff readiness

### 7. `CLAIMS_EVIDENCE_REVIEWER`
Claims gate.

Řeší:
- proof safety
- claim wording risk
- strongest allowed claim
- forbidden claims

### 8. `RELEASE_GATE_REVIEWER`
Release gate.

Řeší:
- READY / READY_WITH_FIXES / NOT_READY
- blockers
- minimum fix order
- release decision

---

## What this layer covers

### Routing control
Pouze `SYSTEM_OS_MASTER` smí určit další GPT.

### Packaging control
Po každém specialistovi jde output do `STACK_DEV_LAYER`.

### Operator control
Operátor ví:
- co otevřít
- co vložit
- co zkopírovat
- kdy zastavit

### Registry control
Každý hop má:
- session log
- artifact identity
- verdict
- next bottleneck

### Release control
Nic nejde live bez:
- claims gate
- release gate

---

## Canonical runtime flow

### Default
`SYSTEM_OS_MASTER -> specialista -> STACK_DEV_LAYER -> SYSTEM_OS_MASTER`

### Extended
`SYSTEM_OS_MASTER -> specialista -> STACK_DEV_LAYER -> reviewer -> SYSTEM_OS_MASTER`

---

## Hard rules

1. router = pouze `SYSTEM_OS_MASTER`
2. po každém specialistovi musí přijít `STACK_DEV_LAYER`
3. žádný direct specialist-to-specialist jump
4. žádný raw output nejde přímo do routeru
5. reviewer = gate, ne router
6. každý hop musí mít log
7. každý live krok musí mít release verdict

---

## What is not included

Do maximum viable control layer ještě nepatří:

- `BACKBONE_TESTER`
- `REGISTRY_AUDITOR`
- `SCOPE_GUARD`
- `LIBRARY_GUIDE`
- governance role
- pattern extraction role
- finance / allocation role

Tyto role jsou control-plus vrstva, ne minimum pro první provoz.

---

## Why this is “maximum viable”
Není to absolutní minimum.
Je to nejmenší vrstva, která je ještě:
- lidsky použitelná
- auditovatelná
- bezpečná pro live provoz
- stabilní pro iPhone operator workflow

---

## Success condition
Control layer je správně nasazená, když:
- operátor nemusí hádat další krok
- raw output nikdy neobchází dev vrstvu
- handoff, claims a release mají vlastní gates
- session má log i manifest
- revenue lane jde spustit bez improvizace
