# CONTROL_PLUS_AUDIT_LAYER_OVERVIEW.md

## Purpose
Tento soubor popisuje control-plus / audit layer — rozšířenou vrstvu nad maximum viable control layer.

Používej ho jako:
- přehled auditních a guard rolí
- mapu rozšířené control vrstvy
- referenci pro vyšší disciplínu a auditovatelnost

---

## What this layer is
Tato vrstva není nutná pro první live provoz.
Je určena pro chvíli, kdy chceš:
- testovat determinismus
- auditovat registry
- hlídat scope creep
- navigovat dokumentaci bez chaosu

---

## Included roles

### `LIBRARY_GUIDE`
Navigátor dokumentace.

Řeší:
- co otevřít
- kam v knihovně patří téma
- kde jsi v dokumentaci
- jaké pořadí dokumentů držet

### `BACKBONE_TESTER`
Determinism gate.

Řeší:
- router stability
- re-entry stability
- 3-hop flow stability
- dominant drift type

Vrací:
- `PASS`
- `FAIL`

### `REGISTRY_AUDITOR`
Artifact trail audit.

Řeší:
- session / artifact consistency
- missing evidence
- manifest correctness
- registry health

Vrací:
- `REGISTRY_CLEAN`
- `REGISTRY_WITH_GAPS`
- `REGISTRY_BROKEN`

### `SCOPE_GUARD`
Scope control gate.

Řeší:
- in-scope
- change-order
- out-of-scope

Vrací:
- `IN_SCOPE`
- `CHANGE_ORDER`
- `OUT_OF_SCOPE`

---

## Why this layer matters
Bez této vrstvy může stack fungovat.
S touto vrstvou je ale:
- lépe auditovatelný
- lépe testovatelný
- lépe škálovatelný
- méně náchylný ke scope driftu a dokumentačnímu chaosu

---

## When to add it
Přidej tuto vrstvu, když:
- už běží maximum viable control layer
- backbone testy se stávají důležité
- roste objem sessions a artefaktů
- scope creep začíná být reálný problém
- dokumentace je rozsáhlá a operátor se v ní ztrácí
