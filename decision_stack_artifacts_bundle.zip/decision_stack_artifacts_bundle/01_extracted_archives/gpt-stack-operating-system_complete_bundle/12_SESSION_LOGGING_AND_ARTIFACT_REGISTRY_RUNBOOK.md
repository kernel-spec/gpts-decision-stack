# 12_SESSION_LOGGING_AND_ARTIFACT_REGISTRY_RUNBOOK.md

## Purpose
Zamknout session logging a artifact registry discipline.

## Required entities
- `SESSION_ID`
- `RUN_ID`
- `STEP_ID`
- `artifact_id`
- `artifact_type`
- `timestamp_label`
- `verdict`
- `drift_type`
- `next_bottleneck`

## SESSION_ID format
`session_YYYYMMDD_01`

## Timestamp format
`YYYY-MM-DD__manual-session`

## Every hop must keep
1. raw input
2. raw output
3. normalized artifact
4. re-entry prompt
5. verdict

## Raw vs normalized
- raw output = preserved 1:1
- normalized artifact = structured derived layer
- raw and normalized must not be confused

## Verdict vocabulary
- `PASS`
- `PASS_WITH_MINOR_FIXES`
- `FAIL`

## Drift vocabulary
- `none`
- `route_drift`
- `schema_drift`
- `narrowing_drift`
- `wording_drift`
- `format_drift`
- `handoff_failure`
- `boundary_violation`
- `operator_confusion`
- `outcome_failure`
