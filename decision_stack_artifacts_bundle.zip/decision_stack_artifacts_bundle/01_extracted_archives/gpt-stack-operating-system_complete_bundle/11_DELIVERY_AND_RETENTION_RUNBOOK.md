# 11_DELIVERY_AND_RETENTION_RUNBOOK.md

## Purpose
Řídit delivery, retention a ops automation layer.

## Flow
1. `SYSTEM_OS_MASTER`
2. `DELIVERY_SOP_ENGINE`
3. `STACK_DEV_LAYER`
4. `SYSTEM_OS_MASTER`
5. `RETENTION_ENGINE`
6. `STACK_DEV_LAYER`
7. `SYSTEM_OS_MASTER`
8. `OPS_AUTOMATOR`
9. `STACK_DEV_LAYER`

## Expected outputs
- delivery SOP
- retention logic
- ops automation spec

## Stop conditions
- no usable SOP
- retention logic is vague
- automation spec is disconnected from real workflow
