# OPERATOR_QUICK_CARD.md

## 1 rule
Po každém specialistovi se vrať přes `STACK_DEV_LAYER`.

## 1 flow
`SYSTEM_OS_MASTER -> specialista -> STACK_DEV_LAYER -> SYSTEM_OS_MASTER`

## 1 logic
- nevíš další business krok -> `SYSTEM_OS_MASTER`
- máš raw output -> `STACK_DEV_LAYER`
- nevíš co kam vložit -> `OPERATOR_HELPER`
- chceš log -> `SESSION_LOGGER`
- chceš manifest -> `MANIFEST_KEEPER`

## Stop
Když musíš hádat další krok, zastav a vrať se do routeru.
