# 10_PRODUCT_BUILD_RUNBOOK.md

## Purpose
Řídit product/build lane od feature packu po execution plan.

## Flow
1. `SYSTEM_OS_MASTER`
2. `SAAS_FEATURE_PACK_ENGINE`
3. `STACK_DEV_LAYER`
4. `SYSTEM_OS_MASTER`
5. `Architecture Copilot`
6. `STACK_DEV_LAYER`
7. `SYSTEM_OS_MASTER`
8. `Staff Engineer OS`
9. `STACK_DEV_LAYER`
10. `SYSTEM_OS_MASTER`
11. `Founder OS`
12. `RELEASE_GATE_REVIEWER`
13. `STACK_DEV_LAYER`

## Expected outputs
- feature pack
- architecture recommendation
- engineering review
- execution plan
- release verdict

## Stop conditions
- outputs are abstract only
- execution plan is not usable
- no release verdict
