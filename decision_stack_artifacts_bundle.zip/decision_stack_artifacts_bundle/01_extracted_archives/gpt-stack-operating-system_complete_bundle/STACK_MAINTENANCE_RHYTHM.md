# STACK_MAINTENANCE_RHYTHM.md

## Purpose
Definovat udržitelný maintenance rytmus pro celý stack.

Používej ho jako:
- cadence dokument
- ops maintenance guide
- review rytmus pro control layer, docs a lanes
- stabilizační plán po live spuštění

---

## Daily rhythm

### Every day
- zkontroluj `LIVE_OPERATOR_RUNBOOK.md`
- zkontroluj dnešní lane objective
- otevři core control chats
- založ nebo potvrď `SESSION_ID`
- drž session log a manifest průběžně
- na konci dne proveď end-of-day closeout

### Daily operator files
- `LIVE_OPERATOR_RUNBOOK.md`
- `OPERATOR_QUICK_CARD.md`
- `SESSION_LOG_TEMPLATE.md`
- `BLOCKERS_AND_DRIFT_LOG.md`
- `END_OF_DAY_OPERATOR_CARD.md`

---

## Weekly rhythm

### Once per week
- proveď weekly stack review
- zkontroluj dominant drift types
- zkontroluj open blockers
- aktualizuj next priorities
- rozhodni, co se opravuje a co ne

### Weekly files
- `WEEKLY_STACK_REVIEW_TEMPLATE.md`
- `STACK_STATUS_TEMPLATE.md`
- `MASTER_EXECUTION_CHECKLIST.md`

---

## Bi-weekly rhythm

### Every 2 weeks
- zkontroluj control layer readiness
- zkontroluj release rules
- zkontroluj registry health
- zkontroluj documentation drift
- zkontroluj import registry relevance

### Bi-weekly files
- `CONTROL_LAYER_READINESS_CHECKLIST.md`
- `RELEASE_GATE_POLICY.md`
- `FINAL_CORE_IMPORT_REGISTRY_CARD.md`
- `MASTER_LIBRARY_INDEX.md`

---

## Monthly rhythm

### Once per month
- projdi split plan vs real library
- zkontroluj duplicity dokumentace
- rozhodni, které soubory zastaraly
- vyčisti referenční vrstvu
- zkontroluj, jestli overview files stále sedí

### Monthly files
- `STACK_DOCUMENTATION_MASTER.md`
- `STACK_DOCUMENTATION_SPLIT_PLAN.md`
- `MASTER_LIBRARY_INDEX.md`

---

## After every live incident

- proveď incident response
- proveď postmortem
- přidej nový guardrail, pokud je potřeba
- aktualizuj checklist nebo card, pokud failure mohl být chycen dřív

### Incident files
- `INCIDENT_RESPONSE_CARD.md`
- `LIVE_SESSION_POSTMORTEM_TEMPLATE.md`
- `COMMON_FAILURE_MODES.md`
- `STACK_DRIFT_TRIAGE_CARD.md`

---

## After every significant router or dev change

- proveď backbone tests
- porovnej drift
- nechoď live bez re-testu

### Required test files
- `TEST_01_router_same_input_10x.md`
- `TEST_02_router_reentry_same_input_10x.md`
- `TEST_03_flow_determinism_3_hops.md`

---

## Maintenance principle

### Keep stable
- control plane
- dev layer contract
- review verdict vocab
- canonical flow

### Review regularly
- docs navigation
- split plan relevance
- checklist accuracy
- live operator cards

### Change carefully
- router rules
- dev output contract
- release policy
- claims gate strictness

---

## Maintenance block

```text
STACK_MAINTENANCE_STATUS:
DATE_LABEL:
DAILY_RHYTHM:
WEEKLY_RHYTHM:
BIWEEKLY_RHYTHM:
MONTHLY_RHYTHM:
OPEN_MAINTENANCE_ITEMS:
LAST_BACKBONE_TEST:
LAST_WEEKLY_REVIEW:
LAST_DOC_CLEANUP:
NEXT_MAINTENANCE_PRIORITY:


⸻

Hard rule

Neměň router nebo dev layer a zároveň nevynechávej re-test.
Maintenance bez re-testu není maintenance, ale riziko.
