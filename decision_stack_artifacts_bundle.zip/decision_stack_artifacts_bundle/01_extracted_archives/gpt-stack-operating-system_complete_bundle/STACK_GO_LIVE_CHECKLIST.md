# STACK_GO_LIVE_CHECKLIST.md

## Purpose
Finální checklist před skutečným live provozem stacku.

Používej ho:
- před prvním live revenue dnem
- před prvním live prompt exportem
- před prvním live product planning během
- před jakýmkoli tvrzením, že stack je ready na produkční provoz

---

## Section 1 — Control plane readiness

- [ ] `SYSTEM_OS_MASTER` je zamčený
- [ ] `STACK_DEV_LAYER` je zamčený
- [ ] router je jediná routing autorita
- [ ] dev layer neroutuje
- [ ] canonical hop je jasný
- [ ] direct specialist-to-specialist jump je zakázaný
- [ ] raw output -> router je zakázané

---

## Section 2 — Operator readiness

- [ ] `OPERATOR_HELPER` je připravený
- [ ] `SESSION_LOGGER` je připravený
- [ ] `MANIFEST_KEEPER` je připravený
- [ ] operátor má otevřené správné core soubory
- [ ] operátor zná default flow
- [ ] operátor zná extended flow
- [ ] operátor umí session otevřít i uzavřít bez improvizace

---

## Section 3 — Review gates readiness

- [ ] `HANDOFF_REVIEWER` je připravený
- [ ] `CLAIMS_EVIDENCE_REVIEWER` je připravený
- [ ] `RELEASE_GATE_REVIEWER` je připravený
- [ ] reviewer verdict vocabulary je zamčená
- [ ] reviewer role nejsou zaměňované za router

---

## Section 4 — Documentation readiness

- [ ] `00_OPERATOR_START_HERE.md` existuje
- [ ] `01_CONTROL_PLANE_RUNBOOK.md` existuje
- [ ] `12_SESSION_LOGGING_AND_ARTIFACT_REGISTRY_RUNBOOK.md` existuje
- [ ] `LIVE_OPERATOR_RUNBOOK.md` existuje
- [ ] `OPERATOR_QUICK_CARD.md` existuje
- [ ] `MASTER_LIBRARY_INDEX.md` existuje
- [ ] `FINAL_CORE_IMPORT_REGISTRY_CARD.md` existuje

---

## Section 5 — Test readiness

- [ ] `TEST_01_router_same_input_10x.md` proběhl
- [ ] `TEST_02_router_reentry_same_input_10x.md` proběhl
- [ ] `TEST_03_flow_determinism_3_hops.md` proběhl
- [ ] backbone verdict je PASS
- [ ] nejsou otevřené kritické drift issues
- [ ] repair focus z předchozích FAIL je uzavřený

---

## Section 6 — Revenue live readiness

- [ ] offer source of truth existuje
- [ ] pricing a packaging existují
- [ ] shortlist logic existuje
- [ ] positioning a claims discipline existují
- [ ] asset pack existuje
- [ ] deliverability baseline existuje
- [ ] post-batch decision logic existuje

---

## Section 7 — Registry readiness

- [ ] session logs jsou konzistentní
- [ ] manifest discipline funguje
- [ ] artifact trail je replay-safe
- [ ] raw output je odlišovaný od normalized artifact
- [ ] re-entry prompt je vždy dohledatelný
- [ ] artifact_id je stabilní

---

## Section 8 — Live risk stop check

- [ ] žádný batch nepůjde ven bez claims gate
- [ ] žádný batch nepůjde ven bez release gate
- [ ] žádný asset nepůjde ven bez version clarity
- [ ] žádný operátor nebude hádat další krok
- [ ] žádný reviewer nebude používaný jako router

---

## Final go-live block

```text
STACK_GO_LIVE_STATUS:
CONTROL_PLANE:
OPERATOR_RUNTIME:
REVIEW_GATES:
DOCUMENTATION:
TEST_LAYER:
REVENUE_LIVE_READINESS:
REGISTRY:
OPEN_BLOCKERS:
FINAL_VERDICT:
NEXT_ACTION:


⸻

Allowed final verdicts
	•	NOT_READY
	•	READY_WITH_FIXES
	•	READY

⸻

Hard rule

Stack není live-ready, pokud:
	•	backbone není stabilní
	•	claims gate nebo release gate chybí
	•	operátor musí improvizovat mezi kroky
