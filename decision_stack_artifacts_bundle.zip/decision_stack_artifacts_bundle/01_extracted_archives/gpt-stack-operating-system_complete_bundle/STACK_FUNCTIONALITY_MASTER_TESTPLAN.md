# STACK_FUNCTIONALITY_MASTER_TESTPLAN.md

## Purpose
Master testplan pro funkční ověření celého stacku.

## Exact order
1. `TEST_01_router_same_input_10x.md`
2. `TEST_02_router_reentry_same_input_10x.md`
3. `TEST_03_flow_determinism_3_hops.md`
4. `TEST_04_revenue_slice_integrity.md`
5. `TEST_05_prompt_ops_slice_integrity.md`
6. `TEST_06_product_slice_integrity.md`
7. `TEST_OP_01_JUNIOR_RUN.md`
8. `TEST_OP_02_SENIOR_RUN.md`
9. `LIVE_01_REVENUE_LIVE_BATCH.md`
10. `LIVE_02_PROMPT_LIVE_EXPORT.md`
11. `LIVE_03_PRODUCT_LIVE_PLANNING.md`

## Global PASS
- backbone PASS
- slice integrity PASS
- operator tests PASS
- at least one live lane is usable

## Global FAIL
- backbone not stable
- operator must improvise
- artifact trail is not audit-safe
- release gate is unusable

## Evidence required
- raw inputs
- raw outputs
- verdicts
- drift types
- blockers
- final test summary
