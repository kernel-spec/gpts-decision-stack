# REVENUE_EXECUTION_CORE_OVERVIEW.md

## Purpose
Tento soubor je orientační overview revenue execution lane.

Používej ho jako:
- rychlý přehled revenue rolí
- mapu revenue flow
- orientaci mezi runbooky a specialisty
- referenci pro první monetizační provoz

---

## Revenue lane goal
Revenue lane má dojít od:
- neurčité nabídky
- neověřeného wedge
- nejasného ICP
- nejasného outbound motion

k:
- jasnému ICP
- shortlist logic
- positioning discipline
- safe asset pack
- launch safety
- post-batch verdict

---

## Core revenue roles

### `MARKET_SCOUT_OUTBOUND`
Používej pro:
- market validation
- first ICP
- wedge validation
- segment priority
- demand reality

### `STRUCTURAL_ENGINE`
Používej pro:
- ICP card
- offer structure
- buyer / pain / trigger / exclusions
- narrow testable framing

### `LIST_BUILDER`
Používej pro:
- source map
- shortlist
- filters
- exclusions
- tiering
- tracker logic

### `POSITIONING_POLICE`
Používej pro:
- positioning lock
- CTA consistency
- vocabulary discipline
- drift audit

### `ASSET_ENGINE`
Používej pro:
- opener
- follow-up
- DM
- first claims-safe asset pack

### `REWRITE_ENGINE`
Používej pro:
- rewrite existing asset
- tighten wording
- improve clarity / conversion

### `SUGGESTION_ENGINE`
Používej pro:
- diagnose asset without rewrite
- identify weak spots

### `DELIVERABILITY_GUARD`
Používej pro:
- DNS baseline
- sending safety
- ramp logic
- launch risk

### `PERFORMANCE_MEMORY`
Používej pro:
- post-batch verdict
- `SCALE / OPTIMIZE / KILL`
- next action after data

---

## Support revenue roles

### `PRICING_PACKAGER`
Pricing, tiering, scope locks, anchors.

### `OBJECTION_HANDLER`
Objection map a objection response pack.

### `CALL_CLOSER`
Call structure, close language, next-step close.

### `DELIVERY_SOP_ENGINE`
Delivery procedure po close.

### `RETENTION_ENGINE`
Retention / continuation / expansion logic.

### `EXPERIMENT_DESIGNER`
Structured testing and variant design.

### `OPS_AUTOMATOR`
Repeatable ops logic.

---

## Canonical revenue flow
`SYSTEM_OS_MASTER -> MARKET_SCOUT_OUTBOUND -> STACK_DEV_LAYER -> SYSTEM_OS_MASTER -> STRUCTURAL_ENGINE -> STACK_DEV_LAYER -> SYSTEM_OS_MASTER -> LIST_BUILDER -> STACK_DEV_LAYER -> SYSTEM_OS_MASTER -> POSITIONING_POLICE -> CLAIMS_EVIDENCE_REVIEWER -> STACK_DEV_LAYER -> SYSTEM_OS_MASTER -> ASSET_ENGINE -> CLAIMS_EVIDENCE_REVIEWER -> STACK_DEV_LAYER -> SYSTEM_OS_MASTER -> DELIVERABILITY_GUARD -> RELEASE_GATE_REVIEWER -> STACK_DEV_LAYER -> SYSTEM_OS_MASTER -> PERFORMANCE_MEMORY`

---

## Revenue documentation map

### Core source-of-truth files
- `OFFER_SINGLE_SOURCE_OF_TRUTH.md`
- `PRICING_AND_PACKAGING_MASTER.md`
- `SALES_CALL_SYSTEM.md`
- `LIST_BUILDING_MASTER_SPEC.md`
- `OUTBOUND_ASSET_MASTER_PACK.md`
- `DELIVERABILITY_AND_LAUNCH_POLICY.md`
- `POST_BATCH_DECISION_RULES.md`

### Revenue runbooks
- `03_REVENUE_DISCOVERY_RUNBOOK.md`
- `04_ICP_TO_SHORTLIST_RUNBOOK.md`
- `05_POSITIONING_AND_CLAIMS_RUNBOOK.md`
- `06_ASSET_GENERATION_RUNBOOK.md`
- `07_LAUNCH_SAFETY_RUNBOOK.md`
- `08_POST_BATCH_DECISION_RUNBOOK.md`

---

## Revenue success condition
Revenue lane je připravená pro live provoz, když:
- offer framing existuje
- ICP je narrow a testable
- shortlist logic je jasná
- claims jsou safe
- asset pack je copy-ready
- sending je safe
- post-batch verdict je tvrdý a jasný
