# 02_STACK_DETERMINISM_RUNBOOK.md

## Purpose
Ověřit determinismus backbone:
- první routing
- router re-entry
- 3-hop flow

## Test order
1. `TEST_01_router_same_input_10x.md`
2. `TEST_02_router_reentry_same_input_10x.md`
3. `TEST_03_flow_determinism_3_hops.md`

## What PASS means
- stejný input -> stejný NEXT_GPT
- stejný input -> stejný handoff shape
- stejný bottleneck -> stejný další krok
- žádný unauthorized narrowing
- žádný format drift

## What FAIL means
- route drift
- schema drift
- wording drift, který rozbíjí handoff
- bottleneck drift
- flow order drift

## Repair protocol
1. označ dominant drift type
2. oprav jen failing layer
3. zopakuj failing test
4. bez PASS nepokračuj dál

## Required outputs
- raw test input
- raw outputs
- verdict
- dominant drift type
- next repair focus
