# LIVE_BATCH_STOP_RULES_CARD.md

## Purpose
Krátká stop karta před a během live batche.

Používej ji:
- těsně před odesláním
- během prvního batche
- při podezření na risk
- při review výsledků po odeslání

---

## Never send if

- [ ] neproběhl `CLAIMS_EVIDENCE_REVIEWER`
- [ ] neproběhl `RELEASE_GATE_REVIEWER`
- [ ] release verdict není explicitní
- [ ] asset wording není final
- [ ] není jasné, která verze assetu jde ven
- [ ] list subset není jasný
- [ ] operátor musí hádat, co se přesně posílá
- [ ] constraints nejsou zachované

---

## Stop immediately if

- [ ] hard bounce rate je vysoká
- [ ] objeví se spam complaints
- [ ] seed placement nebo deliverability je evidentně špatná
- [ ] replies ukazují silný relevance mismatch
- [ ] objeví se wording / compliance problém
- [ ] discoverneš unsupported claim v live copy
- [ ] asset je jiný než reviewovaná verze

---

## Stop and repair if

- [ ] claims review byla přeskočená
- [ ] release gate byla přeskočená
- [ ] batch byl poslán bez jasného logu
- [ ] manifest není aktualizovaný
- [ ] nelze dohledat, co přesně šlo ven

---

## Continue only if

- [ ] claims verdict je `SAFE` nebo `SAFE_WITH_FIXES`
- [ ] release verdict je `READY` nebo vědomě řízené `READY_WITH_FIXES`
- [ ] asset version je jasná
- [ ] list subset je jasný
- [ ] log a manifest jsou aktualizované
- [ ] next post-batch review step je připravený

---

## Golden rule
Když si nejsi jistý, jestli poslat:
- neposílej
- vrať se na gate
- oprav blocker
