# DOC_UPDATE_PROTOCOL.md

## Purpose
Protokol pro bezpečnou aktualizaci dokumentace stacku.

Používej ho:
- při úpravě runbooků
- při rozšiřování knihovny
- při splitu master dokumentace
- při změně import registry
- při cleanupu nebo merge dokumentů

---

## Goal
Udržet dokumentaci:
- konzistentní
- nezdvojenou
- navigovatelnou
- auditovatelnou
- kompatibilní s reálným runtime

---

## Update order

### Step 1 — Determine document class
Rozhodni, jestli jde o:
- control plane doc
- runtime doc
- lane doc
- review/gate doc
- test doc
- reference/overview doc
- utility/checklist doc

### Step 2 — Determine primary authority
Urči:
- primary destination file
- secondary references
- jestli už soubor existuje
- jestli se má mergeovat nebo nově vytvořit

### Step 3 — Check for duplication
Zkontroluj:
- jestli stejná logika už není jinde
- jestli master dokument není přepisovaný jako detailní runbook
- jestli nová sekce nevytváří redundantní file

### Step 4 — Update primary file first
Nejdřív oprav primary authority soubor.
Teprve potom aktualizuj:
- index
- split plan
- overview files
- quick cards

### Step 5 — Update navigation layer
Po změně dokumentace s dopadem na library flow aktualizuj:
- `MASTER_LIBRARY_INDEX.md`
- případně `STACK_DOCUMENTATION_SPLIT_PLAN.md`
- případně `LIBRARY_GUIDE` knowledge source

### Step 6 — Update changelog
Zapiš změnu do:
- `STACK_CHANGELOG_TEMPLATE.md`

---

## Update rules

### Rule 1
Primary authority file má přednost před summary soubory.

### Rule 2
Quick cards nesmí být jediný zdroj pravdy.
Musí odkazovat na stabilní primary soubor.

### Rule 3
Master dokument je reference layer, ne detailní náhrada za všechny soubory.

### Rule 4
Když měníš pořadí nebo význam flow, aktualizuj i související karty a checklisty.

### Rule 5
Když měníš názvy souborů, aktualizuj všude exact file names.

---

## Mandatory sync targets

Zkontroluj, zda se po změně musí synchronizovat i:
- `MASTER_LIBRARY_INDEX.md`
- `STACK_DOCUMENTATION_MASTER.md`
- `STACK_DOCUMENTATION_SPLIT_PLAN.md`
- `FINAL_CORE_IMPORT_REGISTRY_CARD.md`
- `LIBRARY_GUIDE` knowledge
- relevant quick cards
- relevant runbooks

---

## Minimal doc update block

```text
DOC_UPDATE:
DATE_LABEL:
UPDATED_FILE:
DOC_CLASS:
PRIMARY_AUTHORITY:
SECONDARY_REFERENCES:
CHANGE_REASON:
DUPLICATION_CHECK:
NAVIGATION_UPDATE_NEEDED:
CHANGELOG_UPDATED:
STATUS:


⸻

Hard rule

Nejdřív uprav primary authority.
Teprve potom uprav summary, quick cards a index.
