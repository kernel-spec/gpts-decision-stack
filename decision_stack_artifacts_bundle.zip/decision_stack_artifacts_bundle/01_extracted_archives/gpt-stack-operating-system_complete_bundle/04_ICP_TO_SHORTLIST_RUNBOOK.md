# 04_ICP_TO_SHORTLIST_RUNBOOK.md

## Purpose
Převést ICP card do shortlist logic a public-data sourcing layer.

## Entry criteria
- valid `icp_card`
- geo and channel scope known

## Flow
1. `SYSTEM_OS_MASTER`
2. `LIST_BUILDER`
3. `STACK_DEV_LAYER`
4. `SYSTEM_OS_MASTER`

## Expected outputs
- source map
- filters
- exclusions
- tiering
- account-ready vs email-ready logic
- tracker logic

## Exit criteria
- shortlist logic is reproducible
- public-data sourcing is clear
- target volume is defined
- next bottleneck is known

## Stop conditions
- source logic violates constraints
- no clear exclusions
- no distinction between account-ready and email-ready
