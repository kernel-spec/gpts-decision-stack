# COMMON_FAILURE_MODES.md

## Purpose
Tento soubor shrnuje nejčastější failure modes napříč stackem.

Používej ho jako:
- cross-layer reference
- rychlý seznam toho, co se nejčastěji rozbije
- pomoc při debugování stacku

---

## Router failures
- více NEXT_GPT
- routing do špatné fáze
- předčasné narrowing
- scope drift
- routing do dev vrstvy nebo revieweru jako by to byl specialista

## Dev layer failures
- prose noise mimo output contract
- artifact_id mismatch
- completed_artifact mismatch
- fake file persistence claim
- placeholder drift
- bracket drift
- re-entry prompt není router-safe

## Operator failures
- raw output nejde do dev vrstvy
- direct specialist-to-specialist jump
- reviewer použit jako router
- chybí log
- chybí manifest update
- operátor upravuje raw output před vložením

## Review failures
- handoff reviewer authoruje místo review
- claims reviewer je příliš měkký
- release gate říká READY bez blockers checku
- claims gate je přeskočený před live copy

## Revenue failures
- ICP je příliš široké
- claims jsou silnější než proof
- asset pack vznikne dřív než positioning lock
- deliverability řešena až po spuštění
- po batchi není hard verdict

## Prompt ops failures
- QA přepisuje prompt místo review
- exporter vymýšlí nový obsah
- export bez release gate
- prompt draft není dostatečně versioned

## Product failures
- feature pack je příliš vágní
- architecture je příliš abstraktní
- engineering review není prioritizovaný
- execution plan není použitelný
- review a planning se směšují

## Registry failures
- chybí raw output
- chybí normalized artifact
- chybí verdict
- manifest nesedí na real session
- artifact trail není replay-safe

## Recovery rule
Při failure:
1. urč dominant drift type
2. oprav jen failing layer
3. zopakuj failing step nebo test
4. neškáluj přes neopravený failure
