# LIVE_SESSION_POSTMORTEM_TEMPLATE.md

## Purpose
Postmortem template pro jednu live session.

Používej ho:
- po live revenue batchi
- po live prompt exportu
- po live product planning runu
- po session, kde došlo k failure nebo překvapení

---

## Session header

SESSION_ID:
RUN_ID:
DATE_LABEL:
LANE:
OPERATOR:
LIVE_TYPE:
- revenue
- prompt_export
- product
- mixed

---

## Section 1 — What happened

### Planned objective
- 

### Actual outcome
- 

### Final session status
- pass
- pass_with_fixes
- fail
- closed

---

## Section 2 — Planned vs actual

### Planned path
- 

### Actual path
- 

### Where flow diverged
- 

---

## Section 3 — Key artifacts

### Expected artifacts
- 
- 
- 

### Actual artifacts
- 
- 
- 

### Missing artifacts
- 
- 
- 

---

## Section 4 — Gate outcomes

### Handoff gate
- used:
- verdict:
- notes:

### Claims gate
- used:
- verdict:
- notes:

### Release gate
- used:
- verdict:
- notes:

---

## Section 5 — What worked

### Working thing 1
- description:
- why_it_helped:

### Working thing 2
- description:
- why_it_helped:

### Working thing 3
- description:
- why_it_helped:

---

## Section 6 — What failed

### Failure 1
- layer:
- description:
- impact:
- dominant_drift_type:
- could_it_have_been_stopped_earlier:

### Failure 2
- layer:
- description:
- impact:
- dominant_drift_type:
- could_it_have_been_stopped_earlier:

### Failure 3
- layer:
- description:
- impact:
- dominant_drift_type:
- could_it_have_been_stopped_earlier:

---

## Section 7 — Root cause

### Primary root cause
- 

### Secondary root cause
- 

### Was this a control issue, execution issue, or asset issue?
- control
- execution
- asset
- mixed

---

## Section 8 — Recovery

### Immediate recovery action
- 

### Short-term fix
- 

### Long-term fix
- 

---

## Section 9 — Prevent repeat

### New rule or guardrail
- 

### New checklist item
- 

### New test or review needed
- 

---

## Section 10 — Final postmortem block

```text
LIVE_SESSION_POSTMORTEM:
SESSION_ID:
RUN_ID:
LANE:
FINAL_STATUS:
PRIMARY_ROOT_CAUSE:
DOMINANT_DRIFT_TYPE:
IMMEDIATE_RECOVERY_ACTION:
SHORT_TERM_FIX:
LONG_TERM_FIX:
PREVENT_REPEAT_RULE:
NEXT_OPERATOR_ACTION:


⸻

Hard rule

Postmortem není hotový, dokud:
	•	je pojmenovaná root cause
	•	je pojmenovaný dominant drift
	•	je jasná recovery action
	•	je jasné, co se změní příště
