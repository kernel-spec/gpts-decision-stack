# KNOWLEDGE_UPLOAD_CHECKLIST.md

## Purpose
Checklist pro nahrávání knowledge souborů do Custom GPT Builderu.

Používej ho:
- při prvním setupu GPT
- při update knowledge
- při splitu dokumentace
- při QA po uploadu

---

## Section 1 — Pre-upload check

- [ ] soubor je ve formátu `.md`
- [ ] soubor je čitelný a čistý
- [ ] název souboru je canonical
- [ ] názvy souborů uvnitř textu jsou přesné
- [ ] nejsou tam exportní metadata navíc
- [ ] soubor není duplicitní vůči jinému knowledge souboru
- [ ] soubor odpovídá roli GPT, do kterého se nahrává

---

## Section 2 — Naming discipline

- [ ] používáš exact file name
- [ ] nepoužíváš suffixy typu `_final`, `_v2`, `_new`, `_copy`
- [ ] knowledge file name odpovídá dokumentaci
- [ ] stejné jméno je použité i v instructions, pokud na něj GPT odkazuje

---

## Section 3 — Content discipline

- [ ] soubor má být source of truth, ne jen výtah
- [ ] quick card není nahraná jako primary authority, pokud existuje detailní primary file
- [ ] není tam rozpor s jiným knowledge souborem
- [ ] soubor neobsahuje neplatné nebo zastaralé file names
- [ ] soubor drží stejnou terminologii jako stack

---

## Section 4 — Upload discipline

- [ ] správný GPT je otevřený
- [ ] uploaduješ do správného GPT
- [ ] po uploadu je soubor viditelný v knowledge
- [ ] nahrál se celý, ne poškozený
- [ ] po uploadu neexistují duplicitní staré verze téhož souboru

---

## Section 5 — Post-upload QA

- [ ] GPT umí citovat exact file names z knowledge
- [ ] GPT nevymýšlí neexistující soubory
- [ ] GPT přizná, když soubor nebo sekce v knowledge není
- [ ] GPT používá knowledge místo improvizace
- [ ] aspoň 1 smoke test dotaz proběhl správně

---

## Section 6 — LIBRARY_GUIDE specific upload set

### Minimum viable
- [ ] `MASTER_LIBRARY_INDEX.md`

### Recommended production
- [ ] `MASTER_LIBRARY_INDEX.md`
- [ ] `STACK_DOCUMENTATION_MASTER.md`
- [ ] `STACK_DOCUMENTATION_SPLIT_PLAN.md`

---

## Knowledge upload block

```text
KNOWLEDGE_UPLOAD:
DATE_LABEL:
GPT_NAME:
FILES_UPLOADED:
PRIMARY_AUTHORITY_CHECK:
NAMING_CHECK:
DUPLICATION_CHECK:
POST_UPLOAD_QA:
FINAL_STATUS:
NOTES:
```

---

## Final statuses
- `NOT_READY`
- `READY_WITH_FIXES`
- `READY`

---

## Hard rule

Knowledge upload není hotový jen tím, že se soubor nahrál.
Hotový je až po smoke testu, že GPT čerpá správně z knowledge.
