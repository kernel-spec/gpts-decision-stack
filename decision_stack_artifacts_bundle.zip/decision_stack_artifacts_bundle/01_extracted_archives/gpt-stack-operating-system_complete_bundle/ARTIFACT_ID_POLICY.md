# ARTIFACT_ID_POLICY.md

## Purpose
Definovat politiku pro `artifact_id` ve stacku.

Používej ho:
- při návrhu dev layeru
- při QA artifact trailu
- při session loggingu
- při registry auditu

---

## Core rule
Každý významný artifact musí mít jedno stabilní `artifact_id`.

`artifact_id` je identita artefaktu.
Nesmí driftovat mezi:
- raw output packaging
- normalized artifact
- re-entry prompt
- session log
- manifest

---

## Required properties of artifact_id

### 1. Stable
Stejný artifact = stejné `artifact_id`.

### 2. Explicit
`artifact_id` nesmí být skrytý nebo implicitní.

### 3. Re-entry safe
`completed_artifact` v re-entry promptu musí být 1:1 stejné jako `artifact_id`.

### 4. Audit-safe
`artifact_id` musí jít dohledat v:
- normalized artifact
- session log
- manifest

---

## Recommended artifact_id shape

Používej tvar:

`artifact_YYYY-MM-DD_{artifact-type-or-purpose}_{slug}_{step}`

### Example
- `artifact_2026-03-11_market-snapshot_cz-primary-icp_01`
- `artifact_2026-03-11_icp-card_cz-owner-led-it-consultancies_02`
- `artifact_2026-03-11_outbound-asset-pack_uk-saas-founder_04`

---

## Artifact ID components

### Date
Používej datum nebo stabilní date label.

### Artifact purpose/type
Musí být jasné, co artifact je.

### Slug
Krátký identifikátor tématu / ICP / batch / flow.

### Step suffix
Používej, když je potřeba odlišit postupné artefakty ve flow.

---

## Do not do

- nepoužívej náhodné ID bez významu
- nepoužívej více téměř stejných ID pro stejný artifact
- nepřidávej suffixy typu `_final` nebo `_new`
- neměň artifact_id mezi dev outputem a re-entry

---

## Required consistency checks

- [ ] `artifact_id` exists
- [ ] `completed_artifact` = `artifact_id`
- [ ] session log contains `artifact_id`
- [ ] manifest contains `artifact_id`
- [ ] artifact file labels are consistent with artifact identity

---

## Special cases

### If artifact is partial
Použij stále jedno explicitní `artifact_id`, ale summary musí přiznat partial stav.

### If artifact is replaced
Nevytvářej nový `artifact_id` jen kvůli malým fixům, pokud nejde o nový skutečný artifact.

### If artifact is truly new
Použij nové `artifact_id`.

---

## Artifact ID QA block

```text
ARTIFACT_ID_QA:
DATE_LABEL:
SESSION_ID:
ARTIFACT_ID:
ARTIFACT_TYPE:
COMPLETED_ARTIFACT_MATCH:
LOG_MATCH:
MANIFEST_MATCH:
DRIFT_FOUND:
STATUS:

⸻

Hard rule

Když completed_artifact neodpovídá artifact_id, nepokračuj dál v re-entry flow.
