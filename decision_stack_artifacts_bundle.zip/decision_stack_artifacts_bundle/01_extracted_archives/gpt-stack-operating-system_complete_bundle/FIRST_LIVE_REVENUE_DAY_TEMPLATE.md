# FIRST_LIVE_REVENUE_DAY_TEMPLATE.md

## Purpose
Template pro první skutečný live revenue den.

Používej ho:
- při prvním live outbound dni
- při prvním kontrolovaném revenue batchi
- při prvním end-to-end revenue provozu stacku

---

## Day header

DATE_LABEL:
OPERATOR:
PRIMARY_OBJECTIVE:
SESSION_ID:
RUN_ID:
TARGET_MARKET:
PRIMARY_ICP:
CHANNEL:
TIME_HORIZON:

---

## Section 1 — Day objective

### One clear objective
- 

### Success criterion for today
- 

### Hard stop condition for today
- 

---

## Section 2 — Starting state

### Already ready
- offer:
- ICP:
- shortlist:
- positioning:
- assets:
- deliverability:
- gates:

### Still missing
- 
- 
- 

### Current bottleneck
- 

---

## Section 3 — Planned live path

1. `SYSTEM_OS_MASTER`
2. selected revenue specialist
3. `STACK_DEV_LAYER`
4. `SYSTEM_OS_MASTER`
5. next specialist or reviewer
6. `STACK_DEV_LAYER`
7. `SYSTEM_OS_MASTER`
8. final claims gate
9. final release gate
10. live batch
11. post-batch verdict

---

## Section 4 — Pre-send checks

- [ ] current asset version is final
- [ ] current list subset is final
- [ ] claims verdict is known
- [ ] release verdict is known
- [ ] session log is current
- [ ] manifest is current
- [ ] operator knows exact next action after send

---

## Section 5 — Live batch details

BATCH_ID:
ASSET_VERSION:
LIST_SUBSET:
SEND_WINDOW:
PLANNED_VOLUME:
RELEASE_VERDICT:
RELEASE_NOTES:

---

## Section 6 — During-day observations

### Observation 1
- time:
- what_happened:
- impact:

### Observation 2
- time:
- what_happened:
- impact:

### Observation 3
- time:
- what_happened:
- impact:

---

## Section 7 — Post-send snapshot

SENT:
DELIVERY_SIGNALS:
EARLY_REPLIES:
EARLY_OBJECTIONS:
ISSUES_FOUND:
IMMEDIATE_ACTION:

---

## Section 8 — End-of-day review

### What worked
- 
- 
- 

### What failed
- 
- 
- 

### What must be fixed tomorrow
- 
- 
- 

---

## Final day block

```text
FIRST_LIVE_REVENUE_DAY:
DATE_LABEL:
PRIMARY_OBJECTIVE:
SUCCESS_CRITERION:
CURRENT_BOTTLENECK:
BATCH_ID:
SENT:
EARLY_SIGNAL:
FINAL_DAY_STATUS:
TOMORROW_FIRST_ACTION:
NOTES:


⸻

Hard rule

První live revenue den není o scale.
Je o kontrolovaném průchodu flow a jasném post-batch signálu.
