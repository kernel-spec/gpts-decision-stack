# 08_POST_BATCH_DECISION_RUNBOOK.md

## Purpose
Po batchi udělat tvrdé rozhodnutí podle dat.

## Entry criteria
- batch was sent
- basic metrics exist

## Flow
1. `SYSTEM_OS_MASTER`
2. `PERFORMANCE_MEMORY`

## Inputs
- sent
- replies
- booked
- closed
- revenue
- channel
- offer_type
- timeframe
- objections

## Outputs
- `SCALE`
- `OPTIMIZE`
- `KILL`
- top lessons
- next action

## Exit criteria
- one hard verdict
- one next action
- top changes prioritized

## Stop conditions
- no real data
- vague verdict
- optimization without decision
