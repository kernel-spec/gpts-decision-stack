# ROUTER_REENTRY_QA_CARD.md

## Purpose
Krátká QA karta pro kontrolu, jestli je re-entry prompt bezpečný pro návrat do `SYSTEM_OS_MASTER`.

Používej ji:
- po `STACK_DEV_LAYER`
- před vložením do routeru
- při debugování driftu

---

## Re-entry must contain

- `Completed previous step: ...`
- `user_goal: ...`
- `target_market: ...`
- `time_horizon: ...`
- `Context:`
- `completed_artifact: ...`
- `key_output:`
- `bottleneck: ...`
- `constraints: ...`
- finální větu:
  `Return only the routing sentence and strict handoff pack.`

---

## QA checklist

### Identity
- [ ] `completed_artifact` existuje
- [ ] `completed_artifact` sedí 1:1 na `artifact_id`
- [ ] `Completed previous step` sedí na source role

### Scope
- [ ] `user_goal` není ztracený
- [ ] `target_market` není změněný bez důvodu
- [ ] `time_horizon` sedí
- [ ] bottleneck je úzký a operativní
- [ ] constraints jsou zachované

### Quality
- [ ] není tam `NEXT_GPT`
- [ ] není tam commentary navíc
- [ ] není tam strategie navíc
- [ ] není tam fake completion claim
- [ ] key_output je konkrétní, ne vágní

---

## Re-entry is BAD when
- chybí bottleneck
- chybí constraints
- artifact identity driftuje
- prompt obsahuje commentary místo handoffu
- mění scope oproti artifactu
- tlačí router do konkrétní role jinak než přes bottleneck

---

## Re-entry is GOOD when
- jde copy-paste přímo do routeru
- operátor nic nedopisuje
- router z něj umí vybrat další krok bez guesswork
- zachovává real state po předchozím hopu

---

## Hard rule
Když re-entry neprojde touto kartou:
- nevkládej ho do routeru
- vrať se do `STACK_DEV_LAYER`
- oprav packaging
