# GPT_IMPORT_QA_CHECKLIST.md

## Purpose
Checklist pro QA po importu GPT do Custom GPT Builderu.

Používej ho:
- po vytvoření nového GPT
- po změně system promptu
- po změně description / starters
- po nahrání knowledge souborů
- před označením GPT jako ready

---

## Section 1 — Identity check

- [ ] Name je přesný
- [ ] Description odpovídá skutečné roli
- [ ] role není zaměnitelná s jinou rolí
- [ ] Conversation starters odpovídají skutečnému use case

---

## Section 2 — Instructions check

- [ ] Instructions jsou vložené celé
- [ ] nedošlo ke zkrácení kritických pravidel
- [ ] output contract je zachovaný
- [ ] verdict vocabulary je zachovaná
- [ ] boundary rules jsou zachované
- [ ] role neplní jinou práci, než má

---

## Section 3 — Behavior check

- [ ] GPT dělá přesně svůj typ práce
- [ ] GPT neroutuje, pokud nemá routovat
- [ ] GPT nereviewuje, pokud nemá reviewovat
- [ ] GPT neauthoruje, pokud má být gate
- [ ] GPT nevymýšlí knowledge mimo prompt / knowledge files

---

## Section 4 — Knowledge check

- [ ] správné knowledge soubory jsou nahrané
- [ ] názvy knowledge souborů sedí
- [ ] GPT používá knowledge tam, kde má
- [ ] GPT nevymýšlí soubory mimo knowledge
- [ ] při chybějícím souboru to přizná

---

## Section 5 — Output format check

- [ ] output shape odpovídá promptu
- [ ] nejsou tam extra sekce
- [ ] nejsou tam chybějící sekce
- [ ] exact key names sedí
- [ ] fences / formát odpovídá designu
- [ ] není prose noise, pokud nemá být

---

## Section 6 — Role boundary check

- [ ] `SYSTEM_OS_MASTER` neroutuje mimo registry
- [ ] `STACK_DEV_LAYER` neroutuje
- [ ] reviewer dává verdict, ne routing
- [ ] operator helper neřeší business
- [ ] library guide naviguje, neauthoruje

---

## Section 7 — Smoke test check

Proveď aspoň 1 krátký test:
- [ ] valid starter input
- [ ] one edge-case input
- [ ] one boundary-case input

Výsledek:
- [ ] PASS
- [ ] PASS_WITH_FIXES
- [ ] FAIL

---

## GPT import QA block

```text
GPT_IMPORT_QA:
GPT_NAME:
DATE_LABEL:
IDENTITY_CHECK:
INSTRUCTIONS_CHECK:
BEHAVIOR_CHECK:
KNOWLEDGE_CHECK:
OUTPUT_FORMAT_CHECK:
BOUNDARY_CHECK:
SMOKE_TEST_RESULT:
FINAL_STATUS:
NOTES:


⸻

Final statuses
	•	NOT_READY
	•	READY_WITH_FIXES
	•	READY

⸻

Hard rule

GPT není ready jen proto, že byl úspěšně importovaný.
Ready je až po behavior a format QA.
