# 00_OPERATOR_START_HERE.md

## Purpose
První vstupní soubor pro operátora.
Používej ho, když začínáš od nuly nebo si nejsi jistý, co otevřít jako první.

## Open first
1. `01_CONTROL_PLANE_RUNBOOK.md`
2. `12_SESSION_LOGGING_AND_ARTIFACT_REGISTRY_RUNBOOK.md`
3. `02_STACK_DETERMINISM_RUNBOOK.md`
4. `LIVE_OPERATOR_RUNBOOK.md`

## Golden runtime rule
Po každém specialistovi:
`specialista -> STACK_DEV_LAYER -> SYSTEM_OS_MASTER`

## Never do
- specialista -> specialista
- raw output -> router
- reviewer -> router
- ruční routing mimo `SYSTEM_OS_MASTER`

## First real path
1. zamkni control plane
2. zapni session logging
3. otestuj backbone
4. spusť první revenue flow
5. teprve potom scaleuj

## If you are lost
- dokumenty -> `MASTER_LIBRARY_INDEX.md`
- další business krok -> `SYSTEM_OS_MASTER`
- raw output -> `STACK_DEV_LAYER`
- co teď udělat -> `OPERATOR_HELPER`
