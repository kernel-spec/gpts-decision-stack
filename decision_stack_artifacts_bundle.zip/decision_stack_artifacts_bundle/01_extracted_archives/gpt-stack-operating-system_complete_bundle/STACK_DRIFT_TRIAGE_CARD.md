# STACK_DRIFT_TRIAGE_CARD.md

## Purpose
Krátká triage karta pro rychlé určení driftu a další opravy.

Používej ji:
- při FAIL kroku
- při backbone test failure
- při nejasném handoffu
- při rozdílu expected vs actual
- při operátorském chaosu

---

## Step 1 — Name the drift

Použij jen jeden dominantní drift type:

- `route_drift`
- `schema_drift`
- `narrowing_drift`
- `wording_drift`
- `format_drift`
- `handoff_failure`
- `boundary_violation`
- `operator_confusion`
- `outcome_failure`

---

## Step 2 — Quick definitions

### `route_drift`
Špatný další GPT.

### `schema_drift`
Špatné nebo neúplné input keys.

### `narrowing_drift`
Scope byl zúžen dřív nebo jinak, než měl.

### `wording_drift`
Význam zůstal podobný, ale wording už mění použitelnost nebo claim discipline.

### `format_drift`
Output shape už neodpovídá contractu.

### `handoff_failure`
Artifact není předatelný bez guesswork.

### `boundary_violation`
Vrstva udělala práci, kterou dělat nesmí.

### `operator_confusion`
Flow může být teoreticky správně, ale operátor neví, co dál.

### `outcome_failure`
Flow proběhlo, ale nedošlo k cílovému výsledku.

---

## Step 3 — Map drift to layer

### Router layer
Typicky:
- route_drift
- narrowing_drift
- schema_drift

### Dev layer
Typicky:
- format_drift
- handoff_failure
- wording_drift

### Reviewer layer
Typicky:
- boundary_violation
- wrong verdict strength
- handoff_failure

### Operator layer
Typicky:
- operator_confusion
- boundary_violation
- skipped step

### Specialist layer
Typicky:
- outcome_failure
- wording_drift
- artifact quality failure

---

## Step 4 — Repair priority

### Priority 1
Oprav failing layer, ne celý stack.

### Priority 2
Neopakuj celý flow, pokud stačí opravit jeden hop.

### Priority 3
Neškáluj přes neopravený dominant drift.

---

## Triage block

```text
DRIFT_TRIAGE:
SESSION_ID:
RUN_ID:
STEP_ID:
DOMINANT_DRIFT_TYPE:
FAILING_LAYER:
WHAT_BROKE:
LAST_VALID_STEP:
MINIMUM_REPAIR:
RETEST_NEEDED:
NEXT_SAFE_STEP:


⸻

Golden triage rule

Nejdřív pojmenuj dominant drift.
Teprve potom opravuj.

Nikdy neopravuj vše najednou, pokud nevíš, která vrstva selhala.
