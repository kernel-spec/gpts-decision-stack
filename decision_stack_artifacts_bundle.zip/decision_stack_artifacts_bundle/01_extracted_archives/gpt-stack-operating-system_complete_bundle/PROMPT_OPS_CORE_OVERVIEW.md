# PROMPT_OPS_CORE_OVERVIEW.md

## Purpose
Tento soubor je orientační overview prompt ops lane.

Používej ho jako:
- rychlý přehled prompt ops rolí
- mapu create -> QA -> export flow
- referenci pro prompt production workflow

---

## Prompt ops goal
Prompt ops lane má dojít od:
- potřeby nového promptu
- need-to-refactor promptu
- nejasného prompt draftu

k:
- usable prompt draftu
- QA-reviewed promptu
- export-ready packu
- release verdictu

---

## Core roles

### `PROMPT_AUTHOR`
Používej pro:
- nový prompt
- první draft
- refactor promptu
- převod requirements do promptu

### `PROMPT_QA_CRITIC`
Používej pro:
- QA promptu
- finding weak spots
- failure modes
- pre-export review

### `PROMPT_PACK_EXPORTER`
Používej pro:
- export-ready bundle
- builder pack
- import-ready format

### `RELEASE_GATE_REVIEWER`
Používej pro:
- final READY / NOT_READY
- export safety
- release discipline

---

## Canonical prompt ops flow
`SYSTEM_OS_MASTER -> PROMPT_AUTHOR -> STACK_DEV_LAYER -> SYSTEM_OS_MASTER -> PROMPT_QA_CRITIC -> STACK_DEV_LAYER -> SYSTEM_OS_MASTER -> PROMPT_PACK_EXPORTER -> RELEASE_GATE_REVIEWER -> STACK_DEV_LAYER`

---

## Documentation source
Primary runbook:
- `09_PROMPT_OPS_RUNBOOK.md`

Related control files:
- `01_CONTROL_PLANE_RUNBOOK.md`
- `12_SESSION_LOGGING_AND_ARTIFACT_REGISTRY_RUNBOOK.md`
- `RELEASE_GATE_POLICY.md`

---

## Prompt ops success condition
Prompt ops lane je správně nastavená, když:
- author vytvoří usable draft
- QA vrací review, ne nový authoring
- exporter vrací skutečný export-ready pack
- release gate dává tvrdý verdict
- operátor nemusí improvizovat mezi kroky
