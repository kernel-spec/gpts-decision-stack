# IOS_TAP_BY_TAP_OPERATOR_CARD.md

## Purpose
Ultra-praktická karta pro iPhone operátora.
Říká:
- co otevřít
- kam klepnout
- co zkopírovat
- co vložit
- kam se vrátit

Používej ji během live runtime, když nechceš přemýšlet nad flow.

---

## Golden runtime path
`SYSTEM_OS_MASTER -> specialista -> STACK_DEV_LAYER -> SYSTEM_OS_MASTER`

---

## Screen 1 — Start
### Otevři
- `LIBRARY_GUIDE` nebo `OPERATOR_HELPER`

### Kdy
- když nevíš, kde začít
- když nevíš, co otevřít

### Akce
1. otevři chat
2. vlož krátký dotaz
3. zapiš si next file nebo next GPT

---

## Screen 2 — Router
### Otevři
- `SYSTEM_OS_MASTER`

### Kdy
- když chceš další business krok
- když máš re-entry prompt
- když potřebuješ vybrat další roli

### Akce
1. zkopíruj vstup
2. vlož ho do `SYSTEM_OS_MASTER`
3. počkej na routing sentence + handoff pack
4. zkopíruj jen handoff block nebo jeho input část
5. přepni do specialisty

---

## Screen 3 — Specialista
### Otevři
- vybraný specialista

### Kdy
- po routeru

### Akce
1. vlož handoff
2. nech specialistu vrátit raw output
3. nic neupravuj
4. zkopíruj raw output 1:1
5. přepni do `STACK_DEV_LAYER`

### Nikdy nedělej
- nepřepisuj raw output
- nechoď z jednoho specialisty do druhého
- neposílej raw output rovnou do routeru

---

## Screen 4 — Dev layer
### Otevři
- `STACK_DEV_LAYER`

### Kdy
- po každém specialistovi

### Akce
1. vlož:
   - `SESSION_ID`
   - `TIMESTAMP`
   - `USER_GOAL`
   - `TARGET_MARKET`
   - `TIME_HORIZON`
   - `SOURCE_STEP`
   - `RAW_SPECIALIST_OUTPUT`
2. počkej na:
   - `RESPONSE_CLASS`
   - `FILE_LABELS` nebo `FILES`
   - `REENTRY_PROMPT`
   - `NORMALIZED_ARTIFACT`
3. zkopíruj jen `REENTRY_PROMPT`
4. přepni zpět do `SYSTEM_OS_MASTER`

---

## Screen 5 — Router re-entry
### Otevři
- `SYSTEM_OS_MASTER`

### Kdy
- po `STACK_DEV_LAYER`

### Akce
1. vlož `REENTRY_PROMPT`
2. získej další route
3. rozhodni:
   - pokračuji do specialisty
   - nebo jdu do revieweru, pokud to router řekne

---

## Screen 6 — Reviewer
### Otevři
- `HANDOFF_REVIEWER`
- `CLAIMS_EVIDENCE_REVIEWER`
- `RELEASE_GATE_REVIEWER`

### Kdy
- jen když je to explicitní gate krok
- nebo když je to součást runbooku

### Akce
1. vlož artifact nebo relevantní input
2. získej verdict
3. pokud verdict blokuje postup, nepokračuj
4. pokud je verdict použitelný, loguj ho a pokračuj přes `STACK_DEV_LAYER` nebo router podle flow

---

## Screen 7 — Logger
### Otevři
- `SESSION_LOGGER`

### Kdy
- po každém hopu

### Akce
1. vlož stručně:
   - role
   - artifact_id
   - artifact_type
   - verdict
   - drift_type
   - next_bottleneck
2. zkopíruj log block
3. ulož do session logu

---

## Screen 8 — Manifest
### Otevři
- `MANIFEST_KEEPER`

### Kdy
- po významném kroku
- na konci session vždy

### Akce
1. vlož:
   - session_id
   - role
   - artifact_id
   - files
   - verdict
   - next_bottleneck
2. zkopíruj manifest entry
3. vlož do manifestu

---

## Mini flow bez vysvětlování

### Když nevíš, co otevřít
`LIBRARY_GUIDE`

### Když nevíš, co udělat
`OPERATOR_HELPER`

### Když chceš další business krok
`SYSTEM_OS_MASTER`

### Když máš raw output
`STACK_DEV_LAYER`

### Když chceš log
`SESSION_LOGGER`

### Když chceš manifest
`MANIFEST_KEEPER`

---

## Hard stop
Zastav, když:
- specialista má následovat specialistu bez dev vrstvy
- raw output jde přímo do routeru
- reviewer je použit jako router
- live step nemá gate verdict
