# RELEASE_GATE_POLICY.md

## Purpose
Definovat finální release rozhodnutí před live sendem, exportem nebo execution handoffem.

## Allowed verdicts
- `READY`
- `READY_WITH_FIXES`
- `NOT_READY`

## READY
Použij jen když:
- required artifacts exist
- no critical blockers remain
- operator can proceed without guesswork

## READY_WITH_FIXES
Použij když:
- core is usable
- some non-critical or medium fixes remain
- fix order is clear

## NOT_READY
Použij když:
- critical artifacts are missing
- blockers remain
- release would require improvisation

## Mandatory output
Každé release review musí vrátit:
- verdict
- blockers
- non-blockers
- minimum fix order
- release_now yes/no

## Hard rules
- do not say READY if critical artifacts are missing
- be conservative when uncertain
- blockers must be explicit
- release gate is a decision, not a suggestion
