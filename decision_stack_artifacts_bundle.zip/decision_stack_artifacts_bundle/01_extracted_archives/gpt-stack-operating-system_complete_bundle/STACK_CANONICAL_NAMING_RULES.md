# STACK_CANONICAL_NAMING_RULES.md

## Purpose
Definovat canonical naming rules pro celý stack:
- GPT names
- file names
- artifact names
- manifest labels
- status labels

Používej ho:
- při zakládání nových souborů
- při update dokumentace
- při importu GPTs
- při naming QA

---

## Core naming principle
Používej stabilní, krátké, přesné názvy.
Nepoužívej:
- `_final`
- `_final_final`
- `_v2`
- `_new`
- `_copy`
- lokální aliasy pro stejné entity

---

## File naming rules

### Rule 1
Dokumentační a runbook soubory používej jako:
- `UPPERCASE_OR_NUMBERED_NAME.md`
- nebo `NUMBERED_NAME.md`

### Rule 2
Primary authority file má mít stabilní canonical name.

### Rule 3
Quick cards, checklists a templates mají být v názvu rozlišitelné:
- `..._CARD.md`
- `..._CHECKLIST.md`
- `..._TEMPLATE.md`
- `..._POLICY.md`
- `..._RUNBOOK.md`
- `..._OVERVIEW.md`

---

## GPT naming rules

### Rule 1
GPT name musí přesně odlišit typ role.

### Rule 2
Používej stabilní role names.
Nepřejmenovávej role bez důvodu.

### Rule 3
Boundary v názvu má být čitelná:
- router
- dev layer
- reviewer
- helper
- navigator
- specialist
- auditor

---

## Recommended role naming shapes

### Control plane
- `SYSTEM_OS_MASTER`
- `STACK_DEV_LAYER`

### Operator support
- `OPERATOR_HELPER`
- `SESSION_LOGGER`
- `MANIFEST_KEEPER`

### Review gates
- `HANDOFF_REVIEWER`
- `CLAIMS_EVIDENCE_REVIEWER`
- `RELEASE_GATE_REVIEWER`

### Audit / control-plus
- `LIBRARY_GUIDE`
- `BACKBONE_TESTER`
- `REGISTRY_AUDITOR`
- `SCOPE_GUARD`

### Specialists
Používej stabilní exact names z import registry.

---

## Artifact naming rules

### Rule 1
`artifact_id` má být stabilní a bez kosmetických suffixů.

### Rule 2
Stejný artifact nesmí mít více „téměř stejných“ jmen.

### Rule 3
`completed_artifact` musí být přesně stejné jako `artifact_id`.

---

## File label naming patterns

### Artifact file
`artifact__{timestamp_label}__{artifact_type}__{slug}.md`

### Artifact JSON
`artifact__{timestamp_label}__{artifact_type}__{slug}.json`

### Re-entry file
`reentry__{timestamp_label}__{source_role}__to_system_os_master__{step}.txt`

### Manifest file
`manifest__{session_id}__{step}.md`

---

## Session naming rules

### SESSION_ID
`session_YYYYMMDD_01`

### RUN_ID
`run_{lane}_{index}`

### STEP_ID
`step_01`, `step_02`, `step_03`

---

## Status naming rules

### Generic statuses
- `not_started`
- `partial`
- `pass`
- `pass_with_fixes`
- `fail`
- `closed`
- `live_ready`
- `needs_repair`

### Review verdicts
Používej jen oficiální vocabulary příslušné role.

---

## Anti-drift naming rules

### Never do
- stejné věci nazývat různě napříč soubory
- přidávat suffixy jen proto, že existuje starší verze
- měnit canonical name bez update indexu, split plánu a knowledge mapy

### Always do
- aktualizovat exact file names všude
- držet 1 primary name per entity
- držet naming map kompatibilní s manifestem a artifact trail

---

## Naming QA block

```text
CANONICAL_NAMING_QA:
DATE_LABEL:
ENTITY_TYPE:
ENTITY_NAME:
CANONICAL_NAME:
ALIASES_FOUND:
DRIFT_RISK:
FIX_NEEDED:
STATUS:
