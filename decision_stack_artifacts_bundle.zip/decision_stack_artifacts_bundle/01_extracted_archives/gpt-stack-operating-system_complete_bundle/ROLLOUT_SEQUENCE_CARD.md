# ROLLOUT_SEQUENCE_CARD.md

## Purpose
Krátká rollout karta pro bezpečné zavádění celého stacku do provozu.

Používej ji:
- při prvním rollout setupu
- při přechodu z designu do live provozu
- při postupném rozšiřování stacku

---

## Phase 1 — Control layer rollout

Rollout:
1. `SYSTEM_OS_MASTER`
2. `STACK_DEV_LAYER`
3. `OPERATOR_HELPER`
4. `SESSION_LOGGER`
5. `MANIFEST_KEEPER`

Goal:
- control skeleton exists
- canonical hop exists
- basic logging exists

Do not add yet:
- široké specialist lanes
- control-plus layer
- extra docs beyond minimum core

---

## Phase 2 — Gate rollout

Rollout:
6. `HANDOFF_REVIEWER`
7. `CLAIMS_EVIDENCE_REVIEWER`
8. `RELEASE_GATE_REVIEWER`

Goal:
- handoff safety exists
- claims safety exists
- release safety exists

---

## Phase 3 — Revenue core rollout

Rollout:
9. `MARKET_SCOUT_OUTBOUND`
10. `STRUCTURAL_ENGINE`
11. `LIST_BUILDER`
12. `POSITIONING_POLICE`
13. `ASSET_ENGINE`
14. `DELIVERABILITY_GUARD`
15. `PERFORMANCE_MEMORY`

Goal:
- first live revenue path is possible

---

## Phase 4 — Revenue support rollout

Rollout:
16. `PRICING_PACKAGER`
17. `OBJECTION_HANDLER`
18. `CALL_CLOSER`
19. `REWRITE_ENGINE`
20. `SUGGESTION_ENGINE`

Goal:
- revenue lane becomes commercially usable

---

## Phase 5 — Prompt ops rollout

Rollout:
21. `PROMPT_AUTHOR`
22. `PROMPT_QA_CRITIC`
23. `PROMPT_PACK_EXPORTER`

Goal:
- prompt ops lane becomes usable

---

## Phase 6 — Product rollout

Rollout:
24. `SAAS_FEATURE_PACK_ENGINE`
25. `Architecture Copilot`
26. `Staff Engineer OS`
27. `Founder OS`
28. `ENTERPRISE_LAYER`

Goal:
- product/build lane becomes usable

---

## Phase 7 — Control-plus rollout

Rollout:
29. `LIBRARY_GUIDE`
30. `BACKBONE_TESTER`
31. `REGISTRY_AUDITOR`
32. `SCOPE_GUARD`

Goal:
- documentation navigation
- deterministic testing
- registry audit
- scope control

---

## Rollout checks after each phase

- [ ] import QA passed
- [ ] smoke tests passed
- [ ] boundaries hold
- [ ] no role confusion
- [ ] docs reflect real state
- [ ] next phase is justified

---

## Rollout block

```text
ROLLOUT_SEQUENCE_STATUS:
CURRENT_PHASE:
PHASE_1_CONTROL_LAYER:
PHASE_2_GATES:
PHASE_3_REVENUE_CORE:
PHASE_4_REVENUE_SUPPORT:
PHASE_5_PROMPT_OPS:
PHASE_6_PRODUCT:
PHASE_7_CONTROL_PLUS:
CURRENT_BLOCKERS:
NEXT_PHASE:
NOTES:
```

---

## Hard rule

Nezrychluj rollout tím, že přidáš víc GPTs, než umíš provozně udržet.
Nejdřív stabilita, potom šířka.
