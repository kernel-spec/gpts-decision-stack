# CUSTOM_GPT_BUILDER_SETUP_CARD.md

## Purpose
Krátká setup karta pro založení nebo update GPT v Custom GPT Builderu.

Používej ji:
- při vytváření nového GPT
- při update Instructions
- při uploadu Knowledge
- při final QA před použitím

---

## Section 1 — Core fields

### Fill these fields
- Name
- Description
- Instructions
- Conversation starters
- Knowledge files

### Check
- [ ] Name odpovídá skutečné roli
- [ ] Description nepřehání schopnosti GPT
- [ ] Instructions odpovídají typu role
- [ ] starters odpovídají reálnému use case
- [ ] knowledge odpovídá roli GPT

---

## Section 2 — Role type check

Rozhodni, co GPT je:

- [ ] router
- [ ] dev layer
- [ ] reviewer
- [ ] operator helper
- [ ] library navigator
- [ ] specialist
- [ ] audit / control-plus

### Rule
GPT musí dělat jen svůj typ práce.

---

## Section 3 — Instructions check

- [ ] output contract je explicitní
- [ ] hard rules jsou explicitní
- [ ] boundary rules jsou explicitní
- [ ] language policy je explicitní
- [ ] GPT ví, co nesmí dělat
- [ ] GPT nepřebírá práci jiné role

---

## Section 4 — Knowledge check

- [ ] knowledge files jsou správné
- [ ] názvy knowledge files jsou canonical
- [ ] instructions odkazují na knowledge správně
- [ ] GPT nemá zbytečné soubory mimo svůj scope
- [ ] GPT má jen tu knowledge, kterou potřebuje

---

## Section 5 — Smoke test

Udělej aspoň 3 testy:
1. basic use case
2. edge case
3. boundary case

### Check
- [ ] format drží
- [ ] role drží boundaries
- [ ] GPT nepřeskakuje do jiné role
- [ ] GPT neimprovizuje mimo knowledge / instructions

---

## Section 6 — Final builder QA

- [ ] Name final
- [ ] Description final
- [ ] Instructions final
- [ ] starters final
- [ ] knowledge final
- [ ] smoke test PASS
- [ ] GPT_IMPORT_QA_CHECKLIST proběhl

---

## Builder setup block

```text
CUSTOM_GPT_BUILDER_SETUP:
GPT_NAME:
ROLE_TYPE:
INSTRUCTIONS_STATUS:
KNOWLEDGE_STATUS:
STARTERS_STATUS:
SMOKE_TEST_STATUS:
IMPORT_QA_STATUS:
FINAL_STATUS:
NOTES:
```

---

## Final statuses
- `NOT_READY`
- `READY_WITH_FIXES`
- `READY`

---

## Hard rule

Neoznačuj GPT jako ready, dokud:
- nedrží boundaries
- nedrží output contract
- neprošel smoke testem
