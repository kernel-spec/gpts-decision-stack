# 01_CONTROL_PLANE_RUNBOOK.md

## Purpose
Ústava stacku. Zamyká router authority, hop model, role types, stop podmínky a canonical re-entry.

## Router authority
Pouze `SYSTEM_OS_MASTER` je routing autorita.

## Canonical hop
`SYSTEM_OS_MASTER -> specialista -> STACK_DEV_LAYER -> SYSTEM_OS_MASTER`

## Extended hop
`SYSTEM_OS_MASTER -> specialista -> STACK_DEV_LAYER -> reviewer -> SYSTEM_OS_MASTER`

## Role types
- router: `SYSTEM_OS_MASTER`
- dev layer: `STACK_DEV_LAYER`
- specialisté: revenue / prompt ops / product / delivery role
- review gates: `HANDOFF_REVIEWER`, `CLAIMS_EVIDENCE_REVIEWER`, `RELEASE_GATE_REVIEWER`
- operator support: `OPERATOR_HELPER`, `SESSION_LOGGER`, `MANIFEST_KEEPER`

## Hard rules
1. žádný specialista nesmí routovat
2. žádný reviewer nesmí routovat
3. žádný raw output nejde přímo do routeru
4. po každém specialistovi musí přijít `STACK_DEV_LAYER`
5. každý hop musí mít log
6. každý live krok musí mít release verdict
7. reviewer je gate, ne router

## Stop conditions
Zastav flow, když:
- router vrací více NEXT_GPT
- specialista vrátí nepředatelný artifact
- dev layer začne routovat
- reviewer authoruje místo review
- operátor musí hádat další krok

## Canonical re-entry
Používej jen `CANONICAL_REENTRY_TEMPLATE.md`.

## Final rule
Bez artifact trailu se krok nepočítá jako validní.
