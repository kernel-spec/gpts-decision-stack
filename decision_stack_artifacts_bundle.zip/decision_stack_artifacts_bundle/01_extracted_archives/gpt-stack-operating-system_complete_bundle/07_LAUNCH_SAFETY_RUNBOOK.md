# 07_LAUNCH_SAFETY_RUNBOOK.md

## Purpose
Rozhodnout, zda je batch safe to send.

## Entry criteria
- asset pack exists
- shortlist logic exists
- sending setup is known

## Flow
1. `SYSTEM_OS_MASTER`
2. `DELIVERABILITY_GUARD`
3. `RELEASE_GATE_REVIEWER`
4. `STACK_DEV_LAYER`
5. `SYSTEM_OS_MASTER`

## Expected outputs
- deliverability review
- release verdict
- blockers
- fix order

## Exit criteria
- DNS baseline understood
- ramp logic exists
- stop rules exist
- release verdict is explicit

## Stop conditions
- no release verdict
- no stop rules
- no sending baseline
- critical blockers unresolved
