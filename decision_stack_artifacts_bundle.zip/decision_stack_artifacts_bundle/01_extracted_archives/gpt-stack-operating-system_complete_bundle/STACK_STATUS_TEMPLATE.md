# STACK_STATUS_TEMPLATE.md

## Purpose
Reusable template pro rychlé zhodnocení stavu celého stacku.

Používej ho pro:
- weekly review
- readiness review
- pre-live summary
- test summary
- operator status snapshot

---

## Template

```text
STACK_STATUS:
CONTROL_LAYER:
ROUTER:
DEV_LAYER:
OPERATOR_RUNTIME:
REGISTRY:
REVIEW_GATES:
REVENUE_CORE:
PROMPT_OPS:
PRODUCT:
TEST_LAYER:
LIVE_PROOF:
NEXT_PRIORITY:


⸻

Suggested values

Používej krátké stavy jako:
	•	not_started
	•	partial
	•	locked
	•	pass
	•	pass_with_fixes
	•	fail
	•	live_ready
	•	needs_repair

⸻

Usage note

Tento template je rychlý status snapshot.
Nenahrazuje:
	•	session log
	•	manifest
	•	full test summary
	•	release verdict
