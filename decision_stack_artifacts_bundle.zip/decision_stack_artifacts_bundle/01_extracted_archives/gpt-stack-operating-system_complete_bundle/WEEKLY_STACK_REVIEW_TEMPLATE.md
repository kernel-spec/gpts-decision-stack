# WEEKLY_STACK_REVIEW_TEMPLATE.md

## Purpose
Týdenní review template pro stav celého stacku.

Používej ho:
- na konci týdne
- po sérii live sessions
- po testovacím týdnu
- při rozhodování, co opravit jako další priority

---

## Weekly header

WEEK_RANGE:
DATE_LABEL:
OPERATOR:
PRIMARY_LANE:
REVIEW_TYPE:
- weekly
- post-live
- post-test
- mixed

---

## Section 1 — This week in one sentence

WEEK_SUMMARY:

---

## Section 2 — What ran this week

### Sessions
- total_sessions:
- revenue_sessions:
- prompt_ops_sessions:
- product_sessions:
- test_sessions:

### Live runs
- live_revenue_runs:
- live_prompt_exports:
- live_product_planning_runs:

---

## Section 3 — Control layer status

### Router
- status:
- notes:

### Dev layer
- status:
- notes:

### Operator runtime
- status:
- notes:

### Logging
- status:
- notes:

### Manifest
- status:
- notes:

### Review gates
- status:
- notes:

---

## Section 4 — Lane status

### Revenue
- status:
- notes:

### Prompt ops
- status:
- notes:

### Product
- status:
- notes:

### Delivery / retention
- status:
- notes:

---

## Section 5 — Tests and drift

### Backbone tests
- status:
- notes:

### Slice integrity
- status:
- notes:

### Operator tests
- status:
- notes:

### Dominant drift types this week
- 
- 
- 

---

## Section 6 — Top failures

### Failure 1
- layer:
- description:
- impact:
- dominant_drift_type:
- repair_needed:

### Failure 2
- layer:
- description:
- impact:
- dominant_drift_type:
- repair_needed:

### Failure 3
- layer:
- description:
- impact:
- dominant_drift_type:
- repair_needed:

---

## Section 7 — What worked

### Win 1
- layer:
- description:
- why_it_worked:

### Win 2
- layer:
- description:
- why_it_worked:

### Win 3
- layer:
- description:
- why_it_worked:

---

## Section 8 — Artifact and registry health

- raw_output_coverage:
- normalized_artifact_coverage:
- reentry_coverage:
- logging_completeness:
- manifest_completeness:
- registry_health:

---

## Section 9 — Live readiness

- claims_gate_status:
- release_gate_status:
- revenue_live_status:
- prompt_export_status:
- product_live_status:
- overall_live_readiness:

---

## Section 10 — Next week priorities

### Priority 1
- layer:
- action:
- owner:
- expected_result:

### Priority 2
- layer:
- action:
- owner:
- expected_result:

### Priority 3
- layer:
- action:
- owner:
- expected_result:

---

## Final weekly verdict

WEEKLY_STACK_STATUS:
CONTROL_LAYER:
ROUTER:
DEV_LAYER:
OPERATOR_RUNTIME:
REGISTRY:
REVIEW_GATES:
REVENUE_CORE:
PROMPT_OPS:
PRODUCT:
TEST_LAYER:
LIVE_PROOF:
NEXT_PRIORITY:

---

## Hard rule
Týdenní review není hotové, dokud:
- je pojmenovaný dominantní drift
- jsou jasné příští priority
- je jasné, co se neopravuje tento týden
