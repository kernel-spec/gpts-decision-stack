# 09_PROMPT_OPS_RUNBOOK.md

## Purpose
Řídit prompt ops lane od draftu po export.

## Flow
1. `SYSTEM_OS_MASTER`
2. `PROMPT_AUTHOR`
3. `STACK_DEV_LAYER`
4. `SYSTEM_OS_MASTER`
5. `PROMPT_QA_CRITIC`
6. `STACK_DEV_LAYER`
7. `SYSTEM_OS_MASTER`
8. `PROMPT_PACK_EXPORTER`
9. `RELEASE_GATE_REVIEWER`
10. `STACK_DEV_LAYER`

## Expected outputs
- prompt draft
- QA report
- export bundle
- release verdict

## Stop conditions
- QA authoruje místo review
- export bundle is unusable
- no release verdict
