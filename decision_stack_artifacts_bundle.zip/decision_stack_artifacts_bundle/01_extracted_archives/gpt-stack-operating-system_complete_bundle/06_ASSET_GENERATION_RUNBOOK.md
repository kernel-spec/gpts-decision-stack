# 06_ASSET_GENERATION_RUNBOOK.md

## Purpose
Vytvořit claims-safe outbound asset pack.

## Entry criteria
- positioning locked
- CTA locked
- claims policy clear
- ICP and offer defined

## Flow
1. `SYSTEM_OS_MASTER`
2. `ASSET_ENGINE`
3. `CLAIMS_EVIDENCE_REVIEWER`
4. `STACK_DEV_LAYER`
5. `SYSTEM_OS_MASTER`

## Required assets
- opener
- follow-up
- DM

## Exit criteria
- assets are copy-ready
- one CTA only
- no fake familiarity
- no invented proof
- wording stays in scope

## Stop conditions
- guarantee language
- fake personalization
- multiple competing CTA
- evidence risk unresolved
