# SESSION_ID_AND_RUN_ID_POLICY.md

## Purpose
Definovat politiku pro `SESSION_ID` a `RUN_ID` napříč stackem.

Používej ho:
- při startu session
- při logování kroků
- při manifest managementu
- při auditování session trailu

---

## Core distinction

### SESSION_ID
Identita jedné session.

### RUN_ID
Identita konkrétního běhu nebo sub-běhu uvnitř session.

---

## SESSION_ID policy

### Default shape
`session_YYYYMMDD_01`

### Example
- `session_20260311_01`
- `session_20260311_02`

### Rules
- `SESSION_ID` musí být stabilní po celou session
- neměň `SESSION_ID` uprostřed flow
- každá samostatná session má mít vlastní `SESSION_ID`

---

## RUN_ID policy

### Default shape
`run_{lane}_{index}`

### Examples
- `run_revenue_01`
- `run_prompt_ops_01`
- `run_product_01`
- `run_test_01`

### Rules
- `RUN_ID` určuje konkrétní běh uvnitř session
- může být více runů pod jedním `SESSION_ID`
- lane v `RUN_ID` musí sedět na skutečný typ běhu

---

## When to create new SESSION_ID

Vytvoř nový `SESSION_ID`, když:
- začínáš novou samostatnou session
- předchozí session je uzavřená
- nový cíl už není pokračováním předchozí session
- chceš čistě oddělit audit trail

---

## When to reuse SESSION_ID

Použij stejné `SESSION_ID`, když:
- jde o pokračování téže session
- jde o tentýž cíl
- jde o tentýž live run nebo jeho bezprostřední pokračování
- navazuješ na předchozí artifact trail

---

## When to create new RUN_ID

Vytvoř nový `RUN_ID`, když:
- měníš lane
- začínáš nový typ běhu uvnitř session
- odděluješ test run od live run
- odděluješ revenue run od product run

---

## Minimum per step

Každý krok by měl nést:
- `SESSION_ID`
- `RUN_ID`
- `STEP_ID`
- `ROLE`
- `ARTIFACT_ID`

---

## Recommended companion labels

### STEP_ID
- `step_01`
- `step_02`
- `step_03`

### DATE_LABEL
- `2026-03-11`
- nebo `2026-03-11__manual-session`

---

## Common mistakes

- měnit `SESSION_ID` uprostřed flow
- nepoužívat `RUN_ID` pro lane distinction
- míchat více session do jednoho manifestu bez označení
- logovat kroky bez `SESSION_ID`

---

## Session policy QA block

```text
SESSION_RUN_POLICY_QA:
DATE_LABEL:
SESSION_ID:
RUN_ID:
LANE:
STEP_COUNT:
SESSION_STABILITY:
RUN_STABILITY:
MANIFEST_MATCH:
LOG_MATCH:
STATUS:

⸻

Hard rule

Bez SESSION_ID a RUN_ID není session audit-safe.
