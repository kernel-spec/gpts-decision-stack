# Builder Wiring README

## Import order

1. Open Custom GPT Builder.
2. Create or update the GPT named `GPTS_DECISION_STACK_IOS_OPERATOR_LAYER`.
3. Paste `custom_gpts/ios_operator_layer/builder/instructions.en.md` into Builder Instructions.
4. Paste `custom_gpts/ios_operator_layer/builder/conversation_starters.en.md` into Conversation Starters.
5. Paste `custom_gpts/ios_operator_layer/builder/knowledge_notes.en.md` into Knowledge / Notes if used.
6. Keep `custom_gpts/ios_operator_layer/operator/` and `custom_gpts/ios_operator_layer/scenarios/` as operator-side reference files.

## Expected iOS flow

Typical runtime flow:

- Operator asks status / next step / scenario command
- GPT identifies the correct scenario or Worker action
- GPT routes through the governed loop or Worker action
- Raw artifact is stored through STACK_DEV_LAYER when scenario mode is used
- GPT returns only a narrow routed summary or operator-facing packet

## Rule reminders

- Do not deploy multiple specialist GPTs
- Do not move business truth into prompts
- Do not bypass Worker as source of truth
- Do not bypass STACK_DEV_LAYER in governed scenario mode
