# Spec — iOS Operator Layer Deployment

## Purpose

This document defines the scope, architecture, and deployment rules for the single iOS/operator GPT shell.

## Deployment target

Deploy exactly one GPT:

`GPTS_DECISION_STACK_IOS_OPERATOR_LAYER`

## Scope

This GPT is:
- a thin iOS operator shell,
- above Worker-backed source of truth,
- above builder-safe actions,
- constrained by a narrow routing prompt,
- supported by scenario cards and operator SOPs.

This GPT is not:
- a replacement for Worker truth,
- a freeform strategy layer,
- a multi-GPT specialist marketplace,
- a parallel control plane.

## Source of truth

Canonical runtime truth remains in:
- `backend/worker/`
- `actions/openapi.yaml`
- `actions/openapi.openai.yaml`
- `knowledge/`
- `operations/`
- `qa/`

## GPT responsibilities

The operator layer may:
- classify intent,
- choose the correct scenario or action path,
- structure requests for Worker actions,
- return narrow operator-ready responses,
- apply PASS / BLOCKED / STOP operating discipline,
- enforce the golden flow where scenario mode is active.

The operator layer may not:
- become canonical business truth,
- invent state,
- bypass Worker as source of truth,
- bypass required review or release gate,
- act as multiple deployed specialist GPTs.

## Action surface

The intended model is:

user input
→ GPT identifies intent
→ GPT calls the appropriate Worker action
→ Worker returns canonical packet
→ GPT renders a narrow operator-facing response

Preferred action shape remains typed, not freeform natural-language routing.

## Deployment package

Primary packaging lives in:

`custom_gpts/ios_operator_layer/`

It includes:
- builder instructions
- conversation starters
- knowledge notes
- operator SOP
- quick macros
- fail macros
- scenario cards

## Runtime rule

Worker = source of truth  
Custom GPT = thin operator shell  
Specialists = internal orchestration roles, not separate GPT deployments
