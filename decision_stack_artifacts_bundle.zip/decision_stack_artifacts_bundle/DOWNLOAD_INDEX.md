# Decision Stack Artifacts Bundle

## What is included

This bundle consolidates the currently available materials into four layers:

1. **00_original_uploads/**  
   Flat copies of the uploaded source files.

2. **01_extracted_archives/**  
   Extracted contents of all uploaded ZIP archives:
   - GPT_KIT_Deploy_FULL.zip
   - gpt-stack-operating-system_complete_bundle.zip
   - gpts-decision-stack-DEV.zip
   - gpts-decision-stack-Deploy.zip
   - revenue-os-gpt-stack-main.zip

3. **02_repo_package/**  
   Generated repo-ready package for the single iOS/operator GPT shell:
   - custom_gpts/ios_operator_layer/
   - operations/specs/ios-operator-layer-deployment.md
   - README_wiring.md

4. **03_normalized_docs/**  
   Cleaned or normalized copies of key standalone source materials:
   - Universal_Prompt_Scaffold.md
   - STACK_FUNCTIONALITY_MASTER_TESTPLAN.md
   - GPT_KIT_TRIGGER_CHEAT_SHEET.cs.md
   - Board_Ready_Micro_Case_Studies.md

5. **04_indexes/**  
   Machine-readable and human-readable manifests.

## Quick-start files

### Repo package
- `02_repo_package/custom_gpts/ios_operator_layer/README.md`
- `02_repo_package/custom_gpts/ios_operator_layer/builder/instructions.en.md`
- `02_repo_package/custom_gpts/ios_operator_layer/builder/conversation_starters.en.md`
- `02_repo_package/custom_gpts/ios_operator_layer/builder/knowledge_notes.en.md`
- `02_repo_package/custom_gpts/ios_operator_layer/operator/sop.cs.md`
- `02_repo_package/operations/specs/ios-operator-layer-deployment.md`

### Standalone docs
- `03_normalized_docs/STACK_FUNCTIONALITY_MASTER_TESTPLAN.md`
- `03_normalized_docs/GPT_KIT_TRIGGER_CHEAT_SHEET.cs.md`
- `03_normalized_docs/Board_Ready_Micro_Case_Studies.md`
- `03_normalized_docs/Universal_Prompt_Scaffold.md`

## File counts by top-level folder

- `00_original_uploads`: 26 files
- `01_extracted_archives`: 354 files
- `02_repo_package`: 16 files
- `03_normalized_docs`: 4 files

## Assumptions

- “Vytvoř všechny artefakty/soubory k stažení” was interpreted as:
  1. preserve the original uploaded files,
  2. extract uploaded archives,
  3. generate a repo-ready operator package,
  4. add cleaned standalone document versions,
  5. package everything into one downloadable ZIP.

- Existing uploaded content was preserved as-is unless a normalized copy was explicitly created in `03_normalized_docs/`.

## Notes

- The generated repo package follows the PR-1 packaging direction discussed earlier.
- The normalized markdown files are convenience copies for easier reading, editing, and repo use.
