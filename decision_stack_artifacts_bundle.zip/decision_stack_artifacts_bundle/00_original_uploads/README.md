# GPTS Decision Stack – iOS Operator Layer

This directory contains the complete packaging for the **iOS operator layer** used in the `Revenue Simulation – New ICP Sales` motion.  The operator layer is delivered as a single Custom GPT that sits on top of the Worker runtime.  It exposes a thin conversational shell for iOS operators while delegating all state management, artefact storage and transition logic to the backend.  Specialists and reviewers are encoded as internal roles; they are not deployed as separate GPTs.

## Directory Structure

```
custom_gpts/ios_operator_layer/
│
├── builder/                  # Files intended for the Custom GPT Builder configuration
│   ├── instructions.en.md    # Canonical builder instructions
│   ├── conversation_starters.en.md  # Seed phrases to trigger each scenario
│   └── knowledge_notes.en.md # Internal notes (rules, mappings, defect types, naming conventions)
│
├── operator/                 # Reference materials for live operators
│   ├── sop.cs.md             # One‑page Standard Operating Procedure in Czech
│   ├── quick_macros.cs.md    # Short macros for running scenarios and daily operations (Czech)
│   └── fail_macros.cs.md     # Macros for handling failure cases (Czech)
│
├── scenarios/
│   └── revenue_simulation_new_icp_sales/
│       ├── 01_discovery.md          # Discovery scenario card
│       ├── 02_icp_shortlist.md      # ICP → Shortlist scenario card
│       ├── 03_positioning_claims.md # Positioning & Claims scenario card
│       ├── 04_asset_generation.md   # Asset Generation scenario card
│       ├── 05_launch_safety.md      # Launch Safety scenario card
│       └── 06_post_batch_decision.md# Post‑Batch Decision scenario card
│
└── README.md                # This file
```

## Purpose

The iOS operator layer is designed to ensure that every interaction with the revenue lane follows the same governed workflow.  Operators use scenario cards and macros to progress a single lane from discovery through post‑batch decision without improvisation.  The GPT never stores or invents state; instead, it consults the Worker via defined actions, enforces the golden flow (`SYSTEM_OS_MASTER → specialist → STACK_DEV_LAYER → SYSTEM_OS_MASTER`) and returns an auditable summary for each step.  For full context on the operating model, see `operations/specs/ios-operator-layer-deployment.md`.