# Revenue Simulation – New ICP Sales: v4 Single‑Run Master Sheets

The **v4 pack** provides ready‑to‑use **single‑run master sheets** for each scenario in the revenue lane motion “Governed GPT Workflow Audit.”  These sheets are designed for operators to run the lane without improvisation, following the golden flow `SYSTEM_OS_MASTER → specialist → STACK_DEV_LAYER → SYSTEM_OS_MASTER`【453901471500937†L55-L58】 and ensuring auditable artifacts at every step【937679800961216†L2244-L2255】.

For each scenario you will find:
- **INPUTS** – the parameters and constraints to provide to `SYSTEM_OS_MASTER`.
- **ROUTER MOVE** – validations and decisions performed by the router.
- **SPECIALIST MOVE** – the invocation details and required fields for the specialist.
- **DEV‑LAYER MOVE** – the expected save block and flags from `STACK_DEV_LAYER`.
- **REVIEW MOVE** – reviewer logic, if applicable.
- **FINAL DECISION MOVE** – pass/blocked/stop conditions and the required output format.

## Offer and ICP Context
- **Offer:** Governed GPT Workflow Audit
- **Target buyer:** Head of RevOps / Revenue Operations leader (B2B SaaS)
- **Primary CTA:** Book a 20‑minute diagnostic call
- **Core promise boundary:** Audit current GPT/ops workflow, identify governance gaps, map risk, recommend bounded refactor path.  No implementation or performance guarantee; no fake enterprise‑proof claims.

---

## v4.1 – Discovery Master Sheet

**RUN SHEET**

`DISCOVERY_MASTER_SHEET`

### INPUTS
```
scenario: DISCOVERY
offer_name: Governed GPT Workflow Audit
target_market: B2B SaaS
target_buyer: Head of RevOps / Revenue Operations leader
business_problem: GPT usage exists, but workflow truth, approvals, evidence, and production discipline are fragmented
commercial_goal: identify the shortest credible wedge for first outreach
primary_cta: Book a 20-min diagnostic call
available_context:
  - worker-backed governed system exists
  - founder console exists
  - evidence / closure / state discipline is core differentiator
  - no fake enterprise scale claims allowed
known_constraints:
  - no guarantee language
  - no invented market proof
  - no unsupported customer logos or references
  - must keep scope narrow to fastest cashflow wedge
  - do not broaden into full AI transformation offer
artifact_id_prefix: REV_DISCOVERY
run_id: RUN_NEW_ICP_2026_03_29_DISCOVERY_01
session_id: SESSION_NEW_ICP_SALES_01
```

### ROUTER MOVE
- Validate that buyer, market, offer and CTA are present.  
- Confirm scenario is `DISCOVERY`.  
- Select exactly one specialist: **MARKET_SCOUT_OUTBOUND**.  
- Define required artifact: `DISCOVERY__market_scan__MARKET_SCOUT_OUTBOUND__RUN_NEW_ICP_2026_03_29_DISCOVERY_01__v1`.  
- **Block** if target buyer or commercial wedge is undefined.

### SPECIALIST MOVE
Invoke specialist with the following contract:

**ROLE INVOCATION — MARKET_SCOUT_OUTBOUND**

```
SCENARIO
DISCOVERY

STAGE
market_scan

OBJECTIVE
Identify the shortest credible commercial wedge for Governed GPT Workflow Audit aimed at Head of RevOps / Revenue Operations leaders in B2B SaaS.

OUTPUT MUST INCLUDE
- MARKET HYPOTHESIS
- BUYING SIGNALS
- PAIN PATTERNS
- EXCLUSION SIGNALS
- CANDIDATE ANGLES
- RISKS
- RAW ARTIFACT
```

### DEV‑LAYER MOVE
Expected save block:
```
ARTIFACT SAVED
YES

ARTIFACT NAME
DISCOVERY__market_scan__MARKET_SCOUT_OUTBOUND__RUN_NEW_ICP_2026_03_29_DISCOVERY_01__v1

SOURCE ROLE
MARKET_SCOUT_OUTBOUND

SAVE STATUS
saved

ISSUES FLAGGED
- none or explicit discovery issues only

ROUTER RE-ENTRY READY
YES
```

### REVIEW MOVE
No reviewer is required unless the discovery artifact contains unsupported market claims, a broadened offer scope, or non‑auditable conclusions.  If such issues arise, return `BLOCKED` with appropriate `defect_type` (e.g., `wording_drift` or `route_drift`).

### FINAL DECISION MOVE
- **PASS** if: one usable buyer problem and commercial wedge are explicit; exclusions are explicit; route remains narrow and audit‑first.  
- **BLOCKED** if: buyer is too broad; wedge is unclear; exclusions missing.  
- **STOP** if: offer drifts into generic AI consulting; unsupported certainty or proof is invented.

**Output format:**
- STAGE  
- ENTRY CHECK  
- ROUTER DECISION  
- SELECTED SPECIALIST  
- RAW OUTPUT SAVED TO STACK_DEV_LAYER  
- ROUTED OUTPUT TO SYSTEM_OS_MASTER  
- EXIT CRITERIA CHECK  
- STOP CONDITIONS CHECK  
- NEXT BOTTLENECK  
- FINAL STATUS

---

## v4.2 – ICP → Shortlist Master Sheet

**RUN SHEET**

`ICP_SHORTLIST_MASTER_SHEET`

### INPUTS
```
scenario: ICP → SHORTLIST
locked_offer: Governed GPT Workflow Audit
locked_market: B2B SaaS
target_buyer_title_primary: Head of RevOps
target_buyer_title_secondary: Revenue Operations leader
target_company_profile:
  - B2B SaaS
  - 20–500 employees
  - GTM / ops complexity visible
  - likely multiple manual handoffs
  - signs of AI experimentation without operating discipline
inclusion_signals:
  - ops-heavy workflow ownership
  - revenue systems/process responsibility
  - signal / routing / process quality concerns
  - likely tooling sprawl
exclusion_signals:
  - solo founders without ops complexity
  - agencies
  - companies without GTM operations function
  - companies clearly outside B2B SaaS
desired_output_count: 25
known_constraints:
  - no fake personal familiarity
  - no speculative personalization beyond bounded evidence
  - no broad market list without explicit inclusion/exclusion logic
artifact_id_prefix: REV_SHORTLIST
run_id: RUN_NEW_ICP_2026_03_29_SHORTLIST_01
session_id: SESSION_NEW_ICP_SALES_01
```

### ROUTER MOVE
- Validate locked offer exists; inclusion and exclusion rules exist; desired count exists.  
- Select exactly one specialist: **LIST_BUILDER**.  
- Define required artifact: `ICP_SHORTLIST__candidate_list__LIST_BUILDER__RUN_NEW_ICP_2026_03_29_SHORTLIST_01__v1`.

### SPECIALIST MOVE
Invoke specialist with the contract:

**ROLE INVOCATION — LIST_BUILDER**

```
SCENARIO
ICP → SHORTLIST

STAGE
candidate_list_build

OBJECTIVE
Build a bounded shortlist of 25 candidate accounts matching the locked ICP.

OUTPUT MUST INCLUDE
- LIST OBJECTIVE
- INCLUSION RULES
- EXCLUSION RULES
- SHORTLIST
- REJECTED CANDIDATES
- DATA QUALITY FLAGS
- RAW ARTIFACT
```

### DEV‑LAYER MOVE
Expected save block:
```
ARTIFACT SAVED
YES

ARTIFACT NAME
ICP_SHORTLIST__candidate_list__LIST_BUILDER__RUN_NEW_ICP_2026_03_29_SHORTLIST_01__v1

SOURCE ROLE
LIST_BUILDER

SAVE STATUS
saved

ISSUES FLAGGED
- none or shortlist-quality issues only

ROUTER RE-ENTRY READY
YES
```

### REVIEW MOVE
No formal reviewer is required.  The router audits the shortlist: is it narrow enough?  Are the inclusion/exclusion rules explicit?  Was any narrowing done without authorisation?  If unauthorised narrowing occurs, return `STOP` with `defect_type: narrowing_drift`.

### FINAL DECISION MOVE
- **PASS** if: shortlist exists; inclusion and exclusion logic explicit; data quality flags visible; list is usable for outbound.  
- **BLOCKED** if: list exists but criteria are incomplete; exclusion logic missing; shortlist too noisy.  
- **STOP** if: list was silently narrowed; breaks scenario scope; or relies on speculative personalization.

**Output format:** (same as discovery)

---

## v4.3 – Positioning & Claims Master Sheet

**RUN SHEET**

`POSITIONING_AND_CLAIMS_MASTER_SHEET`

### INPUTS
```
scenario: POSITIONING & CLAIMS
locked_offer: Governed GPT Workflow Audit
locked_icp: Head of RevOps / Revenue Operations leader in B2B SaaS
core_problem:
  - GPT usage may exist, but state, approvals, evidence, and closure logic are not governed
desired_outcome:
  - sharper, claim-safe positioning angle for outbound and diagnostic proposal
allowed_proof_basis:
  - founder-built governed stack exists
  - worker-backed state/evidence/closure discipline exists
  - founder console + runtime truth pattern exists
disallowed_claims:
  - no guarantee of revenue lift
  - no guaranteed production outcome
  - no fake compliance guarantees
  - no fully autonomous operations claim
primary_cta: Book a 20-min diagnostic call
known_constraints:
  - no guarantee language
  - no inflated transformation claims
  - no fake urgency
  - must preserve narrow audit wedge
artifact_id_prefix: REV_POSITIONING
run_id: RUN_NEW_ICP_2026_03_29_POSITIONING_01
session_id: SESSION_NEW_ICP_SALES_01
```

### ROUTER MOVE
- Validate locked ICP and proof basis exist; disallowed claim set exists.  
- Select exactly one specialist: **POSITIONING_POLICE**.  
- Mark reviewer required: **CLAIMS_EVIDENCE_REVIEWER**.  
- Define required artifact: `POSITIONING_AND_CLAIMS__message_policy__POSITIONING_POLICE__RUN_NEW_ICP_2026_03_29_POSITIONING_01__v1`.

### SPECIALIST MOVE
Invoke specialist with the contract:

**ROLE INVOCATION — POSITIONING_POLICE**

```
SCENARIO
POSITIONING & CLAIMS

STAGE
message_policy_lock

OBJECTIVE
Create claim-safe positioning and wording policy for outbound and diagnostic proposal.

OUTPUT MUST INCLUDE
- CORE POSITIONING
- CLAIM BOUNDARY
- DISALLOWED WORDING
- RECOMMENDED WORDING
- CTA OPTIONS
- MESSAGE RISKS
- RAW ARTIFACT
```

### DEV‑LAYER MOVE
Expected save block:
```
ARTIFACT SAVED
YES

ARTIFACT NAME
POSITIONING_AND_CLAIMS__message_policy__POSITIONING_POLICE__RUN_NEW_ICP_2026_03_29_POSITIONING_01__v1

SOURCE ROLE
POSITIONING_POLICE

SAVE STATUS
saved

ISSUES FLAGGED
- none or claims / wording risks only

ROUTER RE-ENTRY READY
YES
```

### REVIEW MOVE
Invoke **CLAIMS_EVIDENCE_REVIEWER** on the saved positioning artifact.  Review must return: `REVIEW SCOPE`, `FINDINGS`, `BLOCKERS`, `REQUIRED FIXES`, `VERDICT` (allowed verdicts: READY, READY_WITH_FIXES, FAIL).

### FINAL DECISION MOVE
- **PASS** if: core positioning explicit; claim boundary explicit; banned wording explicit; CTA locked; reviewer verdict is READY or READY_WITH_FIXES.  
- **BLOCKED** if: wording requires fixes; claim boundary incomplete; CTA lock unstable.  
- **STOP** if: reviewer verdict = FAIL; unsupported claims remain; positioning breaks audit‑first boundary.

**Output format:** (same fields as discovery)

---

## v4.4 – Asset Generation Master Sheet

**RUN SHEET**

`ASSET_GENERATION_MASTER_SHEET`

### INPUTS
```
scenario: ASSET GENERATION
locked_offer: Governed GPT Workflow Audit
locked_icp: Head of RevOps / Revenue Operations leader in B2B SaaS
locked_positioning:
  - move from fragmented GPT usage to governed operating discipline
  - audit-first, not transformation-first
locked_claim_boundary:
  - audit / map / recommend
  - no performance guarantee
  - no implementation guarantee
locked_cta: Book a 20-min diagnostic call
asset_type: cold outbound email
desired_variants: 3
tone_of_voice:
  - credible
  - direct
  - non-hype
  - founder-led
required_structure:
  - hook
  - pain articulation
  - audit wedge
  - CTA
known_constraints:
  - single CTA only
  - no fake familiarity
  - no quick-question fluff
  - no overlong email
  - no unapproved claims
artifact_id_prefix: REV_ASSET
run_id: RUN_NEW_ICP_2026_03_29_ASSET_01
session_id: SESSION_NEW_ICP_SALES_01
```

### ROUTER MOVE
- Validate locked positioning, claim boundary and CTA exist.  
- Select exactly one specialist: **ASSET_ENGINE**.  
- Mark reviewer required: **CLAIMS_EVIDENCE_REVIEWER**.  
- Define required artifact: `ASSET_GENERATION__cold_email__ASSET_ENGINE__RUN_NEW_ICP_2026_03_29_ASSET_01__v1`.

### SPECIALIST MOVE
Invoke specialist with the contract:

**ROLE INVOCATION — ASSET_ENGINE**

```
SCENARIO
ASSET GENERATION

STAGE
cold_email_generation

OBJECTIVE
Generate 3 bounded cold outbound email variants from locked message policy.

OUTPUT MUST INCLUDE
- ASSET TYPE
- LOCKED INPUTS USED
- RAW DRAFT
- CLAIM RISK FLAGS
- FORMAT CHECK NOTES
- RAW ARTIFACT
```

### DEV‑LAYER MOVE
Expected save block:
```
ARTIFACT SAVED
YES

ARTIFACT NAME
ASSET_GENERATION__cold_email__ASSET_ENGINE__RUN_NEW_ICP_2026_03_29_ASSET_01__v1

SOURCE ROLE
ASSET_ENGINE

SAVE STATUS
saved

ISSUES FLAGGED
- none or format / claim / CTA issues only

ROUTER RE-ENTRY READY
YES
```

### REVIEW MOVE
Invoke **CLAIMS_EVIDENCE_REVIEWER** on the saved outbound asset artifact.  Review must return `REVIEW SCOPE`, `FINDINGS`, `BLOCKERS`, `REQUIRED FIXES`, `VERDICT`.

### FINAL DECISION MOVE
- **PASS** if: 3 usable variants exist; CTA lock preserved; claim boundary preserved; reviewer verdict is READY or READY_WITH_FIXES.  
- **BLOCKED** if: variants exist but need targeted fixes; CTA or formatting drift needs correction; only one variant usable.  
- **STOP** if: reviewer FAIL; claim inflation present; asset breaks locked positioning.

**Output format:** (same fields as discovery)

---

## v4.5 – Launch Safety Master Sheet

**RUN SHEET**

`LAUNCH_SAFETY_MASTER_SHEET`

### INPUTS
```
scenario: LAUNCH SAFETY
locked_asset:
  - outbound email selected from approved asset generation stage
locked_icp: Head of RevOps / Revenue Operations leader in B2B SaaS
batch_size: 25
sending_surface: founder-led manual / low-volume outbound
deliverability_assumption:
  - no mass cold infrastructure
  - cautious initial send
release_scope:
  - single batch
  - single asset type
  - single CTA
claims_policy:
  - already reviewed
approval_context:
  - no pricing proposal in initial outreach
  - only diagnostic-call CTA
known_constraints:
  - do not skip release gate
  - do not expand batch size during safety review
  - no extra offer claims
  - no personalization theater
artifact_id_prefix: REV_LAUNCH
run_id: RUN_NEW_ICP_2026_03_29_LAUNCH_01
session_id: SESSION_NEW_ICP_SALES_01
```

### ROUTER MOVE
- Validate approved asset, release scope and batch size exist.  
- Select exactly one specialist: **DELIVERABILITY_GUARD**.  
- Mark reviewer required: **RELEASE_GATE_REVIEWER**.  
- Define required artifact: `LAUNCH_SAFETY__batch_release_check__DELIVERABILITY_GUARD__RUN_NEW_ICP_2026_03_29_LAUNCH_01__v1`.

### SPECIALIST MOVE
Invoke specialist with the contract:

**ROLE INVOCATION — DELIVERABILITY_GUARD**

```
SCENARIO
LAUNCH SAFETY

STAGE
batch_release_check

OBJECTIVE
Evaluate whether approved outbound asset may be launched as a single controlled batch.

OUTPUT MUST INCLUDE
- SAFETY CHECK SCOPE
- DELIVERABILITY RISKS
- HARD BLOCKERS
- SOFT WARNINGS
- REQUIRED FIXES
- RAW ARTIFACT
```

### DEV‑LAYER MOVE
Expected save block:
```
ARTIFACT SAVED
YES

ARTIFACT NAME
LAUNCH_SAFETY__batch_release_check__DELIVERABILITY_GUARD__RUN_NEW_ICP_2026_03_29_LAUNCH_01__v1

SOURCE ROLE
DELIVERABILITY_GUARD

SAVE STATUS
saved

ISSUES FLAGGED
- none or release issues only

ROUTER RE-ENTRY READY
YES
```

### REVIEW MOVE
Invoke **RELEASE_GATE_REVIEWER** on the saved launch safety artifact.  Reviewer must return `REVIEW SCOPE`, `FINDINGS`, `BLOCKERS`, `REQUIRED FIXES`, `VERDICT` (allowed verdicts: READY, READY_WITH_FIXES, FAIL).

### FINAL DECISION MOVE
- **PASS** if: risks explicit; blockers explicit; reviewer verdict READY or READY_WITH_FIXES; operator knows whether launch may proceed now.  
- **BLOCKED** if: release review pending; hard blocker fix known but unresolved; asset version mismatch requires correction.  
- **STOP** if: reviewer FAIL; unresolved hard blocker; release gate missing or bypass attempted.

**Output format:** (same fields as discovery)

---

## v4.6 – Post‑Batch Decision Master Sheet

**RUN SHEET**

`POST_BATCH_DECISION_MASTER_SHEET`

### INPUTS
```
scenario: POST-BATCH DECISION
launched_batch_id: BATCH_NEW_ICP_01
batch_size: 25
asset_used:
  - approved outbound email variant
observed_signals:
  - reply_count: [TBD]
  - positive_reply_count: [TBD]
  - call_booked_count: [TBD]
  - bounce_count: [TBD]
  - objection_patterns: [TBD]
decision_goal:
  - determine whether to repeat, narrow, revise, or stop
learning_priority:
  - detect wording failures
  - detect ICP mismatch
  - detect CTA friction
  - detect asset safety issues
known_constraints:
  - no vanity interpretation
  - no invented performance signal
  - no rewrite without evidence
  - decision must come from observed batch signals
artifact_id_prefix: REV_POSTBATCH
run_id: RUN_NEW_ICP_2026_03_29_POSTBATCH_01
session_id: SESSION_NEW_ICP_SALES_01
```

### ROUTER MOVE
- Validate batch evidence exists and observed signals are sufficient for decision.  
- Select exactly one specialist: **PERFORMANCE_MEMORY**.  
- Define required artifact: `POST_BATCH_DECISION__performance_memory__PERFORMANCE_MEMORY__RUN_NEW_ICP_2026_03_29_POSTBATCH_01__v1`.

### SPECIALIST MOVE
Invoke specialist with the contract:

**ROLE INVOCATION — PERFORMANCE_MEMORY**

```
SCENARIO
POST-BATCH DECISION

STAGE
performance_memory_extraction

OBJECTIVE
Convert observed batch signals into a usable decision basis for repeat / revise / narrow / stop.

OUTPUT MUST INCLUDE
- PERFORMANCE SIGNALS
- REPEATED FAILURES
- WHAT WORKED
- WHAT SHOULD CHANGE
- MEMORY CANDIDATES
- RAW ARTIFACT
```

### DEV‑LAYER MOVE
Expected save block:
```
ARTIFACT SAVED
YES

ARTIFACT NAME
POST_BATCH_DECISION__performance_memory__PERFORMANCE_MEMORY__RUN_NEW_ICP_2026_03_29_POSTBATCH_01__v1

SOURCE ROLE
PERFORMANCE_MEMORY

SAVE STATUS
saved

ISSUES FLAGGED
- none or evidence-quality issues only

ROUTER RE-ENTRY READY
YES
```

### REVIEW MOVE
No reviewer is required by default.  The router verifies that the decision comes from evidence, that one decision path exists and that one next bottleneck exists.  If evidence is too weak, return `BLOCKED`.  If contradictory interpretation, return `STOP`.

### FINAL DECISION MOVE
- **PASS** if: performance signals explicit; repeated failures explicit; one next bottleneck explicit; one decision path chosen (repeat, revise, narrow, stop).  
- **BLOCKED** if: metrics incomplete; objections missing; evidence insufficient for decision.  
- **STOP** if: invented success narrative; contradictory next steps; no explicit bottleneck despite claimed decision.

**Output format:** (same fields as discovery)

---

## v4.7 – Master Operator Sequence

Use the following sequence for all sheets:

1. **Open** the relevant **MASTER SHEET**.  
2. **Paste the INPUTS** into `SYSTEM_OS_MASTER`.  
3. **Take the SPECIALIST MOVE block** and invoke the selected specialist.  
4. **Pass the returned raw artifact** into `STACK_DEV_LAYER`.  
5. **Wait until `STACK_DEV_LAYER` returns** `ROUTER RE-ENTRY READY: YES`.  
6. **Return to `SYSTEM_OS_MASTER`** and complete the **routed summary**, **review move** (if any) and **final decision move**.  
7. **Close the step** only with **PASS**, **BLOCKED** or **STOP**.

---

## v4.8 – Final Verdict

This v4 pack is a fully operational operator guide.  Each scenario has its own master sheet, making the flow easy to follow without keeping the entire lane logic in the operator’s head.  By following the sequence **INPUTS → ROUTER MOVE → SPECIALIST MOVE → DEV‑LAYER MOVE → REVIEW MOVE → FINAL DECISION MOVE**, the operator preserves auditability and avoids scope drift.

The next iteration (v5) will translate these master sheets into concise **copy‑paste run cards** optimized for Custom GPT / Builder use.

