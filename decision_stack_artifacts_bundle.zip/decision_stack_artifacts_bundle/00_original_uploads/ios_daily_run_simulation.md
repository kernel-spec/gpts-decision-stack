# iOS Daily Run Workflow Simulation – DevOps Operator Guide

## Role & Objective

This guide is for a **DevOps operator** running the GPT‑stack operating system from an iOS device.  The goal is to simulate a daily workflow that follows the control‑plane rules of the GPT‑stack OS while treating iOS as a **consumption and validation surface** only【476698118884759†L4995-L4997】.  The operator will manage sessions, specialists and reviewers, ensure logs and manifests are updated, and follow the prescribed golden flow patterns.

## Setup: First 10 Minutes

The first ten minutes at the beginning of the day or before a live session are critical.  Use them to get your control plane, documentation and session parameters in order【476698118884759†L7262-L7280】.

1. **Open core control chats**: Launch `SYSTEM_OS_MASTER`, `STACK_DEV_LAYER`, `OPERATOR_HELPER`, `SESSION_LOGGER` and `MANIFEST_KEEPER`【476698118884759†L7262-L7280】.
2. **Open navigation and runtime docs**: Open the live operator runbook, operator quick card, canonical re‑entry template, stack dev layer input template and session log template【476698118884759†L7283-L7292】.
3. **Check today's lane**: Decide whether today is a revenue day, testing day, prompt‑ops day or product day【476698118884759†L7295-L7301】.
4. **Open lane‑specific docs**:  If it’s a revenue day, open the revenue docs (`OFFER_SINGLE_SOURCE_OF_TRUTH.md`, `OUTBOUND_ASSET_MASTER_PACK.md`, `DELIVERABILITY_AND_LAUNCH_POLICY.md`, etc.)【476698118884759†L7305-L7313】; if it’s a testing day, open the test plan and order card【476698118884759†L7316-L7318】; if prompt‑ops or product day, open the respective runbook【476698118884759†L7320-L7327】.
5. **Confirm session start**: Record `SESSION_ID`, `RUN_ID`, lane, user goal, target market and time horizon【476698118884759†L7330-L7338】.
6. **Check control rules**: Confirm the router is `SYSTEM_OS_MASTER`, raw output goes to `STACK_DEV_LAYER`, the reviewer isn’t used as a router, every hop will be logged and the manifest will be updated【476698118884759†L7342-L7350】.
7. **Check gates**: Ensure the `HANDOFF_REVIEWER`, `CLAIMS_EVIDENCE_REVIEWER` and `RELEASE_GATE_REVIEWER` are ready【476698118884759†L7353-L7359】.
8. **Check the current bottleneck**: Write down the current bottleneck and the next intended lane step【476698118884759†L7362-L7367】.
9. **Check stop risks**: Verify there is no direct specialist‑to‑specialist jump, no raw output sent to the router, no live send without gates and no ambiguous session start【476698118884759†L7370-L7375】.
10. **Start**:  If you need another business step, open `SYSTEM_OS_MASTER`; if you’re unsure what to open, check `LIBRARY_GUIDE` or ask `OPERATOR_HELPER`【476698118884759†L7379-L7385】.

## Daily Runtime: Golden & Extended Flow

During the session, follow the golden and extended flows described in the live operator runbook.  The **golden flow** is `SYSTEM_OS_MASTER → specialista → STACK_DEV_LAYER → SYSTEM_OS_MASTER`; the **extended flow** inserts a reviewer before returning to the router【476698118884759†L2084-L2089】.

- **What goes where**: send business next steps to `SYSTEM_OS_MASTER`, send raw specialist output to `STACK_DEV_LAYER`, log each hop via `SESSION_LOGGER` and update the manifest via `MANIFEST_KEEPER`【476698118884759†L2097-L2102】.
- **Never do**: do not send specialist output directly to another specialist, do not send raw output to the router, do not use reviewers as routers and never launch without a release gate【476698118884759†L2103-L2107】.

## Module Initialization: First Five GPTs

At the very start of building or restarting the stack, import the core modules in the following order【476698118884759†L3968-L3995】:

1. **SYSTEM_OS_MASTER** – provides the control plane and canonical next steps【476698118884759†L3970-L3974】.
2. **STACK_DEV_LAYER** – ensures an artifact trail and clean re‑entry path【476698118884759†L3975-L3979】.
3. **OPERATOR_HELPER** – eliminates guesswork and speeds up practical use on an iPhone【476698118884759†L3981-L3984】.
4. **SESSION_LOGGER** – allows you to trace what happened and debug drift【476698118884759†L3986-L3989】.
5. **MANIFEST_KEEPER** – maintains session state and a clear artifact trail【476698118884759†L3991-L3995】.

After importing these five modules you have routing, dev packaging, operator guidance, hop logging and a manifest【476698118884759†L4000-L4006】.  Only after the first five should you add the `HANDOFF_REVIEWER`, `CLAIMS_EVIDENCE_REVIEWER` and `RELEASE_GATE_REVIEWER`【476698118884759†L4015-L4020】.  Perform a minimal test: run a simple router input, mock a raw specialist output into the dev layer, create a log entry and update the manifest to ensure the skeleton works【476698118884759†L4028-L4037】.

## Lane‑Specific Guidance: Revenue Day

If today’s lane is **revenue**, start with the revenue day opening card.  Open the control modules (`SYSTEM_OS_MASTER`, `STACK_DEV_LAYER`, `OPERATOR_HELPER`, `SESSION_LOGGER`, `MANIFEST_KEEPER`)【476698118884759†L9850-L9857】, the standard runtime docs (`LIVE_OPERATOR_RUNBOOK.md`, `OPERATOR_QUICK_CARD.md`, `CANONICAL_REENTRY_TEMPLATE.md`, `STACK_DEV_LAYER_INPUT_TEMPLATE.md`, `SESSION_LOG_TEMPLATE.md`)【476698118884759†L9859-L9864】 and the revenue documentation (single source of truth, pricing and packaging, sales call system, list‑building spec, outbound asset pack, deliverability policy and post‑batch decision rules)【476698118884759†L9866-L9873】.

Then document the primary revenue objective—discovery, ICP narrowing, shortlist logic, positioning/claims, asset generation, launch safety, live batch or post‑batch review【476698118884759†L9877-L9888】—and fill in the current bottleneck, asset state, list state, launch state and proof state【476698118884759†L9892-L9899】.  Use the `CLAIMS_EVIDENCE_REVIEWER` before live wording and the `RELEASE_GATE_REVIEWER` before live send【476698118884759†L9903-L9909】.

## End‑of‑Day Checklist

At the end of the day, run through the end‑of‑day operator card.  Confirm that all sessions have a final status and no session ends at an unclear step【476698118884759†L6847-L6852】.  Make sure today’s final bottleneck is recorded and tomorrow’s first step is clear【476698118884759†L6847-L6852】.

Check logs: each hop must be recorded, every failure should include a drift type and every `PASS_WITH_MINOR_FIXES` should have notes【476698118884759†L6856-L6861】.  Verify the manifest: it should be updated with the last artifact, final verdicts and the next bottleneck【476698118884759†L6865-L6870】.  Perform a live risk check: ensure nothing remains implicitly live, no unreleased asset is considered safe, no batch lacks a release verdict and claims‑safe status is clear【476698118884759†L6874-L6879】.  Finally, fill out the tomorrow setup note (first file, first GPT, bottleneck and session goal)【476698118884759†L6883-L6889】.

## iOS Surface & Control‑Plane Rules

The final target posture of the GPT‑stack OS is clear: treat the **repository** as the source of truth, use the **GPT Builder** as the deployment surface and treat **iOS** as a consumption and validation surface【476698118884759†L4995-L4997】.  This means you should not attempt to run the control plane directly from iOS; instead use it to view outputs, validate results and log sessions.  Always route through `SYSTEM_OS_MASTER` and return to it after each specialist hop, with the dev layer handling raw outputs and logs【476698118884759†L2084-L2090】.

## Quality & Best Practices

- **Maintain discipline**: follow the golden flow and never bypass gates or send raw outputs to the router【476698118884759†L2084-L2107】.
- **Log everything**: record every hop and update the manifest after each step【476698118884759†L2097-L2102】.
- **Check roles and gates**: ensure the reviewers (`HANDOFF_REVIEWER`, `CLAIMS_EVIDENCE_REVIEWER`, `RELEASE_GATE_REVIEWER`) are ready before starting work【476698118884759†L7353-L7359】.
- **Document bottlenecks and objectives**: write down current bottlenecks and intended next steps【476698118884759†L7362-L7367】; record revenue objectives and states when in the revenue lane【476698118884759†L9877-L9899】.
- **Close out properly**: end each day with a complete session state, log audit, manifest update and tomorrow setup note【476698118884759†L6847-L6890】.

By following this simulation guide, a DevOps operator using an iOS device can confidently run daily workflows on the GPT‑stack operating system while adhering to its strict control‑plane rules and ensuring a robust artifact trail and session log.