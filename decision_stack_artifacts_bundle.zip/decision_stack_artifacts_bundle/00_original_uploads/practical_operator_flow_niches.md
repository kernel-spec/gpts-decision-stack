# Praktický 2–3denní operátorský flow pro výběr nichí, ICP a generování leadů

Cílem tohoto plánu je v průběhu dvou až tří pracovních dnů (přibližně 10 hodin práce denně) **zanalyzovat nabídky na trhu**, **zvolit pět finálních niche pro prodej**, definovat **ideálního zákazníka (ICP)**, vytvořit **list‑builder** a **najít minimálně 30 leadů** rozdělených do několika segmentů pro diverzifikaci během 14denního cash‑flow horizontu. Plán respektuje zlatý operátorský tok (router → specialista → dev layer → router) a důraz na auditovatelnost z revenue runbooků.【453901471500937†L55-L58】

## 1 Zvolená finální niche a segmentace

Na základě trendů 2026 a dostupných zdrojů byly vybrány následující oblasti:

1. **Agentic AI & AI Automation** – poptávka po autonomních agentech roste; firmy jako Microsoft a Kanerika nabízejí nástroje pro multi‑agentní automatizaci【624726172201887†L689-L704】【658257015346082†L150-L162】.
2. **Udržitelné & eko‑friendly produkty** – zákazníci (zejména generace Z) platí více za zelené zboží; značky jako Patagonia či IKEA mají udržitelnost zakotvenou ve své DNA【667290506002333†L90-L106】【667290506002333†L108-L120】.
3. **Zdraví a wellness / home fitness & athleisure** – aktivní životní styl a hybridní oblečení exploduje, kolekce 2026 od Lululemon a Bandit Running ukazují budoucí směr【565365162403020†L58-L63】【565365162403020†L133-L146】.
4. **Subscription box & direct‑to‑consumer služby** – personalizované boxy s jídlem, knihami či životním stylem zaznamenávají boom; start‑upy jako Butternut Box nebo Literati přinášejí kurátorované produkty【940647498729349†L144-L148】【940647498729349†L218-L223】.
5. **Pet tech & smart pet products** – segment pet care roste; značky Chewy, The Farmer’s Dog nebo Vetcove uspokojují nároky na zdraví a pohodlí domácích mazlíčků【414341404106804†L140-L148】【414341404106804†L170-L180】.

Aby bylo možné cílit během 14denního cash‑flow na více segmentů, rozděluje se 30 leadů do tří hlavních skupin: **AI Automation**, **Udržitelné/athleisure** a **Subscription Box** (pet tech spadá pod subscription box se službami pro zvířata).

### Tabulka vybraných leadů pro tři segmenty (10 leadů/segment)

| Segment & účel | Lead (společnost) | Odůvodnění a zdroj |
|---|---|---|
| **AI Automation** | **OpenAI** | Buduje GPT agenty, které provádějí end‑to‑end automatizaci a tvoří doménově specifické asistenty【624726172201887†L667-L676】. |
| | **Microsoft** | Nabízí Copilot a AutoGen pro orchestraci multi‑agentních úloh napříč platformami【624726172201887†L689-L704】. |
| | **Anthropic** | Vyvíjí „constitutional AI“ s důrazem na etiku a bezpečnost agentů【624726172201887†L705-L719】. |
| | **Adept AI** | Systém ACT‑1 umožňuje agentům provádět úkoly pomocí přirozeného jazyka【624726172201887†L721-L735】. |
| | **Cognition Labs** | Vytvořilo autonomního AI inženýra Devina, který píše a ladí kód【624726172201887†L736-L744】. |
| | **Perplexity AI** | Nabízí Comet – real‑time vyhledávací a analytický engine pro data【624726172201887†L751-L764】. |
| | **Kanerika** | Poskytuje agentic AI pro finance, zdravotnictví a právo; agenti musí splňovat přísné regulační požadavky【658257015346082†L150-L162】. |
| | **DevCom** | Vyvíjí na míru agentické AI systémy a integruje je do komplexních firemních prostředí【658257015346082†L150-L162】. |
| | **Intuz** | Zaměřuje se na multimodální agenty pro obchod, podporu, HR a supply‑chain【658257015346082†L156-L162】. |
| | **Teneo AI** | Nabízí hybridní NLU a LLM agenty pro kontakt‑centra a regulované obory【658257015346082†L162-L164】. |
| **Udržitelné produkty & Athleisure** | **Patagonia** | Vkládá udržitelnost do každého článku výroby; recykluje oblečení【667290506002333†L90-L106】. |
| | **IKEA** | Cílem je stát se klimaticky pozitivní do 2030; používá obnovitelné materiály a energeticky efektivní logistiku【667290506002333†L108-L120】. |
| | **Tesla** | Posouvá dopravu směrem k bezemisním elektromobilům【667290506002333†L122-L129】. |
| | **Seventh Generation** | Vyrábí ekologické čisticí a domácí produkty, snižuje uhlíkovou stopu【667290506002333†L134-L147】. |
| | **Ben & Jerry’s** | Známé kampaně za klima a propojení podnikání s ekologickým aktivismem【667290506002333†L149-L156】. |
| | **Lush** | Etická kosmetika s minimálním balením a cruelty‑free sourcingem【667290506002333†L160-L170】. |
| | **REI** | Outdoorový prodejce využívající obnovitelnou energii, který snižuje emise【667290506002333†L172-L179】. |
| | **TOMS** | Model „one for one“ – za každý prodaný pár bot věnuje pár potřebným; podporuje komunitní rozvoj【667290506002333†L180-L191】. |
| | **Lululemon** | Aktivwear brand známý inovacemi; kolekce 2026 kombinuje výkonnost, styl a komunitu【565365162403020†L133-L146】. |
| | **Bandit Running** | Vytváří běžecké oblečení s důrazem na funkci i estetiku; kolekce 2025/26 využívá technické materiály a moderní design【565365162403020†L108-L123】. |
| **Subscription Box & Pet Services** | **Butternut Box** | Poskytuje personalizované krmivo pro psy; čerstvé jídlo na míru【940647498729349†L144-L148】. |
| | **Trade** | Spojuje milovníky kávy s nezávislými pražírnami; používá kvíz k doporučení čerstvě pražené kávy【940647498729349†L158-L162】. |
| | **Vinyl Me, Please** | Kurátoruje limitované edice vinylových desek, doplněné o umělecké bonusy【940647498729349†L172-L177】. |
| | **Maker Wine** | Přináší prémiová konzervovaná vína od nezávislých vinařů【940647498729349†L187-L192】. |
| | **She’s Well** | Nabízí předplatné zaměřené na ženské zdraví – produkty, suplementy, edukaci【940647498729349†L194-L207】. |
| | **Literati** | Dětská knižní služba; každý měsíc posílá kurátorované balíčky knih a podporuje lásku ke čtení【940647498729349†L218-L223】. |
| | **OurShelves** | Knižní předplatné zaměřené na inkluzivní a diverzitní dětskou literaturu【940647498729349†L233-L238】. |
| | **Scentbird** | Předplatné parfémů, které umožňuje vyzkoušet designerské vůně ve 30denním balení【940647498729349†L248-L253】. |
| | **Bokksu** | Zasílá autentické japonské snacky a čaje; boxy mají kulturní tematiku【940647498729349†L263-L267】. |
| | **Bespoke Post** | Lifestyle box pro muže; každé balení obsahuje unikátní, vysoce kvalitní produkty z různých kategorií【940647498729349†L279-L284】. |

## 2 Dvoudenní až třídenní harmonogram (10 hodin denně)

Níže uvedený harmonogram rozděluje práci do dvou intenzivních dnů (s volitelným třetím dnem pro prohloubení). Každý blok zahrnuje klíčové operátorské úkoly, které vychází z revenue runbooků (první desetiminutovka, zlatý tok, aktualizace logů a manifestu). Výsledkem je výběr finálních nichí, definice ICP, vytvoření list‑builderu a získání leadů.

### Den 1 – Analýza trhu a definice ICP (10 hodin)

| Čas | Aktivita | Detaily |
|---|---|---|
| **09:00–10:00** | **Kick‑off & nastavení** | Spusť řídicí moduly (System OS Master, Stack Dev Layer, Session Logger, Manifest Keeper) a otevři revenue runbooky. Vyplň **SESSION_ID**, **RUN_ID**, lane (revenue/discovery) a cíle. Připomeň si zlatý tok a kontrolní pravidla【453901471500937†L55-L58】. |
| **10:00–12:00** | **Analýza trendů a volba 5 nichí** | Prozkoumej články o emerging niche (agentic AI, longevity, mental fitness, circular economy apod.), tržní statistiky a sezónní poptávku. Vyber finálních 5 nichí uvedených výše. Zaznamenej důvody (velikost trhu, růst, profitabilita). |
| **12:00–13:00** | **Definice ICP pro každou nichi** | Pro každou zvolenou oblasti popiš ideálního zákazníka: demografii, potřeby a motivace. Příklad: **Agentic AI** → malé a střední B2B firmy hledající automatizaci procesů; **Udržitelné produkty** → mladí ekologicky smýšlející spotřebitelé; **Subscription box** → rodiny nebo milovníci specialit hledající pohodlí a personalizaci. |
| **13:00–14:00** | **Pauza + log update** | Krátký oběd; zapiš dosavadní kroky do session logu a manifestu. |
| **14:00–16:00** | **Sestavení počátečního lead listu** | Vyhledej a shromáždi alespoň 10 firem pro každý segment (viz tabulka). Využij články se seznamy firem (agentic AI, udržitelné značky, subscription boxy). Pro každou firmu uveď krátký popis, web a důvod, proč je vhodná. Založ si **list‑builder** (tabulka/CRM) s poli: společnost, segment, ICP fit, kontaktní kanál. |
| **16:00–18:00** | **Vytvoření operátorského profilu & nástrojů** | Založ si profily na platformách pro vyhledávání leadů (např. LinkedIn, Crunchbase, Apollo.io). Připrav si skript pro oslovování (příběh hodnoty pro každý ICP). Nastav si složky v manifestu pro ukládání surových vstupů a výstupů. |

### Den 2 – Vyhodnocení a prioritizace leadů (10 hodin)

| Čas | Aktivita | Detaily |
|---|---|---|
| **09:00–10:00** | **Rekapitulace a kontrola** | Ověř, zda jsou všechny informace ze Dne 1 zalogovány. Uprav segmentaci podle nových zjištění (např. sloučení pet tech pod subscription box). |
| **10:00–12:00** | **Hluboký průzkum leadů** | Navštiv webové stránky každého kandidáta, zkontroluj jejich nabízené produkty/služby, cenové modely a konkurenční výhody. Zaznamenávej KPI (cena, předplatné, unikátní benefit) do list‑builderu. |
| **12:00–13:00** | **Scoring a výběr top leadů** | Pro každý segment vytvoř skórovací model (např. 1–5 bodů pro relevanci, růst, snadnost spolupráce). Vyber **finálních 30 leadů** (10 v každém segmentu) na základě nejvyššího skóre a vhodnosti pro 14denní cash‑flow. |
| **13:00–14:00** | **Pauza + log update** | Krátký oběd; zapiš výsledky scoringu. |
| **14:00–16:00** | **Plánování outreach** | Vytvoř pro každý segment personalizované zprávy (výzvy k akci, přidaná hodnota). Naplánuj kalendář kontaktů na 14 dní (čas odeslání, následné follow‑up). Ujisti se, že rozdělení leadů mezi segmenty dovolí diverzifikaci cash‑flow. |
| **16:00–18:00** | **Uzavření a příprava implementace** | Aktualizuj manifest: přidej seznam leadů, finální verdikty a next steps. Připrav data pro eventuální marketingovou kampaň (např. emailové seznamy, LinkedIn spojení). Pokud zbývá čas, začni s prvními kontaktními emaily nebo zprávami. |

### Den 3 (volitelný) – Iterace a optimalizace

Pokud je potřeba třetí den:

- **Analýza odezvy**: Sleduj počáteční odpovědi od oslovených leadů, vyhodnoť míru konverze a případné námitky.
- **Úprava ICP a sdělení**: Na základě reakce uprav messaging a případně i definici ICP.
- **Prohloubení segmentů**: Vyhledej doplňkové firmy v silně reagujících segmentech nebo alternativy tam, kde je odezva nízká.
- **Závěrečná zpráva**: Ulož kompletní trail do manifestu, vyhodnoť úspěch (počet odpovědí, booked calls, předpokládaný revenue). Dodržuj zlatý tok a nikdy neobcházej release gate.

## 3 Praktické tipy pro implementaci

- **Zlatý tok**: Každý business krok posílej přes router (`System OS Master`) a všechny raw výstupy ukládej do `Stack Dev Layer`【453901471500937†L55-L58】. Tím zajistíš auditní stopu a snadnou re‑entry.
- **Kontrola pravidel**: Nikdy neposílej raw output přímo do routeru ani specialistovi; nespouštěj live send bez schválení release gate【453901471500937†L58-L60】.
- **Evidence**: Udržuj kompletní logy a manifest (vstupy, výstupy, verdikty, drift type). To usnadní retrospektivu a případný post‑batch decision.
- **Diversifikace cash‑flow**: Díky rozdělení leadů do třech segmentů můžeš během 14 dnů experimentovat s nabídkou a rychle přesouvat pozornost mezi high‑performing segmenty.

Tento plán poskytuje strukturovaný postup, jak během dvou až tří dnů identifikovat atraktivní niche, definovat ICP, vytvořit list‑builder a oslovit více než 30 relevantních firem. Postup vychází z aktuálních trendů a runbooků GPT‑stacku a pomůže operátorovi efektivně nastartovat revenue pipeline.
