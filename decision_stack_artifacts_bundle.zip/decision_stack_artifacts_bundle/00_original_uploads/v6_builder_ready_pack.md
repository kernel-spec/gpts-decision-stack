# Revenue Simulation – New ICP Sales: v6 Builder‑Ready Pack

This **v6 pack** prepares the revenue lane workflow for direct deployment in a Custom GPT/Builder environment.  It contains three layers:

1. **Conversation starters** – short prompts to initiate specific runs or queries.  
2. **Operator macros** – copy‑paste templates for each scenario, plus a universal macro and quick recovery macros for common failure modes.  
3. **Fail‑case macros and control macros** – ready responses for missing inputs, drifts and other errors, along with quick commands for builders.

These artefacts are designed for immediate use within the Builder while preserving the governed workflow discipline: all steps must go through `SYSTEM_OS_MASTER → specialist → STACK_DEV_LAYER → SYSTEM_OS_MASTER`【453901471500937†L55-L58】; PASS/BLOCKED/STOP decisions are enforced【937679800961216†L2244-L2255】.

---

## 1) Builder‑Ready Conversation Starters

Place these in the **Conversation Starters** section of your Custom GPT/Builder:

- **Run Discovery:** *“Run DISCOVERY for Governed GPT Workflow Audit and return PASS / BLOCKED / STOP.”*
- **Run ICP → Shortlist:** *“Run ICP → SHORTLIST for Governed GPT Workflow Audit and build a bounded shortlist of 25 accounts.”*
- **Run Positioning & Claims:** *“Run POSITIONING & CLAIMS and lock claim-safe positioning for Head of RevOps in B2B SaaS.”*
- **Run Asset Generation:** *“Run ASSET GENERATION and produce 3 claim-safe outbound email variants with one CTA only.”*
- **Run Launch Safety:** *“Run LAUNCH SAFETY for the approved outbound asset and decide whether batch release may proceed.”*
- **Run Post‑Batch Decision:** *“Run POST-BATCH DECISION and choose only one path: repeat / revise / narrow / stop.”*
- **Show Next Bottleneck:** *“Show me the next bottleneck for the current revenue lane step.”*
- **Check Verdict:** *“Check whether the current step is PASS, BLOCKED, or STOP and explain only the minimum fix required.”*
- **Re‑enter:** *“Re-enter through STACK_DEV_LAYER and return the routed summary only.”*
- **Audit Drifts:** *“Audit the current run for route drift, schema drift, or narrowing drift.”*

These starters trigger the router to run specific scenarios or audits according to the pack.

---

## 2) Operator Macros

These macros can be pasted by operators during a session.  The **Universal run macro** defines the structure; scenario‑specific macros fill in the fields.

### 2.1 Universal Run Macro

```
Use this operating protocol:
SYSTEM_OS_MASTER → specialist → STACK_DEV_LAYER → SYSTEM_OS_MASTER

Rules:
- choose exactly one specialist
- do not bypass STACK_DEV_LAYER
- do not return raw artifact as final decision
- do not perform implicit narrowing
- close only as PASS / BLOCKED / STOP

Now run this scenario:

scenario:
run_id:
session_id:
artifact_id_prefix:
inputs:
constraints:
expected_specialist:
expected_reviewer:
expected_artifact:
exit_criteria:
stop_conditions:
```

### 2.2 Discovery Macro

```
Run DISCOVERY now.

scenario: DISCOVERY
run_id: RUN_NEW_ICP_DISCOVERY_01
session_id: SESSION_NEW_ICP_SALES_01
artifact_id_prefix: REV_DISCOVERY

inputs:
- offer_name: Governed GPT Workflow Audit
- target_market: B2B SaaS
- target_buyer: Head of RevOps / Revenue Operations leader
- business_problem: GPT usage exists, but workflow truth, approvals, evidence, and production discipline are fragmented
- commercial_goal: identify the shortest credible wedge for first outreach
- primary_cta: Book a 20-min diagnostic call

constraints:
- no guarantee language
- no invented market proof
- keep the offer narrow
- do not broaden into full AI transformation

expected_specialist:
- MARKET_SCOUT_OUTBOUND

expected_artifact:
- DISCOVERY__market_scan__MARKET_SCOUT_OUTBOUND__RUN_NEW_ICP_DISCOVERY_01__v1

exit_criteria:
- one usable buyer problem is explicit
- one usable commercial wedge is explicit
- exclusions are explicit
- route stays audit-first

stop_conditions:
- generic AI consulting drift
- invented proof
- no clear wedge

Return:
- routed summary
- next bottleneck
- FINAL STATUS
```

### 2.3 ICP → Shortlist Macro

```
Run ICP → SHORTLIST now.

scenario: ICP → SHORTLIST
run_id: RUN_NEW_ICP_SHORTLIST_01
session_id: SESSION_NEW_ICP_SALES_01
artifact_id_prefix: REV_SHORTLIST

inputs:
- locked_offer: Governed GPT Workflow Audit
- locked_market: B2B SaaS
- target_buyer_title_primary: Head of RevOps
- target_buyer_title_secondary: Revenue Operations leader
- desired_output_count: 25
- inclusion_signals:
  - ops-heavy workflow ownership
  - revenue systems/process responsibility
  - tooling sprawl
- exclusion_signals:
  - agencies
  - solo founders without ops complexity
  - non-B2B SaaS

constraints:
- no speculative personalization
- no hidden narrowing
- explicit inclusion/exclusion logic required

expected_specialist:
- LIST_BUILDER

expected_artifact:
- ICP_SHORTLIST__candidate_list__LIST_BUILDER__RUN_NEW_ICP_SHORTLIST_01__v1

exit_criteria:
- shortlist exists
- inclusion logic explicit
- exclusion logic explicit
- list usable for outbound

stop_conditions:
- vague criteria
- title mixing drift
- hidden narrowing

Return:
- routed summary
- next bottleneck
- FINAL STATUS
```

### 2.4 Positioning & Claims Macro

```
Run POSITIONING & CLAIMS now.

scenario: POSITIONING & CLAIMS
run_id: RUN_NEW_ICP_POSITIONING_01
session_id: SESSION_NEW_ICP_SALES_01
artifact_id_prefix: REV_POSITIONING

inputs:
- locked_offer: Governed GPT Workflow Audit
- locked_icp: Head of RevOps / Revenue Operations leader in B2B SaaS
- primary_cta: Book a 20-min diagnostic call
- allowed_proof_basis:
  - founder-built governed stack exists
  - worker-backed state/evidence/closure discipline exists
- disallowed_claims:
  - no guaranteed revenue lift
  - no guaranteed production outcome
  - no fake compliance guarantee

constraints:
- no guarantee language
- no inflated transformation claims
- preserve audit-first wedge

expected_specialist:
- POSITIONING_POLICE

expected_reviewer:
- CLAIMS_EVIDENCE_REVIEWER

expected_artifact:
- POSITIONING_AND_CLAIMS__message_policy__POSITIONING_POLICE__RUN_NEW_ICP_POSITIONING_01__v1

exit_criteria:
- core positioning explicit
- claim boundary explicit
- banned wording explicit
- CTA locked
- reviewer verdict READY or READY_WITH_FIXES

stop_conditions:
- unsupported claims
- CTA drift
- reviewer FAIL

Return:
- routed summary
- next bottleneck
- FINAL STATUS
```

### 2.5 Asset Generation Macro

```
Run ASSET GENERATION now.

scenario: ASSET GENERATION
run_id: RUN_NEW_ICP_ASSET_01
session_id: SESSION_NEW_ICP_SALES_01
artifact_id_prefix: REV_ASSET

inputs:
- locked_offer: Governed GPT Workflow Audit
- locked_icp: Head of RevOps / Revenue Operations leader in B2B SaaS
- locked_positioning: audit-first, governed operating discipline
- locked_claim_boundary:
  - audit / map / recommend
  - no performance guarantee
  - no implementation guarantee
- locked_cta: Book a 20-min diagnostic call
- asset_type: cold outbound email
- desired_variants: 3

constraints:
- single CTA only
- no fake familiarity
- no fluff
- no unapproved claims

expected_specialist:
- ASSET_ENGINE

expected_reviewer:
- CLAIMS_EVIDENCE_REVIEWER

expected_artifact:
- ASSET_GENERATION__cold_email__ASSET_ENGINE__RUN_NEW_ICP_ASSET_01__v1

exit_criteria:
- 3 usable variants exist
- CTA preserved
- claim boundary preserved
- reviewer verdict READY or READY_WITH_FIXES

stop_conditions:
- multiple CTA drift
- claim inflation
- reviewer FAIL

Return:
- routed summary
- next bottleneck
- FINAL STATUS
```

### 2.6 Launch Safety Macro

```
Run LAUNCH SAFETY now.

scenario: LAUNCH SAFETY
run_id: RUN_NEW_ICP_LAUNCH_01
session_id: SESSION_NEW_ICP_SALES_01
artifact_id_prefix: REV_LAUNCH

inputs:
- locked_asset: approved outbound email
- locked_icp: Head of RevOps / Revenue Operations leader in B2B SaaS
- batch_size: 25
- sending_surface: founder-led manual / low-volume outbound
- release_scope:
  - single batch
  - single asset type
  - single CTA

constraints:
- do not skip release gate
- do not expand batch size
- no extra claims

expected_specialist:
- DELIVERABILITY_GUARD

expected_reviewer:
- RELEASE_GATE_REVIEWER

expected_artifact:
- LAUNCH_SAFETY__batch_release_check__DELIVERABILITY_GUARD__RUN_NEW_ICP_LAUNCH_01__v1

exit_criteria:
- risks explicit
- blockers explicit
- reviewer verdict READY or READY_WITH_FIXES
- operator knows if launch may proceed now

stop_conditions:
- release gate missing
- reviewer FAIL
- unresolved hard blocker

Return:
- routed summary
- next bottleneck
- FINAL STATUS
```

### 2.7 Post‑Batch Decision Macro

```
Run POST-BATCH DECISION now.

scenario: POST-BATCH DECISION
run_id: RUN_NEW_ICP_POSTBATCH_01
session_id: SESSION_NEW_ICP_SALES_01
artifact_id_prefix: REV_POSTBATCH

inputs:
- launched_batch_id: BATCH_NEW_ICP_01
- batch_size: 25
- asset_used: approved outbound email variant
- observed_signals:
  - reply_count: [TBD]
  - positive_reply_count: [TBD]
  - call_booked_count: [TBD]
  - bounce_count: [TBD]
  - objection_patterns: [TBD]

constraints:
- no vanity interpretation
- no invented performance signal
- decision must come from observed batch signals

expected_specialist:
- PERFORMANCE_MEMORY

expected_artifact:
- POST_BATCH_DECISION__performance_memory__PERFORMANCE_MEMORY__RUN_NEW_ICP_POSTBATCH_01__v1

exit_criteria:
- performance signals explicit
- repeated failures explicit
- one next bottleneck explicit
- one decision path chosen

stop_conditions:
- no usable batch evidence
- contradictory next steps
- no explicit bottleneck

Return:
- routed summary
- next bottleneck
- FINAL STATUS
```

---

## 3) Fail‑Case Macros

Use these macros to handle common failure patterns quickly.

### 3.1 Missing Inputs

```
Critical input check failed.

Return only:
- MISSING INPUTS
- WHY BLOCKING
- MINIMUM REQUIRED TO CONTINUE
- FINAL STATUS: BLOCKED

Do not continue routing.
Do not select another specialist.
Do not invent missing fields.
```

### 3.2 Route Drift

```
Route drift detected.

Return:
- DEFECT TYPE: route_drift
- BLOCKING REASON
- MINIMUM FIX REQUIRED
- FINAL STATUS: STOP

Do not continue to another specialist.
Do not convert raw output into a final verdict.
```

### 3.3 Schema Drift

```
Schema drift detected.

Return:
- DEFECT TYPE: schema_drift
- BLOCKING REASON
- MINIMUM FIX REQUIRED
- FINAL STATUS: BLOCKED
```

### 3.4 Narrowing Drift

```
Unauthorized narrowing detected.

Return:
- DEFECT TYPE: narrowing_drift
- BLOCKING REASON
- MINIMUM FIX REQUIRED
- FINAL STATUS: STOP

Do not continue unless scenario or operator explicitly authorizes narrowing.
```

### 3.5 Boundary Violation

```
Boundary violation detected.

Return:
- DEFECT TYPE: boundary_violation
- BLOCKING REASON
- MINIMUM FIX REQUIRED
- FINAL STATUS: STOP

Do not approve the step.
Do not continue routing.
```

### 3.6 Reviewer Fail

```
Reviewer returned FAIL.

Return:
- DEFECT TYPE: outcome_failure
- BLOCKING REASON
- MINIMUM FIX REQUIRED
- FINAL STATUS: STOP

Do not promote READY_WITH_FIXES to PASS.
Do not bypass release or claims review.
```

### 3.7 Handoff Failure

```
STACK_DEV_LAYER handoff is incomplete.

Return:
- DEFECT TYPE: handoff_failure
- BLOCKING REASON
- MINIMUM FIX REQUIRED
- FINAL STATUS: BLOCKED

No step is complete until:
ROUTER RE-ENTRY READY: YES
```

### 3.8 Operator Confusion

```
Operator request is ambiguous or mixes multiple steps.

Return:
- DEFECT TYPE: operator_confusion
- BLOCKING REASON
- MINIMUM FIX REQUIRED
- FINAL STATUS: BLOCKED

Ask only for the minimum clarification required to continue.
```

### 3.9 Contradictory Outcome

```
Contradictory outcome detected.

Return:
- DEFECT TYPE: outcome_failure
- BLOCKING REASON
- MINIMUM FIX REQUIRED
- FINAL STATUS: STOP

Do not return multiple next steps or multiple final decisions.
```

---

## 4) Builder Operator Control Macros

These short commands support dynamic control and auditing within the Builder.

- **Show next bottleneck**
  
  *“Show only: current stage, current blocker, next bottleneck, minimum fix required, FINAL STATUS.”*

- **Re‑enter from STACK_DEV_LAYER**
  
  *“Re-enter from STACK_DEV_LAYER now.  Do not restate the raw artifact.  Return only the routed summary needed for the next decision.”*

- **Force exact verdict**

  *“Return only: EXIT CRITERIA CHECK, STOP CONDITIONS CHECK, NEXT BOTTLENECK, FINAL STATUS.  Allowed FINAL STATUS: PASS / BLOCKED / STOP.”*

- **Audit drift**

  *“Audit the current step for: route_drift, schema_drift, narrowing_drift, wording_drift, boundary_violation, handoff_failure.  Return only: defect found / no defect found, blocking reason, minimum fix required, FINAL STATUS.”*

- **Enforce one‑specialist rule**

  *“Enforce one-specialist rule.  Select exactly one specialist for the current step.  If more than one would be needed, return BLOCKED and explain the minimum sequencing fix.”*

---

## 5) Builder‑Ready Daily Quick Cards

For a minimal daily workflow, you can use these one‑line commands:

- “Run DISCOVERY for Governed GPT Workflow Audit.”
- “Run ICP → SHORTLIST and build a bounded shortlist of 25 accounts.”
- “Run POSITIONING & CLAIMS and lock claim‑safe wording.”
- “Run ASSET GENERATION and produce 3 usable outbound email variants.”
- “Run LAUNCH SAFETY and decide whether batch release may proceed.”
- “Run POST‑BATCH DECISION and choose repeat / revise / narrow / stop.”
- “Show the current next bottleneck only.”
- “Audit the current step and return PASS / BLOCKED / STOP only.”

---

## 6) Builder Deployment Note

To deploy this pack in the Builder, organise it as follows:

- **Conversation starters:** use section 1 as the list of entry prompts for the Builder.
- **Operational use:** operators should copy and paste macros from section 2 for each scenario.  
- **Recovery flow:** handle errors using the fail‑case macros in section 3.  
- **Quick controls:** use commands from sections 4 and 5 for dynamic inspection and execution.

---

## 7) Final Verdict

The **v6 pack** is a fully deployable layer for Builder/Custom GPT environments.  It provides conversation starters, run macros, fail‑case macros, and quick controls, allowing operators to run the revenue lane daily without referencing long documents.  This pack is intended for real‑world operations and ensures compliance with the governed workflow discipline at every step.

