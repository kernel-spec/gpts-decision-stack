# Spec – iOS Operator Layer Deployment

This document defines the purpose, scope and deployment considerations for the **iOS Operator Layer** used in the `Revenue Simulation – New ICP Sales` motion.

## Purpose

The iOS Operator Layer is a single Custom GPT acting as the gateway for operators running governed revenue workflows on mobile devices.  It provides a thin conversational shell that:

* Recognises which scenario the operator is running (e.g., discovery, shortlisting, positioning, asset generation, launch safety, post‑batch decision).
* Validates all required inputs before proceeding.
* Invokes exactly one specialist role per step and routes raw outputs through the `STACK_DEV_LAYER` to ensure an auditable artefact trail.
* Applies exit criteria and stop conditions to determine whether the step passes, is blocked or must stop.
* Returns a concise routed summary, the next bottleneck and a final status (`PASS`, `BLOCKED` or `STOP`).

## Architecture and Source of Truth

* **Worker runtime** – The backend running on Cloudflare Workers is the source of truth for project state, decisions, artefact registry, policy execution and transition legality.  It exposes actions (defined in `actions/openapi.yaml`) that the Custom GPT may call (e.g., `get_project_status`, `get_next_action`, `save_artifact`, `record_model_output`, `check_sell_ready`, `request_founder_decision`).
* **Custom GPT (iOS Operator Layer)** – A thin shell that uses the Builder instructions, conversation starters, knowledge notes and SOP contained in `custom_gpts/ios_operator_layer/`.  It does not store or invent state; it merely orchestrates the conversation by calling Worker actions, enforcing the golden flow, and returning a minimal summary.
* **Specialists & reviewers** – These are internal roles defined in prompts and runbooks (e.g., `MARKET_SCOUT_OUTBOUND`, `LIST_BUILDER`, `POSITIONING_POLICE`, `ASSET_ENGINE`, `DELIVERABILITY_GUARD`, `PERFORMANCE_MEMORY`, `CLAIMS_EVIDENCE_REVIEWER`, `RELEASE_GATE_REVIEWER`).  They are not deployed as separate GPTs or UIs; the operator layer dispatches work to them via the Worker and ensures their outputs are stored through `STACK_DEV_LAYER`.
* **Scenarios & scenario cards** – The folder `custom_gpts/ios_operator_layer/scenarios/revenue_simulation_new_icp_sales/` contains concise cards describing inputs, constraints, expected roles, exit criteria and stop conditions for each scenario.  These cards guide both the GPT and the operator in performing each step.

## Operating Model

1. **Single entry point:** Only one GPT is deployed for the iOS operator interface.  All operator interactions flow through this GPT.
2. **Golden flow enforcement:** Every step must follow `SYSTEM_OS_MASTER → specialist → STACK_DEV_LAYER → SYSTEM_OS_MASTER`.  Raw outputs are never delivered directly to the operator; they are always saved first.
3. **One‑specialist rule:** Exactly one specialist role is invoked per step.  If multiple specialists are needed, the GPT returns `BLOCKED` with a defect type of `operator_confusion` and guidance on sequencing.
4. **Auditability:** Each step returns a routed summary along with the next bottleneck and final status.  If the status is not `PASS`, the summary includes a defect classification, blocking reason and minimum fix.
5. **Separation of concerns:** The GPT orchestrates.  The Worker holds truth.  The repository stores canonical scripts, runbooks, scenario cards and packaging files.  No business logic or artefact truth is embedded in prompts beyond what is required for orchestration.

## Deployment artefacts

* **custom_gpts/ios_operator_layer/** – Contains builder instructions, conversation starters, knowledge notes, operator SOP, macros and scenario cards.  This is the primary packaging for the Custom GPT.
* **operations/specs/ios-operator-layer-deployment.md** – This specification.
* **actions/openapi.yaml** and **actions/openapi.openai.yaml** – Define the API surface exposed by the Worker runtime.
* **knowledge/**, **operations/** and **qa/** – Additional documentation, governance artefacts and evidence required by the stack (not directly consumed by the operator layer but referenced by specialists and reviewers).

## Forbidden Actions

* The operator layer must not bypass the Worker or call underlying data stores directly.
* It must not contain or rely upon any hidden business logic that modifies the source of truth.
* It must not deploy multiple GPTs for the same lane or allow parallel routing through multiple specialists.

## Change Management

Updates to the iOS operator layer must follow the standard change management process:

1. Propose changes via pull request including updates to builder instructions, conversation starters, macros or scenario cards.
2. Review for compliance with the operating model, defect taxonomy and Worker API surface.
3. Update this spec if the architecture, flow or allowed scenarios change.
4. After approval, publish the updated Custom GPT via the Builder.

This spec ensures that the iOS operator layer remains aligned with the governed operating model while providing a predictable and auditable interface for mobile operators.