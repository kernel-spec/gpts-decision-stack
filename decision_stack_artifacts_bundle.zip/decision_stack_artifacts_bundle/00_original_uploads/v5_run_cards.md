# Revenue Simulation – New ICP Sales: v5 Copy‑Paste Run Cards

The **v5 pack** contains concise run cards designed for everyday operation in Custom GPT / Builder environments.  Each card summarises the **scenario**, **required inputs**, **expected specialist**, **expected artifact**, **exit criteria**, **stop conditions**, and the **router’s tasks**.  Operators can simply copy the appropriate card, paste it into `SYSTEM_OS_MASTER`, and follow the standard golden flow without improvisation.【453901471500937†L55-L58】  This reduces friction while preserving auditability and decision discipline【937679800961216†L2244-L2255】.

## V5.0 – Global Run Card Header

**Operating protocol:** `SYSTEM_OS_MASTER → specialist → STACK_DEV_LAYER → SYSTEM_OS_MASTER`

**Rules:**
- Do **not** bypass `STACK_DEV_LAYER`.
- Do **not** return raw artifact as a final decision.
- Do **not** hallucinate missing inputs.
- Do **not** perform implicit narrowing (scope changes require explicit authorisation).
- Close each step only as **PASS**, **BLOCKED**, or **STOP**.

**Missing input rule:** If a critical input is missing, return only:
- `MISSING INPUTS` – list missing fields
- `WHY BLOCKING` – explain why
- `MINIMUM REQUIRED TO CONTINUE` – specify the minimum fix
- `FINAL STATUS: BLOCKED`

---

## V5.1 – Discovery Run Card

```
RUN CARD
DISCOVERY

scenario: DISCOVERY
run_id: RUN_NEW_ICP_DISCOVERY_01
session_id: SESSION_NEW_ICP_SALES_01
artifact_id_prefix: REV_DISCOVERY

inputs:
- offer_name: Governed GPT Workflow Audit
- target_market: B2B SaaS
- target_buyer: Head of RevOps / Revenue Operations leader
- business_problem: GPT usage exists, but workflow truth, approvals, evidence, and production discipline are fragmented
- commercial_goal: identify the shortest credible wedge for first outreach
- primary_cta: Book a 20-min diagnostic call

constraints:
- no guarantee language
- no invented market proof
- no fake enterprise proof
- keep offer narrow
- do not broaden into full AI transformation

expected_specialist:
- MARKET_SCOUT_OUTBOUND

expected_artifact:
- DISCOVERY__market_scan__MARKET_SCOUT_OUTBOUND__RUN_NEW_ICP_DISCOVERY_01__v1

exit_criteria:
- one usable buyer problem is explicit
- one usable commercial wedge is explicit
- exclusions are explicit
- route stays audit-first

stop_conditions:
- offer drift to generic AI consulting
- invented proof
- no clear wedge
- buyer too broad without narrowing authorisation

router_task:
- validate inputs
- invoke one specialist only
- force save through STACK_DEV_LAYER
- return routed summary
- close as PASS / BLOCKED / STOP
```

**Practical summary:** Start the Discovery run with the given offer, market, buyer and CTA.  Find the shortest credible commercial wedge; invoke exactly one specialist; save the raw artifact via `STACK_DEV_LAYER`; return a routed summary and close with PASS/BLOCKED/STOP.

---

## V5.2 – ICP → Shortlist Run Card

```
RUN CARD
ICP → SHORTLIST

scenario: ICP → SHORTLIST
run_id: RUN_NEW_ICP_SHORTLIST_01
session_id: SESSION_NEW_ICP_SALES_01
artifact_id_prefix: REV_SHORTLIST

inputs:
- locked_offer: Governed GPT Workflow Audit
- locked_market: B2B SaaS
- target_buyer_title_primary: Head of RevOps
- target_buyer_title_secondary: Revenue Operations leader
- target_company_profile:
  - B2B SaaS
  - 20–500 employees
  - GTM / ops complexity visible
  - likely manual handoffs
  - signs of AI experimentation without operating discipline
- inclusion_signals:
  - ops-heavy workflow ownership
  - revenue systems/process responsibility
  - tooling sprawl
- exclusion_signals:
  - solo founders without ops complexity
  - agencies
  - non-B2B SaaS
- desired_output_count: 25

constraints:
- no fake familiarity
- no speculative personalization
- no shortlist without explicit inclusion/exclusion logic

expected_specialist:
- LIST_BUILDER

expected_artifact:
- ICP_SHORTLIST__candidate_list__LIST_BUILDER__RUN_NEW_ICP_SHORTLIST_01__v1

exit_criteria:
- shortlist exists
- inclusion logic explicit
- exclusion logic explicit
- data quality flags visible
- list usable for outbound

stop_conditions:
- vague criteria
- hidden narrowing
- title mixing drift
- unusable shortlist

router_task:
- validate locked inputs
- invoke LIST_BUILDER
- force STACK_DEV_LAYER save
- return routed summary
- close as PASS / BLOCKED / STOP
```

**Practical summary:** Run ICP → Shortlist.  Build a list of 25 accounts matching the locked ICP.  Include explicit inclusion and exclusion logic.  Save raw outputs via `STACK_DEV_LAYER`; summarise and close the step.

---

## V5.3 – Positioning & Claims Run Card

```
RUN CARD
POSITIONING & CLAIMS

scenario: POSITIONING & CLAIMS
run_id: RUN_NEW_ICP_POSITIONING_01
session_id: SESSION_NEW_ICP_SALES_01
artifact_id_prefix: REV_POSITIONING

inputs:
- locked_offer: Governed GPT Workflow Audit
- locked_icp: Head of RevOps / Revenue Operations leader in B2B SaaS
- core_problem: GPT usage may exist, but state, approvals, evidence, and closure logic are not governed
- desired_outcome: claim-safe positioning for outbound and diagnostic proposal
- allowed_proof_basis:
  - founder-built governed stack exists
  - worker-backed state/evidence/closure discipline exists
- disallowed_claims:
  - no guaranteed revenue lift
  - no guaranteed production outcome
  - no fake compliance guarantee
  - no fully autonomous operations claim
- primary_cta: Book a 20-min diagnostic call

constraints:
- no guarantee language
- no inflated transformation claims
- preserve narrow audit wedge

expected_specialist:
- POSITIONING_POLICE

expected_reviewer:
- CLAIMS_EVIDENCE_REVIEWER

expected_artifact:
- POSITIONING_AND_CLAIMS__message_policy__POSITIONING_POLICE__RUN_NEW_ICP_POSITIONING_01__v1

exit_criteria:
- core positioning explicit
- claim boundary explicit
- banned wording explicit
- CTA locked
- reviewer verdict READY or READY_WITH_FIXES

stop_conditions:
- unsupported claims
- no claim boundary
- CTA drift
- reviewer FAIL

router_task:
- validate proof basis
- invoke POSITIONING_POLICE
- save through STACK_DEV_LAYER
- invoke CLAIMS_EVIDENCE_REVIEWER
- return routed summary
- close as PASS / BLOCKED / STOP
```

**Practical summary:** Run the Positioning & Claims scenario to lock a claim‑safe positioning.  Provide the core problem and allowed/disallowed claims.  Use one specialist and one reviewer; save artifacts; close only after reviewer verdict.

---

## V5.4 – Asset Generation Run Card

```
RUN CARD
ASSET GENERATION

scenario: ASSET GENERATION
run_id: RUN_NEW_ICP_ASSET_01
session_id: SESSION_NEW_ICP_SALES_01
artifact_id_prefix: REV_ASSET

inputs:
- locked_offer: Governed GPT Workflow Audit
- locked_icp: Head of RevOps / Revenue Operations leader in B2B SaaS
- locked_positioning: audit-first, governed operating discipline
- locked_claim_boundary:
  - audit / map / recommend
  - no performance guarantee
  - no implementation guarantee
- locked_cta: Book a 20-min diagnostic call
- asset_type: cold outbound email
- desired_variants: 3
- tone:
  - credible
  - direct
  - non-hype
  - founder-led
- required_structure:
  - hook
  - pain articulation
  - audit wedge
  - CTA

constraints:
- single CTA only
- no fake familiarity
- no fluff
- no unapproved claims

expected_specialist:
- ASSET_ENGINE

expected_reviewer:
- CLAIMS_EVIDENCE_REVIEWER

expected_artifact:
- ASSET_GENERATION__cold_email__ASSET_ENGINE__RUN_NEW_ICP_ASSET_01__v1

exit_criteria:
- 3 usable variants exist
- CTA preserved
- claim boundary preserved
- reviewer verdict READY or READY_WITH_FIXES

stop_conditions:
- multiple CTA drift
- claim inflation
- positioning drift
- reviewer FAIL

router_task:
- validate locked inputs
- invoke ASSET_ENGINE
- save via STACK_DEV_LAYER
- invoke CLAIMS_EVIDENCE_REVIEWER
- return routed summary
- close as PASS / BLOCKED / STOP
```

**Practical summary:** Launch the Asset Generation run to produce three cold outbound email variants.  Ensure single CTA, claim safety and proper structure; run the reviewer; save artifacts; close only after reviewer verdict.

---

## V5.5 – Launch Safety Run Card

```
RUN CARD
LAUNCH SAFETY

scenario: LAUNCH SAFETY
run_id: RUN_NEW_ICP_LAUNCH_01
session_id: SESSION_NEW_ICP_SALES_01
artifact_id_prefix: REV_LAUNCH

inputs:
- locked_asset: approved outbound email
- locked_icp: Head of RevOps / Revenue Operations leader in B2B SaaS
- batch_size: 25
- sending_surface: founder-led manual / low-volume outbound
- release_scope:
  - single batch
  - single asset type
  - single CTA
- claims_policy: already reviewed
- approval_context:
  - no pricing proposal in initial outreach
  - CTA only = Book a 20-min diagnostic call

constraints:
- do not skip release gate
- do not expand batch size during safety review
- no extra claims
- no personalization theater

expected_specialist:
- DELIVERABILITY_GUARD

expected_reviewer:
- RELEASE_GATE_REVIEWER

expected_artifact:
- LAUNCH_SAFETY__batch_release_check__DELIVERABILITY_GUARD__RUN_NEW_ICP_LAUNCH_01__v1

exit_criteria:
- risks explicit
- blockers explicit
- reviewer READY or READY_WITH_FIXES
- operator knows whether launch may proceed now

stop_conditions:
- release gate missing
- reviewer FAIL
- unresolved hard blocker
- asset mismatch

router_task:
- validate asset and release scope
- invoke DELIVERABILITY_GUARD
- save via STACK_DEV_LAYER
- invoke RELEASE_GATE_REVIEWER
- return routed summary
- close as PASS / BLOCKED / STOP
```

**Practical summary:** Run Launch Safety to assess whether the approved outbound email can be sent to 25 contacts.  Enforce the release gate; use one specialist and one reviewer; track risks and blockers; close the step accordingly.

---

## V5.6 – Post‑Batch Decision Run Card

```
RUN CARD
POST-BATCH DECISION

scenario: POST-BATCH DECISION
run_id: RUN_NEW_ICP_POSTBATCH_01
session_id: SESSION_NEW_ICP_SALES_01
artifact_id_prefix: REV_POSTBATCH

inputs:
- launched_batch_id: BATCH_NEW_ICP_01
- batch_size: 25
- asset_used: approved outbound email variant
- observed_signals:
  - reply_count: [TBD]
  - positive_reply_count: [TBD]
  - call_booked_count: [TBD]
  - bounce_count: [TBD]
  - objection_patterns: [TBD]
- decision_goal:
  - choose repeat / revise / narrow / stop

constraints:
- no vanity interpretation
- no invented performance signal
- no rewrite without evidence
- decision must come from observed batch signals

expected_specialist:
- PERFORMANCE_MEMORY

expected_artifact:
- POST_BATCH_DECISION__performance_memory__PERFORMANCE_MEMORY__RUN_NEW_ICP_POSTBATCH_01__v1

exit_criteria:
- performance signals explicit
- repeated failures explicit
- one next bottleneck explicit
- one decision path chosen

stop_conditions:
- no usable batch evidence
- invented success interpretation
- contradictory next steps
- no explicit bottleneck

router_task:
- validate enough observed batch data exists
- invoke PERFORMANCE_MEMORY
- save via STACK_DEV_LAYER
- return routed summary
- close as PASS / BLOCKED / STOP
```

**Practical summary:** Use the Post‑Batch Decision run to interpret the batch results and choose whether to repeat, revise, narrow or stop.  Use one specialist; no reviewer by default; rely solely on observed signals; close accordingly.

---

## V5.7 – Ultra‑Short Daily Operator Cards

For a quick daily reference, here are ultra‑short descriptions:

- **Discovery:** Find the narrow commercial wedge for the offer; pick one specialist; save and summarise; PASS/BLOCKED/STOP.
- **ICP → Shortlist:** Build a 25‑account shortlist with explicit inclusion and exclusion logic; pick one specialist; save and summarise; PASS/BLOCKED/STOP.
- **Positioning & Claims:** Lock claim‑safe positioning and claim boundary; pick specialist + reviewer; save; summarise; PASS/BLOCKED/STOP.
- **Asset Generation:** Generate three claim‑safe cold emails with single CTA; pick specialist + reviewer; save; summarise; PASS/BLOCKED/STOP.
- **Launch Safety:** Decide if the approved asset can launch to 25 contacts; pick specialist + reviewer; save; summarise; PASS/BLOCKED/STOP.
- **Post‑Batch Decision:** Analyse batch metrics to decide repeat/revise/narrow/stop; pick specialist; save; summarise; PASS/BLOCKED/STOP.

---

## V5.8 – Master Daily Card

Use this ultra‑concise card for any scenario:

```
OPERATING PROTOCOL
SYSTEM_OS_MASTER → specialist → STACK_DEV_LAYER → SYSTEM_OS_MASTER

STEP BY STEP
1. Validate inputs.
2. Select exactly one specialist.
3. Enforce STACK_DEV_LAYER save.
4. Run reviewer if required.
5. Return routed summary.
6. Close as PASS / BLOCKED / STOP.

NEVER
- Return raw artifact as final verdict.
- Bypass STACK_DEV_LAYER.
- Bypass release gate.
- Hallucinate missing inputs.
- Narrow scope implicitly.
```

---

## V5.9 – Final Verdict

The v5 pack delivers concise, copy‑paste run cards built on top of the v4 master sheets.  It minimises operator friction while maintaining the governed workflow discipline.  Operators simply choose the appropriate card, supply the minimal inputs, and follow the step‑by‑step tasks to achieve PASS/BLOCKED/STOP outcomes without improvisation.

