# End‑to‑End Operator Input Flows for Revenue Simulation (New ICP Sales)

Tento dokument popisuje jednotlivé scénáře, kterými operátor prochází při prodeji novému ICP (ideal customer profile) v revenue lane. Každá část zahrnuje vstupy, které musí operátor připravit, sekvenci specialistů (flow) a očekávané výstupy včetně exit a stop podmínek. Při všech krocích platí zlatý tok `SYSTEM_OS_MASTER → specialista → STACK_DEV_LAYER → SYSTEM_OS_MASTER` – business krok vždy posílej routeru a raw výstup specialisty ukládej do dev vrstvy【118157581700661†L8610-L8618】. Nikdy neposílej raw output přímo do routeru ani specialistovi a neobcházej release gate【118157581700661†L8615-L8619】.

## 1 Discovery – hledání nového ICP

**Vstupy operátora:**

- **user_goal**, **target_market** a **time_horizon** – stručně popiš, co chce uživatel dosáhnout, na jakém trhu a v jakém časovém rámci【118157581700661†L1580-L1586】.
- **current_offer** – aktuální produkt nebo služba, kterou chceš nabízet【118157581700661†L1580-L1586】.
- **current bottleneck** – největší překážka v současném procesu【118157581700661†L1585-L1596】.
- **constraints** – omezení (např. regulační, geografická, jazyková)【118157581700661†L1585-L1596】.

**Flow (specialisté):**

1. **SYSTEM_OS_MASTER** – router vyhodnotí vstupy a určí první krok.
2. **MARKET_SCOUT_OUTBOUND** – sbírá veřejná data a validuje tržní hypotézy. Operátor musí předat výše uvedené vstupy. Specialisté vrací *market snapshot* a první návrhy ICP.
3. **STACK_DEV_LAYER** – ukládá raw data a artefakty.
4. **SYSTEM_OS_MASTER** – router rozhodne o dalším kroku.
5. **STRUCTURAL_ENGINE** – rozloží trh na segmenty, vytvoří a zúží ICP card. Operátor předá výstupy z Market Scoutu. Specialisté vrací finální *icp_card* a další detailní strukturu trhu【118157581700661†L1588-L1596】.
6. **STACK_DEV_LAYER** → **SYSTEM_OS_MASTER** – uloží se artefakty a router uzavře discovery.

**Očekávané výstupy:**

- **market_snapshot** a **icp_card**【118157581700661†L1588-L1596】.
- Jasná primární ICP a případné záložní hypotézy【118157581700661†L1593-L1596】.
- Identifikovaný další bottleneck.

**Exit criteria:** jedna jasná ICP karta, záchova záložních hypotéz a definovaný následující bottleneck【118157581700661†L1593-L1596】.

**Stop conditions:** trh zůstává příliš široký, ICP karta není outbound‑testovatelná nebo operátor obejde dev layer【118157581700661†L1598-L1601】.

## 2 ICP → Shortlist – převod ICP na seznam účtů

**Vstupy operátora:**

- **icp_card** – výstup discovery fáze.
- **geo** a **channel** scope – definuj geografii a komunikační kanál【118157581700661†L1612-L1615】.
- Další constrainty (např. minimální velikost firmy, odvětví) – aby bylo možné připravit filtry.

**Flow (specialisté):**

1. **SYSTEM_OS_MASTER** – router potvrdí, že ICP karta a scope splňují vstupní kritéria【118157581700661†L1610-L1615】.
2. **LIST_BUILDER** – na základě icp_card připraví veřejně dostupný seznam účtů. Operátor mu předá scope a specifikuje, jaké zdroje a filtry použít. Výsledkem je strukturovaná logika shortlistu【118157581700661†L1616-L1629】.
3. **STACK_DEV_LAYER** – uloží raw shortlist, filtry a logiku.
4. **SYSTEM_OS_MASTER** – router uzavře krok.

**Očekávané výstupy:**

- **source map**, **filters**, **exclusions**, **tiering**, logika rozlišení mezi account‑ready a email‑ready a **tracker logic**【118157581700661†L1622-L1629】.

**Exit criteria:** logika shortlistu je reprodukovatelná, veřejná data jsou jasně definována, cílový objem je stanoven a je známý další bottleneck【118157581700661†L1630-L1634】.

**Stop conditions:** logika zdroje porušuje constrainty, chybí jasné vyloučení nebo není odlišen account‑ready a email‑ready【118157581700661†L1636-L1639】.

## 3 Positioning & Claims – formulace poselství a claimů

**Vstupy operátora:**

- **icp_card** a **shortlist logic** – definovaná cílová skupina a seznam účtů【118157581700661†L1650-L1654】.
- **current offer** – rámec nabídky, kterou budeš komunikovat【118157581700661†L1650-L1654】.

**Flow (specialisté):**

1. **SYSTEM_OS_MASTER** – router inicializuje positioning fázi.
2. **POSITIONING_POLICE** – vytváří jasnou positioning linii a nastavuje tonalitu. Operátor poskytne ICP, shortlist logic a nabídku a specifikuje, jaké hodnoty zdůraznit.
3. **CLAIMS_EVIDENCE_REVIEWER** – kontroluje navržené claimy a zajišťuje, že jsou podpořeny důkazy a odpovídají politice claimů【118157581700661†L1655-L1668】.
4. **STACK_DEV_LAYER** – ukládá positioning audit a seznam claimů.
5. **SYSTEM_OS_MASTER** – router uzavře krok.

**Očekávané výstupy:**

- **positioning audit**, **vocabulary rules**, **CTA lock**, **strongest allowed claim** a seznam **forbidden claims**【118157581700661†L1662-L1668】.

**Exit criteria:** jedna jasná positioning linie a pouze jeden CTA; žádný vymyšlený důkaz ani příliš široké přísliby【118157581700661†L1669-L1674】.

**Stop conditions:** více CTA cest, nepodložené nebo zakázané claimy, odklon od scope nebo neurčité pojmenování nabídky【118157581700661†L1675-L1679】.

## 4 Asset Generation – tvorba outbound assetů

**Vstupy operátora:**

- **locked positioning** a **CTA lock** – výstup z předchozí fáze【118157581700661†L1690-L1694】.
- **claims policy** – jasné zásady pro práci s claimy【118157581700661†L1690-L1694】.
- **icp_card** a **current offer** – pro správný kontext assetů【118157581700661†L1690-L1694】.

**Flow (specialisté):**

1. **SYSTEM_OS_MASTER** – router ověří, že entry kritéria jsou splněna.
2. **ASSET_ENGINE** – vytváří konkrétní outbound assety: opener (první e‑mail/DM), follow‑up a DM (přímá zpráva). Operátor může poskytnout specifické požadavky, tone‑of‑voice a CTA.
3. **CLAIMS_EVIDENCE_REVIEWER** – kontroluje assety z hlediska claimů a soulad s evidence. Na základě feedbacku může Asset Engine assety upravit【118157581700661†L1696-L1703】.
4. **STACK_DEV_LAYER** – ukládá finální assety.
5. **SYSTEM_OS_MASTER** – router uzavře generaci assetů.

**Očekávané výstupy:**

- Tři copy‑ready assety: **opener**, **follow‑up** a **DM**【118157581700661†L1703-L1707】.
- Každý asset má pouze jeden CTA a neobsahuje falešnou familiaritu nebo vymyšlené důkazy【118157581700661†L1708-L1714】.

**Exit criteria:** assety jsou připravené k odeslání, mají jeden CTA, nepoužívají garanční jazyk, nejsou „příliš osobní“ a respektují scope【118157581700661†L1708-L1714】.

**Stop conditions:** text obsahuje garanční jazyk, falešnou personalizaci, více CTA nebo není vyřešen rizikový claim【118157581700661†L1715-L1719】.

## 5 Launch Safety – rozhodnutí, zda odeslat batch

**Vstupy operátora:**

- **asset pack** – copy‑ready assety připravené k odeslání【118157581700661†L1730-L1734】.
- **shortlist logic** – definice a seznam cílových účtů【118157581700661†L1730-L1734】.
- **sending setup** – doménové nastavení, DNS baseline, ramp‑up logika a stop rules【118157581700661†L1730-L1734】.

**Flow (specialisté):**

1. **SYSTEM_OS_MASTER** – router zahájí kontrolu bezpečnosti odeslání.
2. **DELIVERABILITY_GUARD** – provede deliverability review: zkontroluje domény, IP reputaci, nastavení DNS a navrhne ramp‑up logiku. Operátor musí předat kompletní sending setup.
3. **RELEASE_GATE_REVIEWER** – vydá release verdict (`READY`, `READY_WITH_FIXES`, `FAIL`) a stanoví seznam blokátorů a pořadí oprav【118157581700661†L1735-L1747】.
4. **STACK_DEV_LAYER** – uloží review a verdict.
5. **SYSTEM_OS_MASTER** – router uzavře krok.

**Očekávané výstupy:**

- **deliverability review**, **release verdict**, přehled **blokátorů** a **fix order**【118157581700661†L1742-L1747】.

**Exit criteria:** DNS baseline je jasně pochopena, existuje ramp‑up logika a stop rules a release verdict je explicitně uveden【118157581700661†L1748-L1753】.

**Stop conditions:** chybí release verdict, stop rules nebo sending baseline, případně nejsou vyřešeny kritické blokátory【118157581700661†L1754-L1758】.

## 6 Post‑Batch Decision – vyhodnocení po odeslání

**Vstupy operátora:**

- **batch metrics**: počet **sent**, **replies**, **booked** a **closed** obchodů, **revenue**, použitý **channel**, **offer_type**, časové okno (**timeframe**) a hlavní **objections**【118157581700661†L1777-L1786】.

**Flow (specialisté):**

1. **SYSTEM_OS_MASTER** – router zahájí post‑batch analýzu.
2. **PERFORMANCE_MEMORY** – analyzuje metriky, identifikuje vzory a navrhuje verdict. Operátor musí předat všechny výše uvedené vstupy. Specialisté vrátí verdict a doporučení【118157581700661†L1766-L1794】.

**Očekávané výstupy:**

- Verdict: **SCALE**, **OPTIMIZE** nebo **KILL** – rozhodne, zda zvětšit objem, optimalizovat messaging nebo zastavit kampaň【118157581700661†L1788-L1794】.
- **top lessons** – klíčové poznatky z batche.
- **next action** – jasně definovaný další krok pro operátora【118157581700661†L1788-L1794】.

**Exit criteria:** jedno tvrdé rozhodnutí, jeden další krok a prioritizované změny【118157581700661†L1795-L1799】.

**Stop conditions:** chybí skutečná data, verdict je vágní nebo se navrhují pouze optimalizace bez skutečného rozhodnutí【118157581700661†L1800-L1803】.

---

### Shrnutí a doporučení pro operátora

- **Připrav důsledně vstupy pro každý scénář:** jasně popsaný cíl, tržní scope, nabídku a constrainty urychlí práci specialistů.
- **Dodržuj zlatý tok a auditní stopu:** každé rozhodnutí a artefakt musí projít přes `STACK_DEV_LAYER`; žádný krok neobcházej kontrolní rovinu【118157581700661†L8610-L8618】.
- **Sleduj exit a stop kritéria:** neopouštěj scénář, dokud nejsou splněny exit podmínky, a zastav proces, pokud nastanou stop podmínky.
- **Zapisuj další bottleneck a loguj každý hop:** to umožní plynulé navazování mezi scénáři a budoucí optimalizaci.

Tento end‑to‑end přehled pomůže operátorovi konzistentně a auditovatelně vést revenue simulace pro nový ICP, od počáteční discovery až po rozhodnutí po odeslání batche.