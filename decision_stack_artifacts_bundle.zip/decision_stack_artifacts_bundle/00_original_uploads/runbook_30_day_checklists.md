# Operator 30‑Day Simulation Checklists for Each Runbook

## Purpose

The GPT‑stack operating system includes a series of runbooks that guide operators through every major lane—control plane, determinism testing, revenue discovery, ICP work, positioning and claims, asset generation, launch safety, post‑batch decisions, prompt ops, product build, delivery and retention, and session logging.  To ensure mastery of each runbook, the following sections provide a **30‑day simulation checklist** for each document in the bundle.  Each plan breaks the month into paired‑day segments (Day 1–2, Day 3–4, etc.), making it practical to distribute tasks over thirty days without overwhelming daily workloads.  The tasks are aligned with the runbooks’ purpose, flow, expected outputs and stop conditions.

### How to Use This Document

- **Daily cadence:** Treat each paired‑day segment as two consecutive days—Day 1 and Day 2, Day 3 and Day 4, etc.  Adjust the pace if some activities take longer.
- **Documentation:** Keep session logs and update the manifest after each simulation.  Record raw inputs, raw outputs, verdicts and drift types as required【784665054432985†L1944-L1959】.
- **Stop conditions:** If you encounter a stop condition in a runbook (e.g., unsupported claims, unusable bundle, no release verdict), pause the simulation and address the issue before proceeding【784665054432985†L1690-L1693】【784665054432985†L1846-L1849】.
- **Cross‑reference:** Refer back to the runbook text for detailed instructions and to supporting cards like the operator quick card, release gate policy and session close‑out checklist.

---

## 00_OPERATOR_START_HERE.md – 30‑Day Simulation

The entry point for any operator, this runbook outlines the first documents to open, the golden runtime rule and the initial sequence of tasks to establish the stack【784665054432985†L1475-L1499】.  The checklist below gradually builds familiarity with the control plane and the first real path.

| Days | Focus | Simulation tasks |
|---|---|---|
|1–2|Orientation|Read the runbook’s purpose and open the recommended files (`01_CONTROL_PLANE_RUNBOOK.md`, `12_SESSION_LOGGING_AND_ARTIFACT_REGISTRY_RUNBOOK.md`, `02_STACK_DETERMINISM_RUNBOOK.md`, `LIVE_OPERATOR_RUNBOOK.md`)【784665054432985†L1475-L1499】.  Ensure you understand the golden runtime rule and the “never do” list (no specialist‑to‑specialist or raw‑output‑to‑router hops).|
|3–4|Control plane lock|Follow the “first real path”: lock the control plane, enable session logging and run the backbone tests as described【784665054432985†L1475-L1499】.  Record session IDs and manifest updates.|
|5–6|First revenue flow|Start a basic revenue discovery flow (router → `MARKET_SCOUT_OUTBOUND` → dev layer) using a sample offer.  Verify that raw outputs go to `STACK_DEV_LAYER` and business next steps return to `SYSTEM_OS_MASTER`.|
|7–8|Loss recovery|Use the “If you are lost” section: practise navigating via `MASTER_LIBRARY_INDEX.md`, asking `SYSTEM_OS_MASTER` for next steps and sending raw output to the dev layer as directed【784665054432985†L1475-L1499】.|
|9–10|Logging discipline|Revisit session logging; ensure each hop has a log entry and manifest update.  Simulate a failure such as missing log and recover.|
|11–12|Golden vs extended flow|Simulate both the canonical hop and the extended hop with a reviewer in the loop to solidify your understanding【784665054432985†L1478-L1490】.|
|13–14|Case study|Run a longer session combining revenue and prompt ops; pay attention to when to switch lanes and how the control plane directs the flow.|
|15–16|Audit check|Perform a mini audit using the common failure modes document to see if any “never do” rules were broken and correct them.|
|17–18|Review helper tools|Practise using `OPERATOR_HELPER`, `SESSION_LOGGER` and `MANIFEST_KEEPER` to get unstuck, debug drift and maintain state.|
|19–20|Scaling preparation|Repeat the first real path and revenue flow with a different offer; practise scaling by opening additional specialists only after the control plane is locked and logging is active【784665054432985†L1475-L1499】.|
|21–22|iOS simulation|Perform the setup from an iOS device using the iOS tap‑by‑tap operator card; confirm that iOS is used only for consumption and validation.|
|23–24|End‑to‑end run|Execute a full session from initiation to session close‑out; ensure logs and manifest are complete and the tomorrow setup note is filled.|
|25–26|Peer review|Have another operator review your session logs and manifest; compare interpretations of bottlenecks and next steps.|
|27–28|Refresher|Review the initial runbook again to note any nuances missed earlier; update personal notes or cheat sheets accordingly.|
|29–30|Retrospective|Write a brief retrospective: What worked well in following the initial path?  Where did you encounter ambiguity?  Plan improvements for the next 30‑day cycle.

---

## 01_CONTROL_PLANE_RUNBOOK.md – 30‑Day Simulation

This runbook defines the control plane’s authority, hop models, role types, hard rules and stop conditions【784665054432985†L1478-L1516】.  The simulation focuses on mastering routing discipline.

| Days | Focus | Simulation tasks |
|---|---|---|
|1–2|Study core rules|Read the runbook thoroughly: understand that only `SYSTEM_OS_MASTER` can route【784665054432985†L1482-L1490】, learn the canonical and extended hop definitions【784665054432985†L1485-L1490】, review role types and hard rules【784665054432985†L1492-L1508】.|
|3–4|Canonical hop practice|Simulate simple canonical hops with different specialists.  After each hop, update the session log and manifest; ensure no raw output goes directly to the router and that every hop is logged【784665054432985†L1500-L1508】.|
|5–6|Extended hop practice|Introduce a reviewer between the specialist and router; simulate handoff review and confirm that the reviewer does not act as a router.|
|7–8|Stop conditions|Deliberately trigger stop conditions (e.g., multiple NEXT_GPT suggestions, specialist returning an unusable artifact, reviewer attempting to author)【784665054432985†L1510-L1515】 and practise pausing and correcting before proceeding.|
|9–10|Role discipline|Rotate through revenue, prompt ops, product and delivery specialists; verify that each respects their role boundaries and that only `SYSTEM_OS_MASTER` routes.|
|11–12|Hard rule audit|Review past sessions for violations of the seven hard rules (no specialist routing, no reviewer routing, etc.)【784665054432985†L1499-L1508】; document any issues and create prevention strategies.|
|13–14|Re-entry template|Practise using the canonical re‑entry template to hand off normalized artifacts back to `SYSTEM_OS_MASTER`【784665054432985†L1517-L1518】.|
|15–16|Drift spotting|Use the common failure modes document to identify route, schema, wording or flow order drift; practise correcting only the failing layer.|
|17–18|End‑to‑end simulation|Run a multi‑lane session (e.g., revenue followed by product build) while maintaining control plane discipline; ensure each hop returns to the router and no gating is skipped.|
|19–20|Peer review & feedback|Exchange session logs with another operator; critique each other’s adherence to the control plane rules and suggest improvements.|
|21–22|Integration with auditing|Practise using audit roles (e.g., `LIBRARY_GUIDE`, `BACKBONE_TESTER`) to navigate documentation and test determinism; confirm control plane rules still hold under audit.|
|23–24|Edge cases|Test edge cases such as repeated re‑entry prompts or ambiguous bottlenecks; see how the control plane resolves them.|
|25–26|Documentation updates|Update your personal checklists or cheat sheets based on insights; consider augmenting runbook notes to clarify tricky points.|
|27–28|Mock training session|Lead a mock training session teaching another operator about the control plane; answering questions reinforces your own understanding.|
|29–30|Final assessment|Conduct a final simulation involving all role types and reviewers; evaluate whether you followed all hard rules and stop conditions without prompting.  Document lessons learned.

---

## 02_STACK_DETERMINISM_RUNBOOK.md – 30‑Day Simulation

This runbook verifies that the backbone is deterministic across routing, re‑entry and multi‑hop flows【784665054432985†L1530-L1544】.  The simulation emphasises running the specified tests, interpreting pass/fail criteria and repairing drift【784665054432985†L1547-L1558】.

| Days | Focus | Simulation tasks |
|---|---|---|
|1–2|Understanding determinism|Read the purpose and test order: `TEST_01`, `TEST_02`, `TEST_03`【784665054432985†L1535-L1539】; comprehend what PASS and FAIL mean in terms of NEXT_GPT, handoff shape and bottleneck consistency【784665054432985†L1540-L1545】.|
|3–4|Test 01 – Router same input|Run `TEST_01` using a simple prompt ten times; verify that the router returns the same NEXT_GPT each time.  Capture raw inputs and outputs and note any route drift.|
|5–6|Repair after drift|If you observe drift (route, schema, wording or bottleneck drift)【784665054432985†L1547-L1552】, follow the repair protocol: identify the dominant drift type, fix only the failing layer and repeat the test until you achieve PASS【784665054432985†L1555-L1558】.|
|7–8|Test 02 – Router re‑entry determinism|Run `TEST_02` ten times; ensure that re‑entering the router with the same input produces identical handoff shapes and bottlenecks.|
|9–10|Test 03 – 3‑hop flow|Execute `TEST_03` (router → specialist → dev layer → router → specialist → dev layer → router) and assess whether the flow remains deterministic across three hops.  Log each hop and update the manifest.|
|11–12|Analyze results|Compile the verdicts and drift types across all three tests.  Determine whether the backbone passes or if slice integrity issues remain.|
|13–14|Drift vocabulary|Review the drift vocabulary (route, schema, narrowing, wording, format, handoff failure, boundary violation, operator confusion, outcome failure)【784665054432985†L1956-L1971】 and practise recognising each type in test outputs.|
|15–16|Slice tests|Extend determinism tests to revenue, prompt ops and product slices using the master test plan; see whether determinism holds within each lane.|
|17–18|Operator tests|Conduct junior and senior operator tests (from the master test plan) to observe how operator behaviour affects determinism; evaluate the impact of mis‑routing or logging errors.|
|19–20|Live lane tests|Run live tests for revenue, prompt and product lanes; confirm that at least one live lane is usable to achieve global PASS【937679800961216†L2257-L2262】.|
|21–22|Evidence compilation|Gather raw inputs, outputs, verdicts, drift types and blockers from all determinism tests; organise them in a summary file for audit【937679800961216†L2269-L2275】.|
|23–24|Failure recovery drill|Induce a known drift (e.g., wording drift) and practise the repair protocol until PASS; document the steps for future reference.|
|25–26|Cross‑lane determinism|Test a sequence of different specialists (revenue → prompt → product) to verify that determinism holds when switching lanes.|
|27–28|Peer review|Share your test results with another operator; compare interpretations of drift and PASS/FAIL criteria.|
|29–30|Final report|Write a determinism report summarising findings and recommending improvements; include suggestions for reducing common drifts in live operations.

---

## 03_REVENUE_DISCOVERY_RUNBOOK.md – 30‑Day Simulation

This runbook guides the operator from offer context to market snapshot and ICP card【784665054432985†L1573-L1605】.  The checklist will help you refine discovery skills and avoid broad targeting【784665054432985†L1612-L1615】.

| Days | Focus | Simulation tasks |
|---|---|---|
|1–2|Purpose & entry criteria|Understand the purpose (market snapshot, primary ICP, narrow ICP card)【784665054432985†L1573-L1605】; verify entry criteria (control plane locked, session logging active, backbone tests pass, offer context exists)【784665054432985†L1579-L1584】.|
|3–4|Flow basics|Practise the flow: router → `MARKET_SCOUT_OUTBOUND` → dev layer → router → `STRUCTURAL_ENGINE` → dev layer → router【784665054432985†L1585-L1593】.|
|5–6|Market snapshot|Use `MARKET_SCOUT_OUTBOUND` to research the target market; document user goal, target market, time horizon and current bottleneck as inputs【784665054432985†L1594-L1601】.|
|7–8|ICP card creation|With the market snapshot, work with `STRUCTURAL_ENGINE` to produce an initial ICP card.  Record backup hypotheses that emerge.|
|9–10|Exit criteria check|Ensure you have one primary ICP, preserved backup hypotheses and a usable narrow ICP card with a clear next bottleneck【784665054432985†L1606-L1611】.|
|11–12|Stop conditions|Explore what happens when the market remains broad or the ICP card cannot be tested outbound【784665054432985†L1612-L1615】; practise stopping and refining the research.|
|13–14|Iterative discovery|Repeat the discovery flow with a different offer context; compare differences in market snapshot and ICP outputs.|
|15–16|Audience segmentation|Practise segmenting the ICP by geo, channel or behavioural signals; refine the scope for future shortlist generation.|
|17–18|Collaboration|Collaborate with a marketing specialist to validate the ICP and gather additional insights.  Use the dev layer to store raw outputs.|
|19–20|Report writing|Draft a revenue discovery report summarising findings, primary ICP, backup hypotheses and next bottleneck.|
|21–22|Integration with downstream runbooks|Feed the ICP card into the ICP‑to‑shortlist runbook; observe how discovery affects list building.|
|23–24|Edge cases|Test scenarios where the offer context is vague or broad; practise narrowing it before running discovery.|
|25–26|Mock live session|Run a mock live revenue session starting with discovery; use live operator runbook templates to log each step and decision.|
|27–28|Peer review & feedback|Have another operator review your market snapshot and ICP card; discuss any over‑generalisation or missing detail.|
|29–30|Retrospective|Summarise what techniques yielded the most accurate ICP; document improvements for future discovery sessions.

---

## 04_ICP_TO_SHORTLIST_RUNBOOK.md – 30‑Day Simulation

This runbook converts the ICP card into actionable shortlist logic and public‑data sourcing【784665054432985†L1621-L1643】.  The plan emphasises building reproducible lists with clear filters and exclusions【784665054432985†L1644-L1648】.

| Days | Focus | Simulation tasks |
|---|---|---|
|1–2|Entry criteria & purpose|Ensure a valid ICP card is available and geo/channel scopes are known【784665054432985†L1626-L1629】.  Understand that the goal is to create source maps, filters, exclusions and tiering【784665054432985†L1636-L1643】.|
|3–4|Flow practice|Follow the flow: router → `LIST_BUILDER` → dev layer → router【784665054432985†L1630-L1634】.  Start a basic shortlist using data from the ICP card.|
|5–6|Source map creation|Identify key data sources (public databases, directories, open web) and map them to your ICP; document constraints and channel preferences.|
|7–8|Filters & exclusions|Define filters (industry, size, geography) and explicit exclusions.  Ensure that account‑ready vs email‑ready logic is clear【784665054432985†L1641-L1643】.|
|9–10|Tiering & tracker logic|Assign tiers (e.g., Tier 1 high priority, Tier 2 long‑tail) and set up simple tracker logic to monitor progress.|
|11–12|Exit criteria check|Verify that shortlist logic is reproducible, public‑data sourcing is clear, target volume is defined and the next bottleneck is known【784665054432985†L1644-L1648】.|
|13–14|Stop conditions|Test boundary conditions: if source logic violates constraints or exclusions are unclear【784665054432985†L1650-L1653】, stop and refine before proceeding.|
|15–16|Iterative refinement|Create a second shortlist with stricter filters or different sources; compare yield quality and coverage.|
|17–18|Collaborate with sales|Share the shortlist with sales or outreach specialists; gather feedback on relevance and adjust logic accordingly.|
|19–20|Integration with positioning|Pass the shortlist to the positioning and claims runbook; observe how shortlist quality affects positioning decisions.|
|21–22|Automation drill|Practise automating parts of the shortlist logic (e.g., scripts to scrape public data); ensure results still meet reproducibility standards.|
|23–24|Edge case handling|Work with a niche ICP where public data is scarce; experiment with creative sourcing while maintaining compliance.|
|25–26|Quality assurance|Use internal or external tools to verify the accuracy of data points in your shortlist; update filters as needed.|
|27–28|Documentation|Write a shortlist logic document capturing sources, filters, exclusions, tiering and tracker logic; store it in the dev layer.|
|29–30|Retrospective & handoff|Review what produced the most qualified shortlist; hand off the logic and the resulting list to positioning for the next phase.  Note improvements for future ICP conversions.

---

## 05_POSITIONING_AND_CLAIMS_RUNBOOK.md – 30‑Day Simulation

This runbook locks the offering’s positioning, call‑to‑action (CTA) discipline and claims safety【784665054432985†L1661-L1682】.  The plan below helps you refine messaging and evidence.

| Days | Focus | Simulation tasks |
|---|---|---|
|1–2|Entry criteria & purpose|Confirm that an ICP and shortlist logic exist and that the current offer framing is available【784665054432985†L1664-L1668】.  Understand the goal of performing a positioning audit and claims review【784665054432985†L1669-L1674】.|
|3–4|Flow practice|Follow the flow: router → `POSITIONING_POLICE` → `CLAIMS_EVIDENCE_REVIEWER` → dev layer → router【784665054432985†L1669-L1674】.  Conduct a basic positioning audit on the offer.|
|5–6|Positioning audit|Define a clear positioning line (problem → solution → outcome) and examine vocabulary rules; ensure no vagueness or broad transformation promises【784665054432985†L1684-L1688】.|
|7–8|CTA discipline|Lock a single call‑to‑action; remove competing CTAs or ambiguous asks.  Ensure CTA aligns with the ICP’s context.|
|9–10|Claims evidence review|Work with `CLAIMS_EVIDENCE_REVIEWER` to determine the strongest allowed claim and identify forbidden claims【784665054432985†L1676-L1682】.  Verify that each claim is supported by proof.|
|11–12|Exit criteria check|Ensure there is one clear positioning line, one CTA only, no invented proof and no broad transformation promise【784665054432985†L1683-L1688】.|
|13–14|Stop conditions|Test scenarios with multiple CTA paths, unsupported claims or scope drift【784665054432985†L1689-L1693】; practise stopping and revising before sending assets forward.|
|15–16|Messaging variations|Develop alternate positioning lines or CTAs for A/B testing; document the rationale behind each.|
|17–18|Proof gathering|Collect testimonials, case studies or data points to strengthen claims; add them to the dev layer for future reference.|
|19–20|Cross‑functional review|Share the positioning and claims with legal or compliance teams to ensure regulatory safety.|
|21–22|Integration with asset generation|Prepare the approved positioning and claims for the asset generation runbook; note how messaging discipline informs copywriting.|
|23–24|Edge case audit|Audit messaging for niches or international markets; ensure claims remain compliant across jurisdictions.|
|25–26|Logging & manifest|Ensure all positioning iterations, CTA locks and claims decisions are logged and included in the session manifest.|
|27–28|Peer teaching|Conduct a training session with another operator to explain claims safety and CTA discipline; field questions.|
|29–30|Retrospective|Summarise which positioning and claim practices were most effective; refine internal guidelines accordingly.

---

## 06_ASSET_GENERATION_RUNBOOK.md – 30‑Day Simulation

This runbook focuses on producing a claims‑safe outbound asset pack, including opener, follow‑up and DM messages【784665054432985†L1701-L1721】.  The checklist emphasises copy readiness and alignment with locked positioning.

| Days | Focus | Simulation tasks |
|---|---|---|
|1–2|Entry criteria & purpose|Confirm that positioning and CTA are locked, claims policy is clear and ICP/offer are defined【784665054432985†L1704-L1708】.  Review the purpose of generating an outbound asset pack.|
|3–4|Flow practice|Follow the flow: router → `ASSET_ENGINE` → `CLAIMS_EVIDENCE_REVIEWER` → dev layer → router【784665054432985†L1710-L1716】.  Produce a basic opener and submit it for claims review.|
|5–6|Opener crafting|Refine the opener to ensure it is concise, relevant to the ICP and contains no invented proof or fake familiarity【784665054432985†L1722-L1727】.|
|7–8|Follow‑up drafting|Develop a follow‑up message that reinforces the opener without introducing new claims.  Keep the CTA consistent.|
|9–10|DM creation|Write a direct‑message version of the outreach; ensure tone and content remain claims‑safe.|
|11–12|Claims review iteration|Submit all messages to `CLAIMS_EVIDENCE_REVIEWER`; iterate until all assets are copy‑ready and only one CTA is present【784665054432985†L1722-L1725】.|
|13–14|Stop conditions|Check for guarantee language, fake personalization, multiple competing CTAs or unresolved evidence risk【784665054432985†L1729-L1733】; practise pausing and correcting.|
|15–16|Stylistic variations|Experiment with tone (formal vs. conversational) or length; ensure variations still meet exit criteria.|
|17–18|A/B testing plan|Design an A/B test plan for the assets; log hypotheses and expected outcomes.|
|19–20|Asset documentation|Compile the final assets with metadata (version, date, proof references) and store them in the dev layer.|
|21–22|Integration with launch safety|Pass the asset pack to the launch safety runbook; observe how asset quality affects send readiness.|
|23–24|Edge case messaging|Craft assets for special segments (cold leads vs. warm intros); verify claims safety remains intact.|
|25–26|Peer review|Ask another operator or copywriter to critique clarity, tone and evidence in the assets.|
|27–28|Logging & manifest|Ensure each asset iteration is logged; update the manifest with final assets and release verdict.|
|29–30|Retrospective|Reflect on which writing techniques produced the highest‑quality assets; note guidelines for future campaigns.

---

## 07_LAUNCH_SAFETY_RUNBOOK.md – 30‑Day Simulation

This runbook decides whether an outbound batch is safe to send by assessing deliverability and gating【784665054432985†L1741-L1766】.  The simulation helps operators practice risk management and release decisions.

| Days | Focus | Simulation tasks |
|---|---|---|
|1–2|Entry criteria & purpose|Confirm that the asset pack exists, shortlist logic is in place and sending setup is known【784665054432985†L1744-L1748】.  Review the purpose of determining batch safety.|
|3–4|Flow practice|Follow the flow: router → `DELIVERABILITY_GUARD` → `RELEASE_GATE_REVIEWER` → dev layer → router【784665054432985†L1749-L1754】.  Conduct a basic deliverability review.|
|5–6|Deliverability review|Analyse sending domains, DNS records and sender reputation; compile a deliverability report【784665054432985†L1756-L1760】.|
|7–8|Release gate decision|Work with `RELEASE_GATE_REVIEWER` to determine whether the batch is safe; document blockers and the fix order【784665054432985†L1756-L1761】.|
|9–10|Exit criteria check|Ensure DNS baseline is understood, ramp logic exists, stop rules exist and the release verdict is explicit【784665054432985†L1762-L1766】.|
|11–12|Stop conditions|Test scenarios where no release verdict, no stop rules or unresolved blockers occur【784665054432985†L1768-L1772】; practise halting the batch until issues are fixed.|
|13–14|Ramp logic design|Design a simple ramp‑up strategy for sending (e.g., 20% volume on day 1); document thresholds for scaling.|
|15–16|Send simulation|Simulate sending a small portion of the batch under monitored conditions; observe deliverability metrics and update the manifest.|
|17–18|Feedback loop|After the send simulation, adjust sending parameters based on observed issues (e.g., bounce rate); refine deliverability guard settings.|
|19–20|Coordination with post‑batch|Prepare to hand off data to the post‑batch decision runbook; ensure metrics such as replies and bookings are tracked accurately.|
|21–22|Edge case review|Analyse special cases such as new domains or international sending; adjust DNS baseline and ramp logic accordingly.|
|23–24|Documentation|Compile a launch safety report summarising deliverability review, release verdict, blockers and fixes; store it in the dev layer.|
|25–26|Peer review & legal check|Have the deliverability and release decision reviewed by another operator and, if needed, legal/compliance.|
|27–28|Live drill|Conduct a live safety drill with a small, real audience; evaluate whether stop rules and ramp logic function correctly.|
|29–30|Retrospective|Summarise what factors most affected batch safety; update internal guidelines for deliverability checks and release gate decisions.

---

## 08_POST_BATCH_DECISION_RUNBOOK.md – 30‑Day Simulation

This runbook handles decisions after a batch has been sent, using performance metrics to decide whether to scale, optimise or kill the campaign【784665054432985†L1780-L1812】.

| Days | Focus | Simulation tasks |
|---|---|---|
|1–2|Purpose & entry criteria|Understand the goal: make a hard decision (SCALE/OPTIMIZE/KILL) based on data【784665054432985†L1780-L1812】.  Confirm that a batch was sent and basic metrics exist (sent, replies, booked, closed, revenue, etc.)【784665054432985†L1783-L1800】.|
|3–4|Flow practice|Follow the flow: router → `PERFORMANCE_MEMORY`【784665054432985†L1787-L1790】.  Input mock metrics to generate a first verdict.|
|5–6|Metric analysis|Learn how to interpret reply rates, booking rates and revenue; practise calculating conversion and ROI.|
|7–8|Verdict generation|Use the outputs (SCALE, OPTIMIZE, KILL, top lessons, next action)【784665054432985†L1802-L1807】 to decide a course of action.  Document reasoning.|
|9–10|Exit criteria check|Ensure there is one hard verdict, one next action and that top changes are prioritised【784665054432985†L1809-L1813】.|
|11–12|Stop conditions|Explore cases where data is incomplete or verdicts are vague【784665054432985†L1814-L1817】; practise withholding decisions until data quality improves.|
|13–14|Optimisation planning|For OPTIMIZE decisions, outline specific improvements (e.g., adjust positioning, refine shortlist) and prepare tasks for relevant runbooks.|
|15–16|Scaling strategy|For SCALE decisions, design a controlled ramp‑up plan; document new target volumes and deliverability considerations.|
|17–18|Kill & learn|For KILL decisions, summarise why the campaign is being stopped and extract lessons for future offers; communicate the decision to stakeholders.|
|19–20|Data integrity|Verify that metrics collected are accurate and free of noise; ensure that objections or anomalies are noted for analysis.|
|21–22|Cross‑runbook integration|Feed the decision and next action into the appropriate runbook (e.g., optimisation leads to asset regeneration or positioning changes).|
|23–24|Edge case simulation|Simulate scenarios like extreme positive/negative response rates and practise adjusting verdict thresholds accordingly.|
|25–26|Documentation & logging|Compile a post‑batch decision report with metrics, verdict, lessons and next actions; update the manifest accordingly.|
|27–28|Peer review|Discuss the decision and reasoning with another operator; ensure alignment on verdict criteria.|
|29–30|Retrospective|Reflect on which metrics most strongly influenced decisions; update internal thresholds and practices for future batches.

---

## 09_PROMPT_OPS_RUNBOOK.md – 30‑Day Simulation

This runbook manages the prompt‑ops lane from drafting to exporting prompts【784665054432985†L1825-L1844】.  The simulation plan strengthens prompt writing, QA and export discipline.

| Days | Focus | Simulation tasks |
|---|---|---|
|1–2|Purpose & flow|Read the purpose and flow of the prompt‑ops lane【784665054432985†L1825-L1839】.  Understand the sequence of `PROMPT_AUTHOR`, `PROMPT_QA_CRITIC`, `PROMPT_PACK_EXPORTER` and `RELEASE_GATE_REVIEWER`.|
|3–4|Drafting|Create a prompt draft aligned with a defined user goal and context; store raw draft in the dev layer.|
|5–6|QA review|Pass the draft to `PROMPT_QA_CRITIC`; ensure that QA critiques rather than rewrites【784665054432985†L1846-L1849】.  Iterate based on feedback.|
|7–8|Export preparation|Use `PROMPT_PACK_EXPORTER` to package the prompt with metadata and versioning; verify that the bundle is usable and complete.|
|9–10|Release verdict|Send the export bundle to `RELEASE_GATE_REVIEWER` for a verdict (READY, READY_WITH_MINOR_FIXES or FAIL)【784665054432985†L1837-L1844】; note any blockers.|
|11–12|Stop conditions|Practise pausing when QA starts authoring, the export bundle is unusable or no release verdict is given【784665054432985†L1846-L1849】.|
|13–14|Version control|Experiment with multiple versions of the same prompt; document differences and maintain clear version history in the dev layer.|
|15–16|QA rubric|Develop a QA rubric outlining what constitutes a strong prompt (clarity, completeness, safety); use it consistently.|
|17–18|Export automation|Automate parts of the export process (e.g., generating bundle metadata); ensure automation doesn’t compromise completeness.|
|19–20|Integration with other lanes|Test how prompts used in revenue flows or product builds behave; adjust prompts based on downstream feedback.|
|21–22|Edge case drafting|Write prompts for extreme scenarios (e.g., very narrow or very broad goals); ensure QA and export processes hold.|
|23–24|Release gate calibration|Collaborate with release gate reviewers to calibrate verdict standards; align on what constitutes a “ready” prompt.|
|25–26|Documentation|Compile a prompt ops report summarising drafts, QA notes, export bundles and release verdicts; store in manifest.|
|27–28|Peer review|Have another operator review your prompt and QA processes; share best practices.|
|29–30|Retrospective|Analyse which prompts performed best in downstream tasks; refine drafting and QA guidelines accordingly.

---

## 10_PRODUCT_BUILD_RUNBOOK.md – 30‑Day Simulation

This runbook guides product/build lane activities from feature pack through execution plan【784665054432985†L1855-L1885】.  The simulation emphasises coordination among multiple specialists and release gating.

| Days | Focus | Simulation tasks |
|---|---|---|
|1–2|Purpose & flow|Review the purpose and flow: `SAAS_FEATURE_PACK_ENGINE`, `Architecture Copilot`, `Staff Engineer OS`, `Founder OS`, `RELEASE_GATE_REVIEWER`【784665054432985†L1856-L1874】.|
|3–4|Feature pack creation|Work with `SAAS_FEATURE_PACK_ENGINE` to define a feature pack (feature description, user stories, scope).  Store raw output in the dev layer.|
|5–6|Architecture recommendation|Use `Architecture Copilot` to design an architecture; focus on modularity, scalability and integration.  Record recommendations.|
|7–8|Engineering review|Have `Staff Engineer OS` perform an engineering review; identify complexity, risks and priorities.|
|9–10|Founder decision|Present the feature pack, architecture and engineering review to `Founder OS`; capture decisions and modifications.|
|11–12|Release verdict|Submit the execution plan to `RELEASE_GATE_REVIEWER` for approval【784665054432985†L1875-L1881】; record verdict and blockers.|
|13–14|Stop conditions|Ensure outputs are concrete, execution plan is usable and a release verdict exists; practise stopping and iterating when outputs are too abstract or plans unusable【784665054432985†L1882-L1885】.|
|15–16|Collaborative iteration|Run a second feature build cycle, incorporating feedback from the first; refine architecture and engineering considerations.|
|17–18|User feedback incorporation|Simulate collecting early user feedback on the feature concept; adjust the feature pack accordingly.|
|19–20|Dependency mapping|Identify dependencies with other teams or systems; update the execution plan to include integration tasks.|
|21–22|Documentation|Compile a product build dossier including feature pack, architecture recommendation, engineering review, execution plan and release verdict; store it in the manifest.|
|23–24|Integration with prompt ops|Design prompts that support the new feature (e.g., training prompts for AI components) and ensure they pass the prompt ops runbook.|
|25–26|Live planning session|Conduct a simulated live planning session with all specialists to finalise priorities and schedule.|
|27–28|Peer review & critique|Have another operator or engineering lead review your product build outputs; discuss improvements.|
|29–30|Retrospective|Summarise key lessons from building a feature end to end; refine guidelines for feature ideation, architecture and execution planning.

---

## 11_DELIVERY_AND_RETENTION_RUNBOOK.md – 30‑Day Simulation

This runbook addresses post‑sales operations: building delivery SOPs, retention logic and ops automation【784665054432985†L1893-L1915】.

| Days | Focus | Simulation tasks |
|---|---|---|
|1–2|Purpose & flow|Review the purpose and flow: router → `DELIVERY_SOP_ENGINE` → dev layer → router → `RETENTION_ENGINE` → dev layer → router → `OPS_AUTOMATOR` → dev layer【784665054432985†L1893-L1905】.|
|3–4|Delivery SOP|Use `DELIVERY_SOP_ENGINE` to draft a delivery SOP covering onboarding, implementation and handoff; ensure clarity and completeness.|
|5–6|Retention logic|Create a retention logic document: identify signals for churn risk, triggers for upsell and actions to maintain engagement【784665054432985†L1907-L1910】.|
|7–8|Ops automation spec|Define automation steps for recurring tasks (billing, reminders, check‑ins); ensure the spec aligns with real workflows【784665054432985†L1907-L1915】.|
|9–10|Stop conditions|Practise stopping when the SOP is unusable, retention logic is vague or the automation spec is disconnected from real workflows【784665054432985†L1912-L1915】; iterate until issues are fixed.|
|11–12|Integration with service team|Share the SOP and retention logic with support or customer success teams; gather feedback and refine.|
|13–14|Automation tooling|Identify tools or scripts needed to implement your ops automation spec; draft an implementation plan.|
|15–16|Monitoring & metrics|Define KPIs to monitor retention (e.g., churn rate, NPS) and set up simple dashboards.|
|17–18|Testing & pilot|Run a pilot of the delivery SOP and retention program with a small customer cohort; collect feedback and adjust.|
|19–20|Cross‑runbook integration|Coordinate with product build or revenue teams when retention insights indicate feature improvements or upsell opportunities.|
|21–22|Edge case handling|Design retention strategies for special segments (e.g., high‑value customers vs. free‑trial users); ensure ops automation accommodates differences.|
|23–24|Documentation|Compile a delivery & retention playbook summarising SOP steps, retention logic, automation spec and lessons learned; store in dev layer.|
|25–26|Peer review|Have a peer or manager review your playbook; incorporate suggestions.|
|27–28|Scaling plan|Plan how to scale the delivery & retention program across more customers; document necessary resources and adjustments.|
|29–30|Retrospective|Summarise which retention tactics and automation steps had the biggest impact; refine guidelines for future programs.

---

## 12_SESSION_LOGGING_AND_ARTIFACT_REGISTRY_RUNBOOK.md – 30‑Day Simulation

This runbook ensures disciplined session logging and artifact registry management, specifying required entities, formats and what each hop must record【784665054432985†L1924-L1950】.  The plan emphasises auditability and reproducibility.

| Days | Focus | Simulation tasks |
|---|---|---|
|1–2|Purpose & requirements|Review required entities (`SESSION_ID`, `RUN_ID`, `STEP_ID`, `artifact_id`, etc.) and formats (session ID and timestamp formats)【784665054432985†L1924-L1943】.|
|3–4|Logging basics|Practise logging raw input, raw output, normalized artifact, re‑entry prompt and verdict for a simple hop【784665054432985†L1944-L1949】.|
|5–6|Raw vs normalized|Understand the difference between raw outputs and normalized artifacts【784665054432985†L1951-L1954】; practise transforming raw output into a normalized artifact without altering meaning.|
|7–8|Verdict & drift vocabulary|Learn the verdict vocabulary (`PASS`, `PASS_WITH_MINOR_FIXES`, `FAIL`) and drift vocabulary (`route_drift`, `schema_drift`, etc.)【784665054432985†L1956-L1971】; log verdicts and drift types accurately.|
|9–10|Template enforcement|Create a logging template that enforces required fields and formats; use it for all subsequent simulations.|
|11–12|Registry maintenance|Practise maintaining an artifact registry: update artifact IDs, types and timestamps consistently.  Ensure you can trace any artifact back to its source session.|
|13–14|Audit rehearsal|Conduct a self‑audit: verify that logs contain all required fields and that raw and normalized artifacts match.  Correct any gaps.|
|15–16|Integration with other runbooks|Ensure that outputs from revenue, prompt ops and product simulations are logged correctly; verify cross‑runbook consistency.|
|17–18|Error injection|Intentionally omit or mis‑label fields in a log entry; practise detecting and correcting these errors.|
|19–20|Automation tooling|Explore scripting or tools to automate log capturing and registry updates; ensure automation does not compromise accuracy.|
|21–22|Peer audit|Swap logs and registry entries with another operator; evaluate each other’s discipline and provide feedback.|
|23–24|Historical replay|Use your logs and registry to replay a past session; verify that the sequence of hops and artifacts is reproducible.|
|25–26|Edge case handling|Handle unusual artifact types (e.g., image outputs) or complex sessions with many steps; ensure logging still captures all required data.|
|27–28|Documentation|Compile a session logging and registry manual summarising lessons, best practices and common pitfalls; store it in the dev layer.|
|29–30|Retrospective|Reflect on which logging practices improved auditability and which errors were most common; refine your template and guidelines accordingly.
