# Revenue Simulation – New ICP Sales: v3 Scenario Pack

This v3 pack extends the v2 scenario pack by adding more explicit operational details for each of the six runs in the **“Governed GPT Workflow Audit”** motion targeting **Heads of RevOps / Revenue Operations leaders** in B2B SaaS.  For each scenario it defines:

- **Exact specialist invocation block** – the prompt details sent to the specialist.
- **Expected `STACK_DEV_LAYER` save block** – the fields logged when the raw artifact is saved.
- **Expected routed summary skeleton** – the structure of the summary returned by the router.
- **PASS / BLOCKED / STOP examples** – examples of final status outcomes with defect types and minimum fixes.

Global rules ensure artifact naming, re‑entry discipline and separation between raw artifacts and routed summaries.

---

## Global v3 Rules

- **Artifact naming:** `[scenario]__[stage]__[role]__[run_id]__[version]`
- **Re‑entry rule:** No step is complete until `STACK_DEV_LAYER` returns `ROUTER RE-ENTRY READY: YES`.
- **Routed summary rule:** Routed summary must never be a raw artifact.  It should be a concise operator‑usable audit summary for the next decision.

---

## 1. Discovery

### Exact specialist invocation block – MARKET_SCOUT_OUTBOUND

```
You are invoked by SYSTEM_OS_MASTER.

SCENARIO
DISCOVERY

STAGE
market_scan

OBJECTIVE
Identify the shortest credible commercial wedge for Governed GPT Workflow Audit aimed at Head of RevOps / Revenue Operations leaders in B2B SaaS.

INPUTS
- offer_name: Governed GPT Workflow Audit
- target_market: B2B SaaS
- target_buyer: Head of RevOps / Revenue Operations leader
- business_problem: GPT usage exists, but workflow truth, approvals, evidence, and production discipline are fragmented
- commercial_goal: identify the shortest credible wedge for first outreach
- primary_cta: Book a 20-min diagnostic call
- available_context:
  - worker-backed governed system exists
  - founder console exists
  - evidence / closure / state discipline is core differentiator
  - no fake enterprise scale claims allowed

HARD CONSTRAINTS
- no guarantee language
- no invented market proof
- no unsupported customer logos or references
- must keep scope narrow to fastest cashflow wedge
- do not broaden into full AI transformation offer

REQUIRED OUTPUT
Return raw specialist output only for STACK_DEV_LAYER.

MANDATORY RAW ARTIFACT FIELDS
- ARTIFACT NAME
- SCENARIO
- STAGE
- MARKET HYPOTHESIS
- BUYING SIGNALS
- PAIN PATTERNS
- EXCLUSION SIGNALS
- CANDIDATE ANGLES
- RISKS
- RAW ARTIFACT

MANDATORY ENDING
- RAW ARTIFACT
- ASSUMPTIONS USED
- MISSING INPUTS
- KNOWN LIMITS
```

### Expected `STACK_DEV_LAYER` save block

```
ARTIFACT SAVED
YES

ARTIFACT NAME
DISCOVERY__market_scan__MARKET_SCOUT_OUTBOUND__RUN_NEW_ICP_2026_03_29_DISCOVERY_01__v1

SOURCE ROLE
MARKET_SCOUT_OUTBOUND

SAVE STATUS
saved

ISSUES FLAGGED
- none
- or: ICP breadth risk
- or: insufficient market proof specificity

ROUTER RE-ENTRY READY
YES
```

### Expected routed summary skeleton

```
STAGE
DISCOVERY

ENTRY CHECK
READY

ROUTER DECISION
DISCOVERY step is valid and specialist artifact has been saved through STACK_DEV_LAYER.

SELECTED SPECIALIST
MARKET_SCOUT_OUTBOUND

RAW OUTPUT SAVED TO STACK_DEV_LAYER
YES

ROUTED OUTPUT TO SYSTEM_OS_MASTER
- locked buyer problem:
- strongest buying signal:
- strongest pain pattern:
- excluded segments:
- selected commercial angle:
- major risk to next step:

EXIT CRITERIA CHECK
- buyer problem explicit: YES / NO
- usable pain pattern list exists: YES / NO
- buying signals bounded: YES / NO
- exclusions explicit: YES / NO
- one viable market angle selected: YES / NO

STOP CONDITIONS CHECK
- ICP too broad: YES / NO
- generic AI consulting drift: YES / NO
- invented proof: YES / NO
- no clear wedge: YES / NO

NEXT BOTTLENECK
-

FINAL STATUS
PASS / BLOCKED / STOP
```

### PASS / BLOCKED / STOP examples

**PASS**

```
FINAL STATUS
PASS

NEXT BOTTLENECK
Translate selected market angle into bounded ICP shortlist criteria.
```

**BLOCKED**

```
FINAL STATUS
BLOCKED
DEFECT TYPE
operator_confusion
BLOCKING REASON
Target buyer is too broad and combines multiple non-equivalent operating owners.
MINIMUM FIX REQUIRED
Lock one primary buyer title before shortlist generation.
```

**STOP**

```
FINAL STATUS
STOP
DEFECT TYPE
route_drift
BLOCKING REASON
Discovery output reframed the offer into a broad AI transformation program outside the scenario boundary.
MINIMUM FIX REQUIRED
Re-run discovery with audit-only wedge preserved.
```

---

## 2. ICP → Shortlist

### Exact specialist invocation block – LIST_BUILDER

```
You are invoked by SYSTEM_OS_MASTER.

SCENARIO
ICP → SHORTLIST

STAGE
candidate_list_build

OBJECTIVE
Build a bounded shortlist of 25 candidate accounts matching the locked ICP for Governed GPT Workflow Audit.

INPUTS
- locked_offer: Governed GPT Workflow Audit
- locked_market: B2B SaaS
- target_buyer_title_primary: Head of RevOps
- target_buyer_title_secondary: Revenue Operations leader
- target_company_profile:
  - B2B SaaS
  - 20–500 employees
  - GTM / ops complexity already visible
  - likely multiple manual handoffs
  - signs of AI experimentation without operating discipline
- inclusion_signals:
  - ops-heavy workflow ownership
  - revenue systems/process responsibility
  - signal / routing / process quality concerns
  - likely tooling sprawl
- exclusion_signals:
  - solo founders without ops complexity
  - agencies
  - companies without GTM operations function
  - companies clearly outside B2B SaaS
- desired_output_count: 25

HARD CONSTRAINTS
- no fake personal familiarity
- no speculative personalization beyond bounded evidence
- no broad market list without explicit inclusion/exclusion logic

REQUIRED OUTPUT
Return raw specialist output only for STACK_DEV_LAYER.

MANDATORY RAW ARTIFACT FIELDS
- ARTIFACT NAME
- SCENARIO
- STAGE
- LIST OBJECTIVE
- INCLUSION RULES
- EXCLUSION RULES
- SHORTLIST
- REJECTED CANDIDATES
- DATA QUALITY FLAGS
- RAW ARTIFACT

MANDATORY ENDING
- RAW ARTIFACT
- ASSUMPTIONS USED
- MISSING INPUTS
- KNOWN LIMITS
```

### Expected `STACK_DEV_LAYER` save block

```
ARTIFACT SAVED
YES

ARTIFACT NAME
ICP_SHORTLIST__candidate_list__LIST_BUILDER__RUN_NEW_ICP_2026_03_29_SHORTLIST_01__v1

SOURCE ROLE
LIST_BUILDER

SAVE STATUS
saved

ISSUES FLAGGED
- none
- or: weak title confidence
- or: insufficient evidence for shortlist inclusion
- or: shortlist too broad

ROUTER RE-ENTRY READY
YES
```

### Expected routed summary skeleton

```
STAGE
ICP → SHORTLIST

ENTRY CHECK
READY

ROUTER DECISION
Shortlist generation step is valid and saved.

SELECTED SPECIALIST
LIST_BUILDER

RAW OUTPUT SAVED TO STACK_DEV_LAYER
YES

ROUTED OUTPUT TO SYSTEM_OS_MASTER
- shortlist count:
- inclusion rule integrity:
- exclusion rule integrity:
- strongest shortlist pattern:
- weakest shortlist pattern:
- data quality flags:
- shortlist ready for positioning: YES / NO

EXIT CRITERIA CHECK
- shortlist exists: YES / NO
- inclusion logic explicit: YES / NO
- exclusion logic explicit: YES / NO
- data quality flags visible: YES / NO
- list narrow enough for outbound test: YES / NO

STOP CONDITIONS CHECK
- vague criteria: YES / NO
- title mixing drift: YES / NO
- no exclusion discipline: YES / NO
- shortlist unusable: YES / NO

NEXT BOTTLENECK
-

FINAL STATUS
PASS / BLOCKED / STOP
```

### PASS / BLOCKED / STOP examples

**PASS**

```
FINAL STATUS
PASS

NEXT BOTTLENECK
Lock positioning and claims policy for the shortlisted ICP.
```

**BLOCKED**

```
FINAL STATUS
BLOCKED
DEFECT TYPE
schema_drift
BLOCKING REASON
Shortlist was returned without explicit exclusion logic.
MINIMUM FIX REQUIRED
Rebuild shortlist with explicit rejected-candidate logic.
```

**STOP**

```
FINAL STATUS
STOP
DEFECT TYPE
narrowing_drift
BLOCKING REASON
Shortlist was narrowed to one subsegment without scenario or operator authorization.
MINIMUM FIX REQUIRED
Restore full authorized ICP scope or obtain explicit narrowing approval.
```

---

## 3. Positioning & Claims

### Exact specialist invocation block – POSITIONING_POLICE

```
You are invoked by SYSTEM_OS_MASTER.

SCENARIO
POSITIONING & CLAIMS

STAGE
message_policy_lock

OBJECTIVE
Create a claim-safe positioning and wording policy for Governed GPT Workflow Audit aimed at Head of RevOps / Revenue Operations leaders in B2B SaaS.

INPUTS
- locked_offer: Governed GPT Workflow Audit
- locked_icp: Head of RevOps / Revenue Operations leader in B2B SaaS
- core_problem:
  - GPT usage may exist, but state, approvals, evidence, and closure logic are not governed
- desired_outcome:
  - sharper, claim-safe positioning angle for outbound and diagnostic proposal
- allowed_proof_basis:
  - founder-built governed stack exists
  - worker-backed state/evidence/closure discipline exists
  - founder console + runtime truth pattern exists
- disallowed_claims:
  - no guarantee of revenue lift
  - no guaranteed production outcome
  - no fake compliance guarantees
  - no fully autonomous operations claim
- primary_cta: Book a 20-min diagnostic call

HARD CONSTRAINTS
- no guarantee language
- no inflated transformation claims
- no fake urgency
- must preserve narrow audit wedge

REQUIRED OUTPUT
Return raw specialist output only for STACK_DEV_LAYER.

MANDATORY RAW ARTIFACT FIELDS
- ARTIFACT NAME
- SCENARIO
- STAGE
- CORE POSITIONING
- CLAIM BOUNDARY
- DISALLOWED WORDING
- RECOMMENDED WORDING
- CTA OPTIONS
- MESSAGE RISKS
- RAW ARTIFACT

MANDATORY ENDING
- RAW ARTIFACT
- ASSUMPTIONS USED
- MISSING INPUTS
- KNOWN LIMITS
```

### Expected `STACK_DEV_LAYER` save block

```
ARTIFACT SAVED
YES

ARTIFACT NAME
POSITIONING_AND_CLAIMS__message_policy__POSITIONING_POLICE__RUN_NEW_ICP_2026_03_29_POSITIONING_01__v1

SOURCE ROLE
POSITIONING_POLICE

SAVE STATUS
saved

ISSUES FLAGGED
- none
- or: unsupported claim language
- or: CTA drift
- or: wording ambiguity

ROUTER RE-ENTRY READY
YES
```

### Expected routed summary skeleton

```
STAGE
POSITIONING & CLAIMS

ENTRY CHECK
READY

ROUTER DECISION
Primary positioning artifact has been saved and is ready for review.

SELECTED SPECIALIST
POSITIONING_POLICE

RAW OUTPUT SAVED TO STACK_DEV_LAYER
YES

ROUTED OUTPUT TO SYSTEM_OS_MASTER
- locked positioning:
- allowed claims:
- banned claims:
- CTA lock:
- main wording risk:
- review required: YES

EXIT CRITERIA CHECK
- core positioning explicit: YES / NO
- claim boundary explicit: YES / NO
- banned wording explicit: YES / NO
- CTA locked: YES / NO
- reviewer verdict READY / READY_WITH_FIXES: YES / NO

STOP CONDITIONS CHECK
- unsupported claims: YES / NO
- no claim boundary: YES / NO
- CTA drift: YES / NO
- reviewer FAIL: YES / NO

NEXT BOTTLENECK
-

FINAL STATUS
PASS / BLOCKED / STOP
```

### PASS / BLOCKED / STOP examples

**PASS**

```
FINAL STATUS
PASS

NEXT BOTTLENECK
Generate outbound asset variants against the locked message policy.
```

**BLOCKED**

```
FINAL STATUS
BLOCKED
DEFECT TYPE
wording_drift
BLOCKING REASON
Positioning artifact contains borderline transformation language that needs targeted claims review.
MINIMUM FIX REQUIRED
Run CLAIMS_EVIDENCE_REVIEWER and apply fix order.
```

**STOP**

```
FINAL STATUS
STOP
DEFECT TYPE
boundary_violation
BLOCKING REASON
Positioning artifact makes unsupported proof claims beyond the allowed evidence basis.
MINIMUM FIX REQUIRED
Remove unsupported claims and reissue message policy.
```

---

## 4. Asset Generation

### Exact specialist invocation block – ASSET_ENGINE

```
You are invoked by SYSTEM_OS_MASTER.

SCENARIO
ASSET GENERATION

STAGE
cold_email_generation

OBJECTIVE
Generate 3 bounded cold outbound email variants using the locked positioning and claims policy.

INPUTS
- locked_offer: Governed GPT Workflow Audit
- locked_icp: Head of RevOps / Revenue Operations leader in B2B SaaS
- locked_positioning:
  - move from fragmented GPT usage to governed operating discipline
  - audit-first, not transformation-first
- locked_claim_boundary:
  - audit / map / recommend
  - no performance guarantee
  - no implementation guarantee
- locked_cta: Book a 20-min diagnostic call
- asset_type: cold outbound email
- desired_variants: 3
- tone_of_voice:
  - credible
  - direct
  - non-hype
  - founder-led
- required_structure:
  - hook
  - pain articulation
  - audit wedge
  - CTA

HARD CONSTRAINTS
- single CTA only
- no fake familiarity
- no “quick question” fluff
- no overlong email
- no unapproved claims

REQUIRED OUTPUT
Return raw specialist output only for STACK_DEV_LAYER.

MANDATORY RAW ARTIFACT FIELDS
- ARTIFACT NAME
- SCENARIO
- STAGE
- ASSET TYPE
- LOCKED INPUTS USED
- RAW DRAFT
- CLAIM RISK FLAGS
- FORMAT CHECK NOTES
- RAW ARTIFACT

MANDATORY ENDING
- RAW ARTIFACT
- ASSUMPTIONS USED
- MISSING INPUTS
- KNOWN LIMITS
```

### Expected `STACK_DEV_LAYER` save block

```
ARTIFACT SAVED
YES

ARTIFACT NAME
ASSET_GENERATION__cold_email__ASSET_ENGINE__RUN_NEW_ICP_2026_03_29_ASSET_01__v1

SOURCE ROLE
ASSET_ENGINE

SAVE STATUS
saved

ISSUES FLAGGED
- none
- or: CTA duplication
- or: format drift
- or: claim risk flag

ROUTER RE-ENTRY READY
YES
```

### Expected routed summary skeleton

```
STAGE
ASSET GENERATION

ENTRY CHECK
READY

ROUTER DECISION
Asset generation artifact has been saved and is ready for review.

SELECTED SPECIALIST
ASSET_ENGINE

RAW OUTPUT SAVED TO STACK_DEV_LAYER
YES

ROUTED OUTPUT TO SYSTEM_OS_MASTER
- asset type:
- variant count:
- CTA preserved: YES / NO
- claim boundary preserved: YES / NO
- strongest variant:
- main format risk:
- reviewer required: YES

EXIT CRITERIA CHECK
- 3 usable variants exist: YES / NO
- CTA lock preserved: YES / NO
- claim boundary preserved: YES / NO
- reviewer verdict READY / READY_WITH_FIXES: YES / NO
- no wording drift: YES / NO

STOP CONDITIONS CHECK
- multiple CTA drift: YES / NO
- claim inflation: YES / NO
- positioning drift: YES / NO
- reviewer FAIL: YES / NO

NEXT BOTTLENECK
-

FINAL STATUS
PASS / BLOCKED / STOP
```

### PASS / BLOCKED / STOP examples

**PASS**

```
FINAL STATUS
PASS

NEXT BOTTLENECK
Run launch safety review on the selected outbound batch asset.
```

**BLOCKED**

```
FINAL STATUS
BLOCKED
DEFECT TYPE
format_drift
BLOCKING REASON
Generated variants exceed the approved outbound structure and require targeted trimming.
MINIMUM FIX REQUIRED
Regenerate with enforced hook / pain / audit wedge / CTA structure only.
```

**STOP**

```
FINAL STATUS
STOP
DEFECT TYPE
boundary_violation
BLOCKING REASON
Draft includes unapproved claims beyond audit / map / recommend boundary.
MINIMUM FIX REQUIRED
Remove unsupported promises and rerun generation from locked claim boundary.
```

---

## 5. Launch Safety

### Exact specialist invocation block – DELIVERABILITY_GUARD

```
You are invoked by SYSTEM_OS_MASTER.

SCENARIO
LAUNCH SAFETY

STAGE
batch_release_check

OBJECTIVE
Evaluate whether the approved outbound email may be launched as a single controlled batch.

INPUTS
- locked_asset:
  - outbound email selected from approved asset generation stage
- locked_icp: Head of RevOps / Revenue Operations leader in B2B SaaS
- batch_size: 25
- sending_surface: founder-led manual / low-volume outbound
- deliverability_assumption:
  - no mass cold infrastructure
  - cautious initial send
- release_scope:
  - single batch
  - single asset type
  - single CTA
- claims_policy:
  - already reviewed
- approval_context:
  - no pricing proposal in initial outreach
  - only diagnostic-call CTA

HARD CONSTRAINTS
- do not skip release gate
- do not expand batch size during safety review
- no extra offer claims
- no personalization theater

REQUIRED OUTPUT
Return raw specialist output only for STACK_DEV_LAYER.

MANDATORY RAW ARTIFACT FIELDS
- ARTIFACT NAME
- SCENARIO
- STAGE
- SAFETY CHECK SCOPE
- DELIVERABILITY RISKS
- HARD BLOCKERS
- SOFT WARNINGS
- REQUIRED FIXES
- RAW ARTIFACT

MANDATORY ENDING
- RAW ARTIFACT
- ASSUMPTIONS USED
- MISSING INPUTS
- KNOWN LIMITS
```

### Expected `STACK_DEV_LAYER` save block

```
ARTIFACT SAVED
YES

ARTIFACT NAME
LAUNCH_SAFETY__batch_release_check__DELIVERABILITY_GUARD__RUN_NEW_ICP_2026_03_29_LAUNCH_01__v1

SOURCE ROLE
DELIVERABILITY_GUARD

SAVE STATUS
saved

ISSUES FLAGGED
- none
- or: hard blocker
- or: soft warning
- or: release mismatch

ROUTER RE-ENTRY READY
YES
```

### Expected routed summary skeleton

```
STAGE
LAUNCH SAFETY

ENTRY CHECK
READY

ROUTER DECISION
Launch safety artifact has been saved and is ready for release review.

SELECTED SPECIALIST
DELIVERABILITY_GUARD

RAW OUTPUT SAVED TO STACK_DEV_LAYER
YES

ROUTED OUTPUT TO SYSTEM_OS_MASTER
- batch size:
- hard blockers:
- soft warnings:
- required fixes:
- release review required: YES
- launch-safe now: YES / NO

EXIT CRITERIA CHECK
- deliverability risks explicit: YES / NO
- hard blockers explicit: YES / NO
- reviewer verdict READY / READY_WITH_FIXES: YES / NO
- operator knows launch decision: YES / NO

STOP CONDITIONS CHECK
- release gate missing: YES / NO
- reviewer FAIL: YES / NO
- unresolved hard blocker: YES / NO
- asset mismatch: YES / NO

NEXT BOTTLENECK
-

FINAL STATUS
PASS / BLOCKED / STOP
```

### PASS / BLOCKED / STOP examples

**PASS**

```
FINAL STATUS
PASS

NEXT BOTTLENECK
Launch the first controlled batch and collect reply / bounce / booking evidence.
```

**BLOCKED**

```
FINAL STATUS
BLOCKED
DEFECT TYPE
handoff_failure
BLOCKING REASON
Release review is required but has not yet been completed on the selected asset version.
MINIMUM FIX REQUIRED
Run RELEASE_GATE_REVIEWER on the saved launch artifact.
```

**STOP**

```
FINAL STATUS
STOP
DEFECT TYPE
outcome_failure
BLOCKING REASON
Hard blocker indicates current asset should not be launched in this batch configuration.
MINIMUM FIX REQUIRED
Resolve the blocker and re-run launch safety from the approved asset version.
```

---

## 6. Post‑Batch Decision

### Exact specialist invocation block – PERFORMANCE_MEMORY

```
You are invoked by SYSTEM_OS_MASTER.

SCENARIO
POST-BATCH DECISION

STAGE
performance_memory_extraction

OBJECTIVE
Convert observed batch signals into a usable decision basis for repeat / revise / narrow / stop.

INPUTS
- launched_batch_id: BATCH_NEW_ICP_01
- batch_size: 25
- asset_used:
  - approved outbound email variant
- observed_signals:
  - reply_count: [TBD]
  - positive_reply_count: [TBD]
  - call_booked_count: [TBD]
  - bounce_count: [TBD]
  - objection_patterns: [TBD]
- decision_goal:
  - determine whether to repeat, narrow, revise, or stop
- learning_priority:
  - detect wording failures
  - detect ICP mismatch
  - detect CTA friction
  - detect asset safety issues

HARD CONSTRAINTS
- no vanity interpretation
- no invented performance signal
- no rewrite without evidence
- decision must come from observed batch signals

REQUIRED OUTPUT
Return raw specialist output only for STACK_DEV_LAYER.

MANDATORY RAW ARTIFACT FIELDS
- ARTIFACT NAME
- SCENARIO
- STAGE
- PERFORMANCE SIGNALS
- REPEATED FAILURES
- WHAT WORKED
- WHAT SHOULD CHANGE
- MEMORY CANDIDATES
- RAW ARTIFACT

MANDATORY ENDING
- RAW ARTIFACT
- ASSUMPTIONS USED
- MISSING INPUTS
- KNOWN LIMITS
```

### Expected `STACK_DEV_LAYER` save block

```
ARTIFACT SAVED
YES

ARTIFACT NAME
POST_BATCH_DECISION__performance_memory__PERFORMANCE_MEMORY__RUN_NEW_ICP_2026_03_29_POSTBATCH_01__v1

SOURCE ROLE
PERFORMANCE_MEMORY

SAVE STATUS
saved

ISSUES FLAGGED
- none
- or: insufficient batch evidence
- or: contradictory signal interpretation
- or: weak decision basis

ROUTER RE-ENTRY READY
YES
```

### Expected routed summary skeleton

```
STAGE
POST-BATCH DECISION

ENTRY CHECK
READY / BLOCKED

ROUTER DECISION
Post-batch synthesis artifact has been saved and is ready for operating decision.

SELECTED SPECIALIST
PERFORMANCE_MEMORY

RAW OUTPUT SAVED TO STACK_DEV_LAYER
YES

ROUTED OUTPUT TO SYSTEM_OS_MASTER
- observed performance signals:
- strongest positive signal:
- strongest negative signal:
- repeated failure pattern:
- main hypothesis for next change:
- recommended path:
  - repeat / revise / narrow / stop

EXIT CRITERIA CHECK
- performance signals explicit: YES / NO
- repeated failure patterns explicit: YES / NO
- one next bottleneck explicit: YES / NO
- one decision path chosen: YES / NO

STOP CONDITIONS CHECK
- no usable batch evidence: YES / NO
- invented success interpretation: YES / NO
- contradictory next steps: YES / NO
- no explicit bottleneck: YES / NO

NEXT BOTTLENECK
-

FINAL STATUS
PASS / BLOCKED / STOP
```

### PASS / BLOCKED / STOP examples

**PASS**

```
FINAL STATUS
PASS

NEXT BOTTLENECK
Revise wording at the selected friction point before launching the next bounded batch.
```

**BLOCKED**

```
FINAL STATUS
BLOCKED
DEFECT TYPE
operator_confusion
BLOCKING REASON
Observed batch metrics are incomplete, so no defensible repeat / revise / narrow / stop decision can be made.
MINIMUM FIX REQUIRED
Provide complete reply, positive reply, booking, and bounce counts.
```

**STOP**

```
FINAL STATUS
STOP
DEFECT TYPE
outcome_failure
BLOCKING REASON
Batch evidence supports stopping the current motion rather than iterating it further.
MINIMUM FIX REQUIRED
Do not relaunch this lane until discovery and positioning assumptions are reset.
```

---

## 7. Nejpraktičtější v3 použití

Follow this exact flow:

1. **Insert the CURRENT EXECUTION INPUT** into `SYSTEM_OS_MASTER`.
2. **SYSTEM_OS_MASTER selects the specialist.**
3. **Insert the exact specialist invocation block** into the specialist prompt.
4. **Specialist returns a RAW ARTIFACT.**
5. **Save the output via `STACK_DEV_LAYER`.**
6. **Return the `STACK_DEV_LAYER` save block to `SYSTEM_OS_MASTER`.**
7. **`SYSTEM_OS_MASTER` returns the routed summary skeleton** filled with the current state.
8. **Close with PASS / BLOCKED / STOP verdict.**

---

## 8. Final Verdict on v3

The v3 scenario pack is operationally robust.  Each run includes:

- **Exact specialist invocation** with objectives, inputs, constraints and required artifact fields.
- **Explicit handoff** to `STACK_DEV_LAYER` with save status and re‑entry signal.
- **Defined routed summary skeleton** to ensure consistent operator‑usable outputs.
- **PASS / BLOCKED / STOP examples** mapping defect types to minimum fixes.

This pack can be used to run the revenue lane end‑to‑end with high auditability.  The next step (v4) would convert each scenario into a single‑run master sheet, with headers: **INPUTS, ROUTER MOVE, SPECIALIST MOVE, DEV‑LAYER MOVE, REVIEW MOVE, FINAL DECISION MOVE**.

